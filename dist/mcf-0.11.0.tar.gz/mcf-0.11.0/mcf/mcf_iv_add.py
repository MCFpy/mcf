"""Created on Thu Oct 31 10:08:06 2024.

Contains IV specific functions.

@author: MLechner
# -*- coding: utf-8 -*-
"""
from copy import deepcopy
from typing import Any, TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray
from pandas import DataFrame

from mcf import mcf_ate
from mcf import mcf_estimation as mcf_est
from mcf import mcf_gate
from mcf import mcf_iate
from mcf import mcf_weight as mcf_w

if TYPE_CHECKING:
    from mcf.mcf_main import ModifiedCausalForest


# Compute weights of reduced form & 1st stage
def get_weights_iv_local(mcf_: 'ModifiedCausalForest', *,
                         mcf_1st: 'ModifiedCausalForest',
                         mcf_redf: 'ModifiedCausalForest',
                         forest_1st_dic: dict,
                         forest_redf_dic: dict,
                         iate_1st_dic: dict,
                         iate_eff_1st_dic: dict,
                         data_df: DataFrame,
                         round_: str,
                         local_effects: bool = True,
                         no_1st_weights: bool = False,
                         ) -> tuple[dict, dict, dict]:
    """Get IV adjusted weights."""
    if no_1st_weights:
        weights_1st_dic = None
    else:
        weights_1st_dic, _ = mcf_w.get_weights_mp(data_df, forest_1st_dic,
                                                  reg_round=round_ == 'regular',
                                                  cf_cfg=mcf_1st.cf_cfg, ct_cfg=mcf_1st.ct_cfg,
                                                  gen_cfg=mcf_1st.gen_cfg, int_cfg=mcf_1st.int_cfg,
                                                  p_cfg=mcf_1st.p_cfg, var_cfg=mcf_1st.var_cfg,
                                                  gen_tv_cfg_yes=mcf_1st.gen_tv_cfg.yes,
                                                  )
    weights_redf_dic, _ = mcf_w.get_weights_mp(data_df, forest_redf_dic,
                                               reg_round=round_ == 'regular',
                                               cf_cfg=mcf_redf.cf_cfg, ct_cfg=mcf_redf.ct_cfg,
                                               gen_cfg=mcf_redf.gen_cfg, int_cfg=mcf_redf.int_cfg,
                                               p_cfg=mcf_redf.p_cfg, var_cfg=mcf_redf.var_cfg,
                                               gen_tv_cfg_yes=mcf_redf.gen_tv_cfg.yes,
                                               )
    # Scale reduced form weights by 1st stage effects
    if local_effects:
        effect_dic = iate_1st_dic if round_ == 'regular' else iate_eff_1st_dic

        iate_1st = np.squeeze(effect_dic['y_pot'], axis=-1)  # Reduce to 2D
        iate_d_z = iate_1st[:, 1] - iate_1st[:, 0]
        weights_local_dic = scale_weights_1st_stage(iate_d_z, weights_redf_dic,
                                                    mcf_.int_cfg.weight_as_sparse,
                                                    )
    else:
        weights_local_dic = {}

    return weights_1st_dic, weights_redf_dic, weights_local_dic


def scale_weights_1st_stage(effect_1st: NDArray[Any],
                            weights_redf_dic: dict,
                            weight_as_sparse: bool, *,
                            zero_tol: float = 1e-10,
                            ) -> dict:
    """Obtain weights for final IV estimation (local and global)."""
    effect_1st = np.asarray(effect_1st)

    if not np.all(np.isfinite(effect_1st)):
        raise RuntimeError('Estimated first-stage effects contain non-finite values.')

    if np.any(np.abs(effect_1st) <= zero_tol):
        raise RuntimeError('Estimated first-stage effect is zero or numerically indistinguishable '
                           'from zero. IV effects cannot be computed.'
                           )

    if weight_as_sparse:
        # Note: Rows of weights add to one here (before rescaling by 1st stage)
        effect_1st_inv = 1 / effect_1st.reshape(-1, 1)
        weights = [weight.multiply(effect_1st_inv).tocsr() for weight in weights_redf_dic['weights']
                   ]
    else:
        w_redf = weights_redf_dic['weights']
        ate_estimation = len(effect_1st) < len(w_redf)
        weights = [[[None] * 2] * len(w_redf[0])] * len(w_redf)
        for obs_i, weight_i in enumerate(w_redf):
            for treat_j, w_treat_j in enumerate(weight_i):
                weights[obs_i][treat_j][0] = w_treat_j[0].copy()  # Indices
                if ate_estimation:
                    weights[obs_i][treat_j][1] = w_treat_j[1] / effect_1st
                else:
                    weights[obs_i][treat_j][1] = w_treat_j[1] / effect_1st[obs_i]
    weights_scaled_dic = deepcopy(weights_redf_dic)
    weights_scaled_dic['weights'] = weights

    return weights_scaled_dic


def iate_1st_stage_all_folds_rounds(mcf_: 'ModifiedCausalForest',
                                    mcf_1st: 'ModifiedCausalForest',
                                    data_df: DataFrame,
                                    only_one_fold_one_round: bool
                                    ) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Pool first-stage potentials over folds separately for each round."""
    iate_1st_dic = iate_eff_1st_dic = None
    for fold in range(mcf_.cf_cfg.folds):
        for round_ in mcf_.cf_cfg.est_rounds:
            # Get relevant forests
            if only_one_fold_one_round:
                forest_1st_dic = mcf_1st.forest[fold][0]
            else:
                forest_1st_dic = deepcopy(mcf_1st.forest[fold][0 if round_ == 'regular' else 1])
            if mcf_.gen_cfg.with_output and mcf_.gen_cfg.verbose:
                print(f'\n\nWeight maxtrix (1st stage) {fold+1} /',
                      f'{mcf_.cf_cfg.folds} forests, {round_}'
                      )
            weights_1st_dic, _ = mcf_w.get_weights_mp(data_df, forest_1st_dic,
                                                      reg_round=round_ == 'regular',
                                                      cf_cfg=mcf_1st.cf_cfg, ct_cfg=mcf_1st.ct_cfg,
                                                      gen_cfg=mcf_1st.gen_cfg,
                                                      int_cfg=mcf_1st.int_cfg,
                                                      p_cfg=mcf_1st.p_cfg, var_cfg=mcf_1st.var_cfg,
                                                      gen_tv_cfg_yes=mcf_1st.gen_tv_cfg.yes,
                                                      )
            y_pot_f, _, _, _, txt_w_f = mcf_iate.iate_est_mp(
                 mcf_1st, weights_1st_dic, None,
                 reg_round=round_ == 'regular', iv_scaling=True,
                 x_tv_df=(data_df[mcf_1st.var_cfg.x_name_tv] if mcf_1st.gen_tv_cfg.yes else None),
                 )
            if round_ == 'regular':
                y_pot_iate_1st_f = y_pot_f.copy()
                iate_1st_dic, _ = mcf_est.aggregate_pots(mcf_1st, y_pot_iate_1st_f, None,
                                                         txt=txt_w_f, effect_dic= iate_1st_dic,
                                                         fold=fold, title='IATE (1st stage',
                                                         )
            else:
                iate_eff_1st_dic, _ = mcf_est.aggregate_pots(mcf_1st,
                                                             y_pot_f,
                                                             None,
                                                             txt=txt_w_f,
                                                             effect_dic=iate_eff_1st_dic, fold=fold,
                                                             title='IATE additional (1st stage)',
                                                             )
    return iate_1st_dic, iate_eff_1st_dic


def bala_1st_redf(instances: tuple['ModifiedCausalForest', 'ModifiedCausalForest',
                                   'ModifiedCausalForest'], *,
                  weights: tuple[dict, dict, dict],
                  bala_1st_dic: dict,
                  bala_redf_dic: dict,
                  data_df: DataFrame,
                  fold: int,
                  ) -> tuple[dict, dict]:
    """Perform balancing tests for 1st stage and reduced form."""
    _, mcf_1st, mcf_redf = instances
    _, weights_1st_dic, weights_redf_dic = weights
    _, y_pot_f, y_pot_var_f, txt_w_f = mcf_ate.ate_est(mcf_1st, data_df, weights_1st_dic,
                                                       balancing_test=True,
                                                       )
    # Aggregate Balancing results over folds
    bala_1st_dic, _ = mcf_est.aggregate_pots(mcf_1st, y_pot_f, y_pot_var_f,
                                          txt=txt_w_f, effect_dic=bala_1st_dic, fold=fold,
                                          title='Reduced form balancing check: ',
                                          )

    _, y_pot_f, y_pot_var_f, txt_w_f = mcf_ate.ate_est(mcf_redf, data_df, weights_redf_dic,
                                                       balancing_test=True,
                                                       )
    # Aggregate Balancing results over folds
    bala_redf_dic, _ = mcf_est.aggregate_pots(mcf_redf, y_pot_f, y_pot_var_f,
                                              txt=txt_w_f, effect_dic=bala_redf_dic, fold=fold,
                                              title='Reduced form balancing check: ',
                                              )
    return bala_1st_dic, bala_redf_dic


def ate_iv(instances: tuple['ModifiedCausalForest', 'ModifiedCausalForest',
                            'ModifiedCausalForest'], *,
           weights: tuple[dict, dict, dict],
           late_global_dic: dict,
           late_local_dic: dict,
           ate_1st_dic: dict,
           ate_redf_dic: dict,
           data_df: DataFrame,
           fold: int,
           global_effects: bool = True,
           local_effects: bool = True,
           ) -> tuple[NDArray[Any], NDArray[Any], dict, dict, NDArray[Any], dict, NDArray[Any], dict
                      ]:
    """Compute LATE, reduced form and first stage."""
    # Unpack inputs
    mcf_, mcf_1st, mcf_redf = instances
    weights_local_dic, weights_1st_dic, weights_redf_dic = weights

    # 1st stage for current fold
    w_ate_1st, y_pot_1st_f, y_pot_var_1st_f, txt_w_1st_f = mcf_ate.ate_est(mcf_1st, data_df,
                                                                           weights_1st_dic,
                                                                           iv=False,)
    # Reduced form for current fold
    (w_ate_redf, y_pot_redf_f, y_pot_var_redf_f, txt_w_redf_f) = mcf_ate.ate_est(mcf_redf, data_df,
                                                                                 weights_redf_dic,
                                                                                 iv=False,
                                                                                 )
    # Aggregate ATEs over folds
    ate_1st_dic, _ = mcf_est.aggregate_pots(mcf_1st, y_pot_1st_f, y_pot_var_1st_f,
                                           txt=txt_w_1st_f, effect_dic= ate_1st_dic, fold=fold,
                                           title='ATE (1st stage)',
                                           )
    ate_redf_dic, _ = mcf_est.aggregate_pots(mcf_redf, y_pot_redf_f, y_pot_var_redf_f,
                                             txt=txt_w_redf_f, effect_dic=ate_redf_dic, fold=fold,
                                             title='ATE (reduced form)',
                                             )
    if global_effects:
        ate_1st = y_pot_1st_f[:, 1] - y_pot_1st_f[:, 0]
        weights_global_dic = scale_weights_1st_stage(ate_1st, weights_redf_dic,
                                                     mcf_.int_cfg.weight_as_sparse,)
        w_late_global, y_pot_f_global, y_pot_var_f_global, txt_w_f_global = mcf_ate.ate_est(
            mcf_, data_df, weights_global_dic, iv=True,
            )
        # Aggregate ATEs over folds
        late_global_dic, _ = mcf_est.aggregate_pots(mcf_, y_pot_f_global, y_pot_var_f_global,
                                                    txt=txt_w_f_global, effect_dic=late_global_dic,
                                                    fold=fold, title='LATE(global)',
                                                    )
    else:
        w_late_global = late_global_dic = None

    if local_effects:
        w_late_local, y_pot_f_local, y_pot_var_f_local, txt_w_f_local = mcf_ate.ate_est(
            mcf_, data_df, weights_local_dic, iv=True,
            )
        # Aggregate ATEs over folds
        late_local_dic, _ = mcf_est.aggregate_pots(mcf_, y_pot_f_local, y_pot_var_f_local,
                                                   txt=txt_w_f_local, effect_dic=late_local_dic,
                                                   fold=fold, title='LATE(local)',
                                                   )
    else:
        w_late_local = late_local_dic = None

    return (w_late_global, w_late_local, late_global_dic, late_local_dic,
            w_ate_1st, ate_1st_dic, w_ate_redf, ate_redf_dic
            )


def bgate_iv(mcf_: 'ModifiedCausalForest',
             data_df: DataFrame, *,
             lbgate_global_dic: dict[str, Any] | None,
             lbgate_local_dic: dict[str, Any] | None,
             lbgate_m_late_global_dic: dict[str, Any] | None,
             lbgate_m_late_local_dic: dict[str, Any] | None,
             fold: int,
             iv_tuple: tuple['ModifiedCausalForest', 'ModifiedCausalForest',
                             dict, dict] | None = None,
             gate_type: str = 'BGATE',
             title: str = 'LBGATE',
             global_effects: bool = False,
             local_effects: bool = True,
             round_: str = 'regular',
             ) -> tuple[dict[str, Any] | None, dict[str, Any] | None,
                        dict[str, Any] | None, dict[str, Any] | None,
                        dict[str, Any] | None, dict[str, Any] | None, str]:
    """Compute BGATE with instrumental variables."""
    txt_b = ''
    if global_effects:

        raise NotImplementedError('LBGATEs, LCGATEs, and LGATEs are not '
                                  'implemented for global compliers.'
                                  )
    lbgate_est_global_dic = None

    if local_effects:
        (y_pot_lbgate_f, y_pot_var_lbgate_f, y_pot_mlate_lbgate_f,
         y_pot_mlate_var_lbgate_f, lbgate_est_local_dic, txt_w_f, txt_b,
         ) = mcf_gate.bgate_est(mcf_, data_df, None,
                                gate_type=gate_type, iv_tuple=iv_tuple, iv_round=round_,
                                )
        lbgate_local_dic, _ = mcf_est.aggregate_pots(mcf_, y_pot_lbgate_f, y_pot_var_lbgate_f,
                                                     txt=txt_w_f, effect_dic=lbgate_local_dic,
                                                     fold=fold, pot_is_list=True,
                                                     title=title+' (local)'
                                                     )
        if y_pot_mlate_lbgate_f is not None:
            lbgate_m_late_local_dic, _ = mcf_est.aggregate_pots(mcf_, y_pot_mlate_lbgate_f,
                                                                y_pot_mlate_var_lbgate_f,
                                                                txt=txt_w_f,
                                                                effect_dic=lbgate_m_late_local_dic,
                                                                fold=fold, pot_is_list=True,
                                                                title=title + ' minus LATE (local)',
                                                                )
    else:
        lbgate_est_local_dic = None

    return (lbgate_global_dic, lbgate_local_dic, lbgate_m_late_global_dic, lbgate_m_late_local_dic,
            lbgate_est_global_dic, lbgate_est_local_dic, txt_b
            )


def gate_iv(mcf_: 'ModifiedCausalForest',
            data_df: DataFrame, *,
            weights: tuple[dict, dict, dict],
            # w_late_global: npt.NDArray[Any],
            w_late_local: NDArray[Any],
            lgate_global_dic: dict,
            lgate_local_dic: dict,
            lgate_m_late_global_dic: dict,
            lgate_m_late_local_dic: dict,
            fold: int,
            title: str = 'LGATE',
            global_effects: bool = False,
            local_effects: bool = True,
            ) -> tuple[dict, dict, dict, dict, dict, dict,]:
    """Compute GATE with instrumental variables."""
    # weights_local_dic, weights_1st_dic, weights_redf_dic = weights
    weights_local_dic, _, _ = weights
    if global_effects:
        raise NotImplementedError('LBGATEs, LCGATEs, and LGATEs are not implemented for global '
                                  'compliers.'
                                  )
    lgate_est_global_dic = None

    if local_effects:
        (y_pot_lgate_f, y_pot_var_lgate_f, y_pot_mlate_lgate_f,
         y_pot_mlate_var_lgate_f, lgate_est_local_dic, txt_w_f
         ) = mcf_gate.gate_est(mcf_, data_df, weights_local_dic, w_late_local, iv=True)

        lgate_local_dic, _ = mcf_est.aggregate_pots(mcf_, y_pot_lgate_f, y_pot_var_lgate_f,
                                                    txt=txt_w_f, effect_dic=lgate_local_dic,
                                                    fold=fold,
                                                    pot_is_list=True, title=title+' (local)'
                                                 )
        if y_pot_mlate_lgate_f is not None:
            lgate_m_late_local_dic, _ = mcf_est.aggregate_pots(mcf_, y_pot_mlate_lgate_f,
                                                               y_pot_mlate_var_lgate_f,
                                                               txt=txt_w_f,
                                                               effect_dic=lgate_m_late_local_dic,
                                                               fold=fold, pot_is_list=True,
                                                               title=title + ' minus LATE (local)',
                                                               )
    else:
        lgate_est_local_dic = None

    return (lgate_global_dic, lgate_local_dic, lgate_m_late_global_dic,
            lgate_m_late_local_dic, lgate_est_global_dic, lgate_est_local_dic
            )


def iate_iv(mcf_: 'ModifiedCausalForest', *,
            weights_dic: dict[str, Any],
            iate_dic: dict[str, Any] | None,
            iate_m_ate_dic: dict[str, Any] | None,
            w_ate: NDArray[Any] | None,
            round_: str,
            fold: int,
            iv: bool = True,
            title: str = 'LIATE',
            x_tv_df: DataFrame | None = None,
            ) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Accumulate individual effects and deviations within one IV estimation round."""
    pot_y, pot_y_var, pot_y_m_ate, pot_y_m_ate_var, txt = mcf_iate.iate_est_mp(
        mcf_, weights_dic, w_ate, reg_round=round_ == 'regular', iv=iv,
        x_tv_df=x_tv_df if mcf_.gen_tv_cfg.yes else None,
        )
    iate_dic, _ = mcf_est.aggregate_pots(
        mcf_, pot_y, pot_y_var, txt=txt, effect_dic=iate_dic, fold=fold, title=title,
        )
    if pot_y_m_ate is not None:
        deviation_title = title + (' minus LATE' if iv else ' minus ATE')
        iate_m_ate_dic, _ = mcf_est.aggregate_pots(
            mcf_, pot_y_m_ate, pot_y_m_ate_var, txt=txt, effect_dic=iate_m_ate_dic,
            fold=fold, title=deviation_title,
            )
    return iate_dic, iate_m_ate_dic
