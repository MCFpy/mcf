"""
Created on Thu Mai 11 11:05:15 2023.

Contains the functions needed for initialising the parameters of the programme.
@author: MLechner
-*- coding: utf-8 -*-
"""
from copy import deepcopy
from numbers import Real
import sys
from typing import Any, TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray
from pandas import DataFrame
from psutil import virtual_memory

from mcf.mcf_estimation import joint_d_values
from mcf import mcf_general as mcf_gp
from mcf import mcf_print_stats as mcf_ps
from mcf import mcf_init_values_cfg as mcf_initvals

try:
    import ray        # type: ignore[import]
except (ImportError, OSError):
    ray = None        # type: ignore[assignment]

if TYPE_CHECKING:
    from mcf.mcf_main import ModifiedCausalForest
    from mcf.mcf_init import VarCfg


def int_update_train(mcf_: 'ModifiedCausalForest') -> None:
    """Update internal parameters before training."""
    int_cfg, cf_cfg = mcf_.int_cfg, mcf_.cf_cfg

    int_cfg.mp_ray_shutdown = ray_shut_down(int_cfg.mp_ray_shutdown,cf_cfg.n_train_eff)
    if int_cfg.max_cats_cont_vars is None or int_cfg.max_cats_cont_vars < 1:
        int_cfg.max_cats_cont_vars = cf_cfg.n_train_eff + 100_000_000
    else:
        int_cfg.max_cats_cont_vars = round(int_cfg.max_cats_cont_vars)

    if cf_cfg.n_train_eff < 20_000:
        int_cfg.mem_object_store_1 = int_cfg.mem_object_store_2 = None
    else:
        memory = virtual_memory()
        # Obs. & number of trees as determinants of obj.store when forest build
        min_obj_str_n_1 = ((cf_cfg.n_train_eff / 60_000) * (cf_cfg.boot / 1_000)
                           * (cf_cfg.m_grid * cf_cfg.n_min_grid * cf_cfg.alpha_reg_grid / 12)
                           * (120 * 1024 * 1024 * 1024) * 5
            )
        min_obj_str_n_2 = ((cf_cfg.n_train_eff / 60_000) * (cf_cfg.boot / 1_000)
                           * (120 * 1024 * 1024 * 1024)
                           )
        int_cfg.mem_object_store_1 = min(memory.available*0.5, min_obj_str_n_1)
        int_cfg.mem_object_store_2 = min(memory.available*0.5, min_obj_str_n_2)
        if int_cfg.mp_ray_objstore_multiplier > 0:
            int_cfg.mem_object_store_1 *= int_cfg.mp_ray_objstore_multiplier
            int_cfg.mem_object_store_2 *= int_cfg.mp_ray_objstore_multiplier
        int_cfg.mem_object_store_1 = min(0.7 * memory.available, int_cfg.mem_object_store_1)
        int_cfg.mem_object_store_2 = min(0.5 * memory.available, int_cfg.mem_object_store_2)
        int_cfg.mem_object_store_1 = int(int_cfg.mem_object_store_1)
        int_cfg.mem_object_store_2 = int(int_cfg.mem_object_store_2)

    int_cfg.bigdata_train = cf_cfg.n_train > int_cfg.obs_bigdata

    if int_cfg.mp_backend is None:
        if (sys.platform.startswith('win') and cf_cfg.n_train <= 250_000) or ray is None:
            int_cfg.mp_backend = 'joblib'
        else:
            int_cfg.mp_backend = 'ray'

    mcf_.int_cfg = int_cfg  # probably redundant


def int_update_pred(mcf_: 'ModifiedCausalForest', n_pred: int) -> None:
    """Update internal parameters before prediction."""
    int_cfg = mcf_.int_cfg
    # Adjusted for effective training sample size
    n_pred_adj = n_pred * (mcf_.cf_cfg.n_train_eff / n_pred)**0.5
    int_cfg.mp_ray_shutdown = ray_shut_down(int_cfg.mp_ray_shutdown, n_pred_adj)
    memory = virtual_memory()
    if n_pred_adj < 20000:
        int_cfg.mem_object_store_3 = None
    else:
        min_obj_str_n_3 = (n_pred_adj / 60000) * (120 * 1024 * 1024 * 1024)
        int_cfg.mem_object_store_3 = min(memory.available * 0.5, min_obj_str_n_3)
        if int_cfg.mp_ray_objstore_multiplier > 0:
            int_cfg.mem_object_store_3 *= int_cfg.mp_ray_objstore_multiplier
        if int_cfg.mem_object_store_3 > 0.5 * memory.available:
            int_cfg.mem_object_store_3 = int(0.5 * memory.available)
        int_cfg.mem_object_store_3 = int(int_cfg.mem_object_store_3)

    mcf_.int_cfg = int_cfg  # probably redunant


def gen_update_train(mcf_: 'ModifiedCausalForest',
                     data_df: DataFrame,
                     ) -> None:
    """Add and update some dictionary entry based on data."""
    gen_cfg, var_cfg = mcf_.gen_cfg, mcf_.var_cfg

    d_dat = (data_df[var_cfg.d_name[0]].to_numpy()
             if mcf_.gen_tv_cfg.yes else data_df[var_cfg.d_name].to_numpy()
             )
    gen_cfg.d_values = np.unique(np.int32(np.round(d_dat))).tolist()
    gen_cfg.no_of_treat = len(gen_cfg.d_values)
    if len(data_df) > mcf_.int_cfg.obs_bigdata and gen_cfg.mp_parallel > 1:
        gen_cfg.mp_parallel = int(gen_cfg.mp_parallel * 0.75)

    mcf_.gen_cfg = gen_cfg


def gen_tv_update_train(mcf_: 'ModifiedCausalForest',
                        data_df: DataFrame
                        ) -> None:
    """Adjust cross-validation for number of training observations."""
    obs = len(data_df)
    if mcf_.gen_tv_cfg.cv_k is None:
        mcf_.gen_tv_cfg.cv_k = mcf_initvals.determine_cv_k(obs)
    if mcf_.gen_tv_cfg.score_cv_k is None:
        mcf_.gen_tv_cfg.score_cv_k = mcf_initvals.determine_cv_k(obs)
    if len(mcf_.gen_tv_cfg.penalize_version) == 1:
        mcf_.gen_tv_cfg.penalize_version *= mcf_.gen_cfg.no_of_treat
    if len(mcf_.gen_tv_cfg.penalize_version) != mcf_.gen_cfg.no_of_treat:
        raise ValueError('gen_tv_penalize_version must be a list or tuple of length equal to the '
                         'number of main treatments (or a single Boolean).'
                         )


def gen_tv_update_pred(mcf_: 'ModifiedCausalForest') -> None:
    """Update treatment-version metadata and the tuning-outcome index."""
    gen_tv_cfg, var_cfg = mcf_.gen_tv_cfg, mcf_.var_cfg

    if len(var_cfg.y_tree_name) != 1:
        raise ValueError('Treatment-version estimation requires one tree-building outcome.')

    # Use the current names, including any local-centering suffix.
    try:
        gen_tv_cfg.y_tree_index = var_cfg.y_name.index(var_cfg.y_tree_name[0])
    except ValueError as exc:
        raise ValueError('The tree-building outcome must be contained in var_cfg.y_name.') from exc

    d_all_values, no_of_treat_per_main = [], []
    main_vals = gen_tv_cfg.d_dict['main_treat']
    sub_vals = gen_tv_cfg.d_dict['sub_treat']
    for m_idx, m_val in enumerate(main_vals):
        if sub_vals[m_idx]:
            no_of_treat_per_main.append(len(sub_vals[m_idx]))
            for s_val in sub_vals[m_idx]:
                d_all_values.append((m_val, s_val,))
        else:
            d_all_values.append((m_val, 0,))
            no_of_treat_per_main.append(1)

    mcf_.gen_tv_cfg.d_all_values = np.asarray(d_all_values, dtype=np.int32)
    mcf_.gen_tv_cfg.no_of_treat_all = len(d_all_values)
    mcf_.gen_tv_cfg.no_of_treat_per_main = no_of_treat_per_main
    mcf_.gen_tv_cfg.d_all_values_one_label = joint_d_values(main_vals, sub_vals, as_string=False)


def var_update_train(mcf_: 'ModifiedCausalForest', data_df: DataFrame) -> None:
    """Update var_cfg with training data if needed."""
    d_name = mcf_.var_cfg.d_name
    if isinstance(d_name, (list, tuple)):
        for d_idx, d_val in enumerate(d_name):
            d_name[d_idx] = mcf_gp.adjust_var_name(d_val, data_df.columns.tolist())
    else:
        d_name = mcf_gp.adjust_var_name(d_name, data_df.columns.tolist())

    mcf_.var_cfg.d_name = d_name


def ct_update_train(mcf_: 'ModifiedCausalForest', data_df: DataFrame) -> None:
    """Initialise dictionary with parameters of continuous treatment."""
    gen_cfg, ct_cfg, var_cfg = mcf_.gen_cfg, mcf_.ct_cfg, mcf_.var_cfg
    zero_tol = mcf_.int_cfg.zero_tol
    d_dat = data_df[var_cfg.d_name].to_numpy(copy=True)
    if gen_cfg.d_type == 'continuous':
        # Existing grids include the zero point; recover their positive-point counts.
        grid_nn = (ct_cfg.grid_nn if ct_cfg.grid_nn_val is None
                   else len(ct_cfg.grid_nn_val) - 1)
        grid_w = (ct_cfg.grid_w if ct_cfg.grid_w_val is None
                  else len(ct_cfg.grid_w_val) - 1)
        grid_dr = (ct_cfg.grid_dr if ct_cfg.grid_dr_val is None
                   else len(ct_cfg.grid_dr_val) - 1)
        ct_cfg.grid_nn = ct_grid(grid_nn, 10)
        ct_cfg.grid_w = ct_grid(grid_w, 10)
        ct_cfg.grid_dr = ct_grid(grid_dr, 100)
        ct_cfg.grid_dr = max(ct_cfg.grid_dr, ct_cfg.grid_w)
        ct_cfg.grid_nn_val = grid_val_fct(ct_cfg.grid_nn, d_dat, zero_tol)
        ct_cfg.grid_w_val = grid_val_fct(ct_cfg.grid_w, d_dat, zero_tol)
        ct_cfg.grid_dr_val = grid_val_fct(ct_cfg.grid_dr, d_dat, zero_tol)
        ct_cfg.grid_nn = len(ct_cfg.grid_nn_val)
        ct_cfg.grid_w = len(ct_cfg.grid_w_val)
        ct_cfg.grid_dr = len(ct_cfg.grid_dr_val)
        gen_cfg.no_of_treat = len(ct_cfg.grid_nn_val)
        gen_cfg.d_values = None
        precision_of_cont_treat = 4
        (ct_cfg.w_to_dr_int_w01, ct_cfg.w_to_dr_int_w10,
         ct_cfg.w_to_dr_index_full, ct_cfg.d_values_dr_list,
         ct_cfg.d_values_dr_np) = interpol_weights(ct_cfg.grid_dr, ct_cfg.grid_w, ct_cfg.grid_w_val,
                                                   precision_of_cont_treat
                                                   )
        var_cfg.grid_nn_name = grid_name(var_cfg.d_name, ct_cfg.grid_nn)
        var_cfg.grid_w_name = grid_name(var_cfg.d_name, ct_cfg.grid_w)
        var_cfg.grid_dr_name = grid_name(var_cfg.d_name, ct_cfg.grid_dr)
    else:
        ct_cfg.grid_nn = ct_cfg.grid_nn_val = ct_cfg.grid_w = None
        ct_cfg.grid_dr = ct_cfg.grid_dr_val = ct_cfg.grid_w_val = None
    mcf_.gen_cfg = gen_cfg
    mcf_.ct_cfg = ct_cfg


def lc_update_train(mcf_: 'ModifiedCausalForest', data_df):
    """Adjust cross-validation for number of training observations."""
    obs = len(data_df)
    if mcf_.lc_cfg.cs_cv_k is None:
        mcf_.lc_cfg.cs_cv_k = mcf_initvals.determine_cv_k(obs)


def p_ba_update_train(mcf_: 'ModifiedCausalForest', data_df: DataFrame) -> None:
    """Adjust cross-validation for bias adjustment."""
    if mcf_.p_ba_cfg.cv_k is None:
        mcf_.p_ba_cfg.cv_k = mcf_initvals.determine_cv_k(len(data_df))


def cs_update_train(mcf_: 'ModifiedCausalForest') -> None:
    """Adjust cs for number of treatments."""
    cs_cfg = mcf_.cs_cfg
    if cs_cfg.adjust_limits is None:
        cs_cfg.adjust_limits = (mcf_.gen_cfg.no_of_treat - 2) * 0.05
    if cs_cfg.adjust_limits < 0:
        raise ValueError('Negative common support adjustment factor is not possible.')
    mcf_.cs_cfg = cs_cfg


def cf_update_train(mcf_: 'ModifiedCausalForest', data_df: DataFrame) -> None:
    """Update cf parameters that need information from training data."""
    cf_cfg, gen_cfg, lc_cfg = mcf_.cf_cfg, mcf_.gen_cfg, mcf_.lc_cfg
    fs_cfg, var_cfg, int_cfg = mcf_.fs_cfg, mcf_.var_cfg, mcf_.int_cfg
    n_train = len(data_df)
    # Number of obs in treatments before any selection
    vcount = data_df.groupby(var_cfg.d_name[0]).size()  # pylint:disable=E1101
    obs_by_treat = vcount.to_numpy()
    if abs(n_train - obs_by_treat.sum()) > len(obs_by_treat):
        raise RuntimeError(f'Counting treatments does not work. n_d_sum:'
                           f' {obs_by_treat.sum()}, n_train: {n_train}. Difference'
                           ' could be due to missing values in treatment.')

    # Adjust for smaller effective training samples due to feature selection
    # and possibly local centering and common support
    cf_cfg.n_train = reduce_effective_n_train(mcf_, n_train)
    if fs_cfg.yes and fs_cfg.other_sample:
        obs_by_treat = obs_by_treat * (1 - fs_cfg.other_sample_share)

    if not isinstance(cf_cfg.chunks_maxsize, (int, float)) or cf_cfg.chunks_maxsize < 100:
        cf_cfg.baseline = 250_000 if mcf_.low_mem_cfg.yes else 100_000
        cf_cfg.chunks_maxsize = get_chunks_maxsize_forest(cf_cfg.baseline, cf_cfg.n_train,
                                                          mcf_.gen_cfg.no_of_treat,
                                                          )
    else:
        cf_cfg.chunks_maxsize = round(cf_cfg.chunks_maxsize)

    # Effective sample sizes per chuck
    no_of_chuncks = int(np.ceil(cf_cfg.n_train / cf_cfg.chunks_maxsize))
    # Actual number of chuncks could be smaller if lot's of data is deleted in
    # common support adjustment
    # This will be updated in the train method, adjusting for common support
    cf_cfg.n_train_eff = np.int32(cf_cfg.n_train / no_of_chuncks)
    obs_by_treat_eff = np.int32(obs_by_treat / no_of_chuncks)

    # size of subsampling samples         n/2: size of forest sample
    cf_cfg.subsample_share_forest = sub_size(
        cf_cfg.n_train_eff, cf_cfg.subsample_factor_forest, 0.67)

    # Initial estimate; train_forest resolves the actual filling size for each round/chunk.
    n_fill = max(1, round(cf_cfg.n_train_eff * (1 - int_cfg.share_forest_sample)))
    cf_cfg.subsample_share_eval = sub_size_eval(
        n_fill, cf_cfg.subsample_factor_eval, cf_cfg.subsample_share_forest,
        getattr(cf_cfg, 'subsample_power_eval', 0.85),
        )
    n_d_subsam = (obs_by_treat_eff.min() * int_cfg.share_forest_sample
                  * cf_cfg.subsample_share_forest
                  )
    # Further adjustments when data is used for other purposes
    if mcf_.cs_cfg.type_ > 0 and not lc_cfg.cs_cv:
        n_d_subsam *= (1 - lc_cfg.cs_share)
    if lc_cfg.yes and not lc_cfg.cs_cv:
        n_d_subsam *= (1 - lc_cfg.cs_share)

    # Check only random thresholds to save computation time when building CF
    if cf_cfg.random_thresholds is None or cf_cfg.random_thresholds < 0:
        cf_cfg.random_thresholds = round(4 + cf_cfg.n_train_eff**0.2)

    # Penalty multiplier in CF building
    if (cf_cfg.p_diff_penalty is None or cf_cfg.p_diff_penalty < 0):
        if cf_cfg.mtot == 4:
            cf_cfg.p_diff_penalty = 0.5
        else:                                   # Approx 1 for N = 1000
            cf_cfg.p_diff_penalty = (
                2 * ((cf_cfg.n_train_eff * cf_cfg.subsample_share_forest)**0.9)
                / (cf_cfg.n_train_eff * cf_cfg.subsample_share_forest))
            if cf_cfg.mtot == 2:
                cf_cfg.p_diff_penalty = 100 * cf_cfg.p_diff_penalty
            if gen_cfg.d_type == 'discrete':
                cf_cfg.p_diff_penalty *= np.sqrt(gen_cfg.no_of_treat * (gen_cfg.no_of_treat - 1) / 2
                                                 )
    elif cf_cfg.p_diff_penalty == 0:
        if cf_cfg.mtot == 4:
            cf_cfg.mtot = 1  # No random mixing  prob of MSE+MCE rule== 1
    else:
        if cf_cfg.mtot == 4:
            if cf_cfg.p_diff_penalty > 1:  # if accidently scaled %
                cf_cfg.p_diff_penalty = cf_cfg.p_diff_penalty / 100
            if not 0 <= cf_cfg.p_diff_penalty <= 1:
                raise ValueError('Probability of using p-score > 1. Programm stopped.')
    if cf_cfg.p_diff_penalty:
        if cf_cfg.penalty_type == 'mse_d':
            cf_cfg.estimator_str += ' Penalty "MSE of treatment variable"'
        else:
            cf_cfg.estimator_str += f' Penalty {cf_cfg.penalty_type}'

    # Minimum leaf size
    if cf_cfg.n_min_min is None or cf_cfg.n_min_min < 1:
        cf_cfg.n_min_min = round(max((n_d_subsam**0.4) / 10, 1.5) * gen_cfg.no_of_treat)
    else:
        cf_cfg.n_min_min = round(cf_cfg.n_min_min)
    if cf_cfg.n_min_max is None or cf_cfg.n_min_max < 1:
        cf_cfg.n_min_max = round(max(n_d_subsam**0.5 / 10, 2) * gen_cfg.no_of_treat)
    else:
        cf_cfg.n_min_max = round(cf_cfg.n_min_max)
    cf_cfg.n_min_max = max(cf_cfg.n_min_min, cf_cfg.n_min_max)
    if gen_cfg.d_type == 'discrete':
        if cf_cfg.n_min_treat is None or cf_cfg.n_min_treat < 1:
            cf_cfg.n_min_treat = round(max((cf_cfg.n_min_min + cf_cfg.n_min_max) / 2
                                           / gen_cfg.no_of_treat / 10, 1)
                                       )
        else:
            cf_cfg.n_min_treat = round(cf_cfg.n_min_treat)
        min_leaf_size = cf_cfg.n_min_treat * gen_cfg.no_of_treat
        if cf_cfg.n_min_min < min_leaf_size:
            cf_cfg.n_min_min = min_leaf_size
            cf_cfg.n_min_max = max(cf_cfg.n_min_max, min_leaf_size)
            mcf_ps.print_mcf(gen_cfg, 'Minimum leaf size adjusted. Smallest ',
                             f' leafsize set to: {cf_cfg.n_min_min}', summary=True
                             )
    else:
        cf_cfg.n_min_treat = 0
    if cf_cfg.n_min_grid is None or cf_cfg.n_min_grid < 1:
        cf_cfg.n_min_grid = 1
    else:
        cf_cfg.n_min_grid = round(cf_cfg.n_min_grid)

    if cf_cfg.n_min_min == cf_cfg.n_min_max:
        cf_cfg.n_min_grid = 1
    if cf_cfg.n_min_grid == 1:
        cf_cfg.n_min_min = cf_cfg.n_min_max = round((cf_cfg.n_min_min + cf_cfg.n_min_max) / 2)
        cf_cfg.n_min_values = cf_cfg.n_min_min
    else:
        if cf_cfg.n_min_grid == 2:
            n_min = np.hstack((cf_cfg.n_min_min, cf_cfg.n_min_max))
        else:
            n_min = np.linspace(cf_cfg.n_min_min, cf_cfg.n_min_max, cf_cfg.n_min_grid)
        n_min = list(np.unique(np.round(n_min)))
        cf_cfg.n_min_min, cf_cfg.n_min_max = n_min[0], n_min[-1]
        cf_cfg.n_min_grid = len(n_min)
        cf_cfg.n_min_values = n_min
    cf_cfg.forests = None              # To be filled at the end of training
    mcf_.cf_cfg = cf_cfg


def p_update_train(mcf_: 'ModifiedCausalForest') -> None:
    """Update parameters with sample size information."""
    p_cfg = mcf_.p_cfg
    # Categorise continuous gate variables
    if p_cfg.max_cats_z_vars is None or p_cfg.max_cats_z_vars < 1:
        p_cfg.max_cats_z_vars = round(mcf_.cf_cfg.n_train_eff ** 0.3)
    else:
        p_cfg.max_cats_z_vars = round(p_cfg.max_cats_z_vars)
    mcf_.p_cfg = p_cfg


def low_mem_update_train(mcf_: 'ModifiedCausalForest', n_train: int) -> None:
    """Update low_memory configuration with size of training data."""
    if mcf_.low_mem_cfg.max_chunksize is None or mcf_.low_mem_cfg.max_chunksize < 1:
        max_size = 1_000
        min_size = 10
        base_level = 10_000
        if n_train > base_level:
            max_chunksize = max(max_size - (n_train - base_level)**0.5, min_size)
        else:
            max_chunksize = max_size

        mcf_.low_mem_cfg.max_chunksize = max_chunksize


def p_update_pred(mcf_: 'ModifiedCausalForest',
                  data_df: DataFrame
                  ) -> DataFrame:
    """Update parameters of p_cfg with data_df related information."""
    gen_cfg, p_cfg, var_cfg = mcf_.gen_cfg, mcf_.p_cfg, mcf_.var_cfg
    n_pred = len(data_df)
    if p_cfg.bgate_sample_share is None or p_cfg.bgate_sample_share <= 0:
        p_cfg.bgate_sample_share = (1 if n_pred < 1000
                                    else (1000 + ((n_pred-1000) ** 0.75)) / n_pred
                                    )
    # All variable names to lower case
    data_df = data_df.rename(columns=lambda x: x.casefold())
    # Check if treatment is included
    if gen_cfg.d_type == 'continuous':
        p_cfg.d_in_pred = False
    else:
        if mcf_.gen_tv_cfg.yes:
            p_cfg.d_in_pred = (var_cfg.d_name[0] in data_df.columns
                               and var_cfg.d_name[1] in data_df.columns
                               )
        else:
            d_name = (var_cfg.d_name[0] if isinstance(var_cfg.d_name, (list, tuple))
                      else var_cfg.d_name
                      )
            p_cfg.d_in_pred = d_name in data_df.columns   # Update boolean
    if not p_cfg.d_in_pred:
        if p_cfg.atet or p_cfg.gatet:
            mcf_ps.print_mcf(gen_cfg,
                             'Treatment variable not in prediction data. ATET '
                             'and GATET cannot be computed.', summary=True
                             )
        p_cfg.atet = p_cfg.gatet = False
        if p_cfg.choice_based_sampling:
            raise ValueError('Choice based sampling relates only to prediction '
                             'data. It requires treatment information in '
                             'prediction data, WHICH IS MISSING!'
                             )
    if p_cfg.choice_based_sampling is True:
        if len(p_cfg.choice_based_probs) != gen_cfg.no_of_treat:
            raise ValueError('Choice based sampling. Rows in choice '
                             'probabilities do not correspond to number of treatments.'
                             )
        if any(v <= 0 for v in p_cfg.choice_based_probs):
            raise ValueError('Choice based sampling active. Not possible to '
                             'have zero or negative choice probability. '
                             )
        # Normalize
        p_cfg.choice_based_probs = mcf_initvals.p_cb_normalize(p_cfg.choice_based_probs,
                                                               gen_cfg.no_of_treat
                                                               )
    else:
        p_cfg.choice_based_sampling, p_cfg.choice_based_probs = False, 1
    mcf_.p_cfg = p_cfg

    return data_df


def post_update_pred(mcf_: 'ModifiedCausalForest', data_df: DataFrame) -> None:
    """Resolve the automatic cluster grid while preserving explicit candidate counts."""
    groups = mcf_initvals.kmeans_groups_fct(mcf_.post_cfg.kmeans_no_of_groups)
    if groups is None:
        n_pred = len(data_df)
        if n_pred < 10_000:
            middle = 5
        elif n_pred > 100_000:
            middle = 10
        else:
            middle = 5 + round(n_pred / 20_000)
        if middle < 7:
            groups = [middle - 2, middle - 1, middle, middle + 1, middle + 2]
        else:
            groups = [middle - 4, middle - 2, middle, middle + 2, middle + 4]
    mcf_.post_cfg.kmeans_no_of_groups = groups


def name_unique(all_names: list[str]) -> list[str]:
    """Remove any duplicates."""
    seen = set()
    name_unique_ = [item for item in all_names if item not in seen and not seen.add(item)]

    return name_unique_


def get_ray_del_defaults(_mp_ray_del_user: Any) -> Any:
    """Get values for :mp_ray_del."""
    if _mp_ray_del_user is None:
        _mp_ray_del = ('refs',)
    else:
        possible_vals = ('refs', 'rest', 'none')

        match _mp_ray_del_user:
            case str() as s:    _mp_ray_del = (s,)
            case list() as lst: _mp_ray_del = tuple(lst)
            case _:             _mp_ray_del = _mp_ray_del_user

        if len(_mp_ray_del) > 2:
            raise ValueError(f'Too many parameters for _mp_ray_del{_mp_ray_del}')
        if not isinstance(_mp_ray_del, tuple):
            raise TypeError(f'mp_ray_del is no Tuple {_mp_ray_del}')
        if not all(i in possible_vals for i in _mp_ray_del):
            raise TypeError(f'Wrong values for _mp_ray_del {_mp_ray_del}')

    return _mp_ray_del


def ray_shut_down(ray_shutdown: bool | None, len_data: int) -> bool:
    """Define mimimum sample size for ray_shut_down."""
    if ray_shutdown is None:
        ray_shutdown = not len_data < 150000
    if not isinstance(ray_shutdown, bool):
        raise TypeError('mp_ray_shutdown must be either None or Boolean')

    return ray_shutdown


def get_alpha(alpha_reg_grid: int | float | None,
              alpha_reg_max: float | None,
              alpha_reg_min: float | None,
              ) -> tuple[int | float,
                         float, float,
                         float | NDArray[float] | list[float]
                         ]:
    """Get the alphas for the CF."""
    if alpha_reg_min is None or not 0 <= alpha_reg_min < 0.5:
        alpha_reg_min = 0.05
    if alpha_reg_max is None or not 0 <= alpha_reg_max < 0.5:
        alpha_reg_max = 0.15
    alpha_reg_grid = (1 if alpha_reg_grid is None or alpha_reg_grid < 1
                      else round(alpha_reg_grid))
    if alpha_reg_min >= alpha_reg_max:
        alpha_reg_grid, alpha_reg_max = 1, alpha_reg_min

    match alpha_reg_grid:
        case 1: alpha_reg = (alpha_reg_max + alpha_reg_min) / 2
        case 2: alpha_reg = np.array([alpha_reg_min, alpha_reg_max])
        case _:
            alpha_reg = np.linspace(alpha_reg_min, alpha_reg_max, alpha_reg_grid)
            alpha_reg = list(np.unique(alpha_reg))
            alpha_reg_grid = len(alpha_reg)

    return alpha_reg_grid, alpha_reg_max, alpha_reg_min, alpha_reg


def grid_val_fct(grid: float | int,
                 d_dat: NDArray[Any],
                 zero_tol: float = 1e-10,
                 ) -> NDArray[Any]:
    """Help for initialisation."""
    quantile = np.linspace(1/(grid)/2, 1-1/grid/2, num=grid)
    d_dat_min = d_dat.min()
    d_dat_r = d_dat - d_dat_min if d_dat_min != 0 else d_dat
    gridvalues = np.around(
        np.quantile(d_dat_r[d_dat_r > zero_tol], quantile), decimals=6)
    gridvalues = np.insert(gridvalues, 0, 0)

    return gridvalues


def ct_grid(user_grid: list[int | float], defaultgrid: list[int | float]) -> list[int | float]:
    """Help for initialisation."""
    if isinstance(user_grid, int):
        grid = defaultgrid if user_grid < 1 else user_grid
    else:
        grid = defaultgrid

    return grid


def interpol_weights(ct_grid_dr: float | int,
                     ct_grid_w: int,
                     ct_grid_w_val: list[float | int] | NDArray[Any],
                     precision_of_treat: int
                     ) -> tuple[NDArray[Any], NDArray[Any], NDArray[Any],
                                list[int | float],
                                NDArray[Any],
                                ]:
    """Generate interpolation measures for continuous treatments."""
    interpol_points = round(ct_grid_dr / ct_grid_w) + 1
    int_w01 = np.linspace(0, 1, interpol_points, endpoint=False)
    int_w10 = 1 - int_w01
    treat_val_list, j_all = [], 0
    index_full = np.zeros((ct_grid_w, len(int_w01)))
    for i, (val, val1) in enumerate(zip(ct_grid_w_val[:-1], ct_grid_w_val[1:])):
        for j in range(interpol_points):
            value = int_w10[j] * val + int_w01[j] * val1
            treat_val_list.append(round(value, precision_of_treat))
            index_full[i, j] = j_all
            j_all = j_all + 1    # do not use +=
    treat_val_list.append(ct_grid_w_val[-1])
    treat_val_np = np.around(np.array(treat_val_list), precision_of_treat)
    if len(treat_val_np) != len(np.unique(treat_val_np)):
        raise ValueError('Continuous treatment needs higher precision (maybe treatment '
                         'is too discrete to be treated as continuous.'
                         )
    index_full[ct_grid_w-1, 0] = j_all
    index_full = np.int32(index_full)

    return int_w01, int_w10, index_full, treat_val_list, treat_val_np


def grid_name(d_name: list[str] | tuple[str],
              add_name: str | int | float
              ) -> list[str]:
    """Help for initialisation."""
    grid_name_tmp = d_name[0] + str(add_name)
    grid_name_l = [grid_name_tmp.casefold()]

    return grid_name_l


def sub_size(n_train: int, share_mult: float, max_share: float | int) -> float:
    """Help for initialisation."""
    if share_mult is None or share_mult <= 0:
        share_mult = 1
    subsam_share = min(4 * ((n_train / 2)**0.85) / n_train, 0.67) * share_mult
    subsam_share = max(min(subsam_share, max_share), (2 * (n_train / 2)**0.5) / n_train)

    return subsam_share


def get_subsample_power_eval(power: float | int | None) -> float:
    """Resolve the filling exponent; 0.85 selects the relative-share rule used in version 0.10.0."""
    if power is None:
        return 0.90
    if isinstance(power, (bool, np.bool_)) or not isinstance(power, Real):
        raise TypeError('cf_subsample_power_eval must be a real number or None.')
    power_f = float(power)
    if not np.isfinite(power_f) or not 0.85 <= power_f <= 1.0:
        raise ValueError('cf_subsample_power_eval must be between 0.85 and 1, inclusive.')

    return power_f


def sub_size_eval(n_fill: int,
                  share_mult: float | int | bool | None,
                  share_forest: float,
                  power: float | int | None = None,
                  ) -> float:
    """Resolve the fraction of the available filling rows used by each tree.

    None or True selects factor 2. False or a numeric factor below 0.01
    requests every filling row. The exponent 0.85 preserves the
    factor-times-construction-share rule of version 0.10.0, including its rounding downstream.

    For larger exponents, use an independent filling power with scale
    (factor / 2) * 4**((1 - power) / 0.15). Factor 2 preserves the previous
    default full-filling threshold for equal construction/filling halves.
    Round the count, retaining at least one row and at most n_fill rows.
    """
    power_f = get_subsample_power_eval(power)
    if n_fill < 1:
        raise ValueError('The available filling sample must contain at least one row.')
    if share_mult is None or share_mult is True:
        factor = 2.0
    elif share_mult is False:
        return 1.0
    elif not isinstance(share_mult, Real):
        raise TypeError('cf_subsample_factor_eval must be a real number, bool or None.')
    else:
        factor = float(share_mult)
        if np.isnan(factor):
            raise ValueError('cf_subsample_factor_eval must not be NaN.')
        if factor < 0.01:
            return 1.0
    if power_f == 0.85:
        return float(min(share_forest * factor, 1.0))

    scale = 4.0**((1.0 - power_f) / 0.15)
    share = min((factor / 2.0) * scale * n_fill**(power_f - 1.0), 1.0)
    n_selected = min(n_fill, max(1, round(n_fill * share)))

    return n_selected / n_fill


def bootstrap(se_boot: int | None, cut_off: int, bnr: int, cluster_std: bool,) -> int | bool:
    """Check and correct bootstrap level."""
    if se_boot is None:
        se_boot = bnr if cluster_std else False
    if 0 < se_boot < cut_off:
        return bnr
    if se_boot >= cut_off:
        return round(se_boot)

    return False


def reduce_effective_n_train(mcf_: 'ModifiedCausalForest', n_train: int) -> int:
    """Compute effective training sample size."""
    if mcf_.fs_cfg.yes and mcf_.fs_cfg.other_sample:
        n_train *= 1 - mcf_.fs_cfg.other_sample_share
    if mcf_.cs_cfg.type_ > 0 and not mcf_.lc_cfg.cs_cv:
        n_train *= (1 - mcf_.lc_cfg.cs_share)
    if mcf_.lc_cfg.yes and not mcf_.lc_cfg.cs_cv:
        n_train *= (1 - mcf_.lc_cfg.cs_share)

    return int(n_train)


def get_chunks_maxsize_forest(base_level: int, obs: int, no_of_treat: int) -> int:
    """Compute optimal chunksize for forest splitting."""
    return round(base_level + (max(obs - base_level, 0) ** 0.8) / (no_of_treat - 1))


def var_helper(var_cfg: 'VarCfg') -> tuple[Any, Any, Any]:
    """Remove unncessary elements from var_cfg."""
    gen_cfg = deepcopy(var_cfg.gen_cfg)
    p_cfg = deepcopy(var_cfg.p)
    var_cfg.gen_cfg = var_cfg.p = None  # Not needed as part of var_cfg

    return gen_cfg, p_cfg, var_cfg


def isinstance_scalar(data: Any) -> bool:
    """Check if the input data is a scalar."""
    scalar_types = (float, int, np.floating, np.integer,)

    return isinstance(data, scalar_types)
