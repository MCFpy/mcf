"""
Contains functions for common support adjustments.

Created on Thu May 11 16:30:11 2023

@author: MLechner
# -*- coding: utf-8 -*-
"""
from math import floor
from typing import Any, TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray
import pandas as pd
try:
    import ray
except ImportError:
    ray = None

from sklearn.base import BaseEstimator
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, r2_score

from mcf import mcf_forest_add as mcf_fo_add
from mcf import mcf_forest_data as mcf_data
from mcf.mcf_forest_splitting import oob_in_tree
from mcf import mcf_general as mcf_gp
from mcf import mcf_general_sys as mcf_sys
from mcf import mcf_print_stats as mcf_ps
from mcf import mcfoptp_parallel_backend_ray_classical as mcf_ray
from mcf.mcfoptp_parallel_backend_forest_executor import (forest_executor_with_shared,
                                                          forest_executor_context,
                                                          map_task_batches,
                                                          )
from mcf.mcfoptp_parallel_backends_base import TaskSpec, print_runtime_info

if TYPE_CHECKING:
    from mcf.mcf_main import ModifiedCausalForest
    from mcf.mcf_init import GenCfg, IntCfg
    from mcf.mcf_init_train import CfCfg


def variable_importance(mcf_: 'ModifiedCausalForest',
                        data_df: pd.DataFrame,
                        forest: list[dict],
                        x_name_mcf: list[str]
                        ) -> None:
    """Compute variable importance measure.

    Parameters
    ----------
    mcf_ : mcf object.
    data_df : DataFrame.
    forest : Estimated forest.
    x_name_mcf : List. Variable names from MCF procedure


    Returns
    -------
    vim : Dictionary. Variable importance measures and names of variable

    Procedure:
    a) Predict Total of OOB of estimated forest_est (should already be there)
    b) For each variable, randomize one or groups of covariates
    c) recompute OOB-MSE with the ys of these more noisy variables

    Use multiprocessing in new oob prediction in the same way as in forest
    Building
    Outer loop over variables and group of variables
        Inner loop: Loop over trees
            Initially take out the indices of leaf 0 [16]--> OOB data
            For every observation determine it terminal leaf
                - save index together with number of terminal leaf
            For all terminal leaves compute OOB prediction

    """
    int_cfg, gen_cfg = mcf_.int_cfg, mcf_.gen_cfg
    cuda, cython = int_cfg.cuda, int_cfg.cython
    if gen_cfg.with_output and gen_cfg.verbose:
        txt = '\nVariable importance measures (OOB data)\nSingle variables'
        mcf_ps.print_mcf(gen_cfg, txt, summary=True)
    (x_name, _, _, cf_cfg, _, data_np, y_i, y_nn_i, x_i, _, _, d_i, w_i, _, _
     ) = mcf_data.prepare_data_for_forest(mcf_, data_df)
    no_of_vars = len(x_name)
    partner_k = determine_partner_k(x_name)
    # Loop over all variables to get respective OOB values of MSE
    if x_name != x_name_mcf:
        raise ValueError('Wrong order of variable names', x_name, x_name_mcf)
    number_of_oobs = 1 + no_of_vars
    oob_values = [None for _ in range(number_of_oobs)]
    if gen_cfg.mp_parallel < 1.5:
        maxworkers = 1
    else:
        if gen_cfg.mp_automatic:
            maxworkers = mcf_sys.find_no_of_workers(gen_cfg.mp_parallel, gen_cfg.sys_share,
                                                    zero_tol=int_cfg.zero_tol,
                                                    )
        else:
            maxworkers = gen_cfg.mp_parallel

    print_runtime_info(gen_cfg, int_cfg, maxworkers, txt_method='variable importance')

    if maxworkers > 1 and int_cfg.mp_use_old_ray:
        if ray is None or ray_get_oob_mcf is None:
            raise ImportError('int_cfg.mp_use_old_ray=True, but ray is not installed. '
                              'Install ray or use the new backend with mp_use_old_ray=False.'
                              )
        if not ray.is_initialized():
            mcf_ray.init_ray_with_fallback(maxworkers, gen_cfg,
                                           mem_object_store=int_cfg.mem_object_store_2,
                                           mem_object_store_2=int_cfg.mem_object_store_2,
                                           ray_err_txt='Ray does not start up in variable '
                                           'importance computation.'
                                           )
        mcf_ray.print_object_store(gen_cfg, int_cfg.mem_object_store_2)
        data_np_ref, forest_ref = mcf_ray.ray_put_all(data_np, forest)

    kw_args = {'y_i': y_i, 'y_nn_i': y_nn_i, 'x_i': x_i, 'd_i': d_i, 'w_i': w_i, 'gen_cfg': gen_cfg,
               'int_cfg': int_cfg, 'cf_cfg': cf_cfg, 'single': True, 'group_ind_list': [],
               'cuda': cuda, 'cython': cython, 'zero_tol': int_cfg.zero_tol,
               }
    if maxworkers == 1:
        for jdx in range(number_of_oobs):
            oob_values[jdx], _ = get_oob_mcf(data_np,
                                             k=jdx, forest=forest, no_mp=False,
                                             partner_k=partner_k[jdx],
                                             **kw_args,
                                             )
            mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                         current_idx=jdx+1, total=number_of_oobs,
                                         )
    else:  # Fast but needs a lot of memory because it copies a lot
        if int_cfg.mp_use_old_ray:
            maxworkers = min(maxworkers, number_of_oobs)
            still_running = [ray_get_oob_mcf.remote(data_np_ref,
                                                    k=idx, forest=forest_ref, no_mp=True,
                                                    partner_k=partner_k[idx],
                                                    **kw_args,
                                                    )
                             for idx in range(number_of_oobs)
                             ]
            jdx = 0
            while len(still_running) > 0:
                finished, still_running = ray.wait(still_running, num_returns=1)
                finished_res = ray.get(finished)
                for res in finished_res:
                    iix = res[1]
                    oob_values[iix] = res[0]
                    mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                                 current_idx=jdx+1, total=number_of_oobs,
                                                 )
                    jdx += 1
        else:
            maxworkers = min(maxworkers, number_of_oobs)

            shared_oob_data = {'data_np': data_np, 'forest': forest}

            with forest_executor_with_shared(int_cfg=int_cfg,
                                             maxworkers=maxworkers,
                                             shared_obj=shared_oob_data,
                                             shared_name='oob_data',
                                             ray_err_txt='Ray does not start in OOB estimation.',
                                             fail_txt='Failed to make executor in OOB estimation.',
                                             ) as (executor, data_handle, maxworkers):
                tasks = [TaskSpec(func=get_oob_mcf_backend,
                                  kwargs={'data': data_handle,
                                          'k': idx,
                                          'partner_k': partner_k[idx],
                                          'kw_args': kw_args,
                                          },
                                  name=f'oob_{idx}',
                                  )
                         for idx in range(number_of_oobs)
                         ]
                jdx = 0
                for res in map_task_batches(executor=executor, tasks=tasks, int_cfg=int_cfg,
                                            maxworkers=maxworkers,
                                            min_worker_waves = (4 if int_cfg.mp_backend == 'joblib'
                                                                else 1
                                                                ),
                                            ):
                    iix = res[1]
                    oob_values[iix] = res[0]

                    jdx += 1
                    mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                                 current_idx=jdx, total=number_of_oobs,
                                                 )
    oob_values = np.array(oob_values)
    oob_values = oob_values.reshape(-1)
    mse_ref = oob_values[0]   # reference value
    vim, txt = vim_print(mse_ref, oob_values[1:], x_name=x_name, ind_list=0,
                         with_output=gen_cfg.with_output, single=True, partner_k=partner_k
                         )
    if gen_cfg.with_output:
        mcf_ps.print_mcf(gen_cfg, txt, summary=True)
    # Variables are grouped
    no_g, no_m_g = number_of_groups_vi(no_of_vars)
    partner_k = None
    if no_g > 0:
        if gen_cfg.with_output:
            print('\nGroups of variables')
        ind_groups = vim_grouping(vim, no_g)
        n_g = len(ind_groups)
        oob_values = [None for _ in range(n_g)]
        kw_args = {'y_i': y_i, 'y_nn_i': y_nn_i, 'x_i': x_i, 'd_i': d_i, 'w_i': w_i,
                   'gen_cfg': gen_cfg, 'int_cfg': int_cfg, 'cf_cfg': cf_cfg, 'single': False,
                   'group_ind_list': ind_groups, 'partner_k': partner_k, 'cuda': cuda,
                   'cython': cython, 'zero_tol': int_cfg.zero_tol,
                   }
        if maxworkers > 1:
            if int_cfg.mp_use_old_ray:
                still_running = [ray_get_oob_mcf.remote(data_np_ref,
                                                        k=idx, forest=forest_ref, no_mp=True,
                                                        **kw_args,
                                                        )
                                 for idx in range(n_g)
                                 ]
                idx = 0
                while len(still_running) > 0:
                    finished, still_running = ray.wait(still_running, num_returns=1)
                    finished_res = ray.get(finished)
                    for res in finished_res:
                        iix = res[1]
                        oob_values[iix] = res[0]
                        mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                                     current_idx=idx+1, total=n_g,
                                                     )
                        idx += 1
            else:
                shared_oob_data = {'data_np': data_np, 'forest': forest,}

                with forest_executor_context(int_cfg=int_cfg, maxworkers=maxworkers,
                                             ray_err_txt='Ray does not start in OOB estimation.',
                                             fail_txt='Failed to make executor in OOB estimation.',
                                             ) as (executor, maxworkers):
                    data_np_handle_2 = executor.put_shared(data_np, name='oob_data_np')
                    forest_handle_2 = executor.put_shared(forest, name='oob_forest')

                    tasks = [TaskSpec(func=get_oob_mcf_backend_2,
                                      kwargs={'data_np': data_np_handle_2,
                                              'forest': forest_handle_2,
                                              'k': idx,
                                              'kw_args': kw_args,
                                              },
                                      name=f'oob_{idx}',
                                      )
                             for idx in range(n_g)
                             ]
                    idx = 0
                    for res in map_task_batches(executor=executor, tasks=tasks, int_cfg=int_cfg,
                                                maxworkers=maxworkers,
                                                min_worker_waves = (
                                                    4 if int_cfg.mp_backend == 'joblib' else 1),
                                                ):
                        iix = res[1]
                        oob_values[iix] = res[0]

                        idx += 1
                        mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                                     current_idx=idx, total=n_g,
                                                     )
        else:
            for idx in range(n_g):
                oob_values[idx], _ = get_oob_mcf(data_np,
                                                 k=idx, forest=forest, no_mp=False,
                                                 **kw_args,
                                                 )
                mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                             current_idx=idx+1, total=n_g,
                                             )
        vim_g, txt = vim_print(mse_ref, np.array(oob_values),
                               x_name=x_name, ind_list=ind_groups, with_output=gen_cfg.with_output,
                               single=False,
                               )
        if gen_cfg.with_output:
            mcf_ps.print_mcf(gen_cfg, txt, summary=True)
    else:
        vim_g = None
    # Groups are accumulated from worst to best
    if no_m_g > 0:
        if gen_cfg.with_output:
            mcf_ps.print_mcf(gen_cfg, '\nMerged groups of variables', summary=True)
        ind_groups = vim_grouping(vim_g, no_m_g, True)
        n_g = len(ind_groups)
        oob_values = [None for _ in range(n_g)]
        kw_args = {'y_i': y_i, 'y_nn_i': y_nn_i, 'x_i': x_i, 'd_i': d_i, 'w_i': w_i,
                   'gen_cfg': gen_cfg, 'int_cfg': int_cfg, 'cf_cfg': cf_cfg, 'single': False,
                   'group_ind_list': ind_groups, 'partner_k': partner_k, 'cuda': cuda,
                   'cython': cython, 'zero_tol': int_cfg.zero_tol,
                   }
        if maxworkers > 1:
            if int_cfg.mp_use_old_ray:
                still_running = [ray_get_oob_mcf.remote(data_np_ref,
                                                        k=idx, forest=forest_ref, no_mp=True,
                                                        **kw_args,
                                                        )
                                 for idx in range(n_g)
                                 ]
                idx = 0
                while len(still_running) > 0:
                    finished, still_running = ray.wait(still_running, num_returns=1)
                    finished_res = ray.get(finished)
                    for res in finished_res:
                        iix = res[1]
                        oob_values[iix] = res[0]
                        mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                                     current_idx=idx+1, total=n_g,
                                                     )
                        idx += 1
            else:
                # shared_oob_data_ng = {'data_np': data_np, 'forest': forest,}
                ray_err_txt='Ray does not start in OOB estimation (n_g variant).'
                fail_txt='Failed to make executor in OOB estimation (n_g variant).'
                with forest_executor_context(int_cfg=int_cfg, maxworkers=maxworkers,
                                             ray_err_txt=ray_err_txt, fail_txt=fail_txt,
                                             ) as (executor, maxworkers):

                    data_np_handle_ng = executor.put_shared(data_np, name='oob_data_np_ng')
                    forest_handle_ng = executor.put_shared(forest, name='oob_forest_ng')

                    tasks = [TaskSpec(func=get_oob_mcf_backend_ng,
                                      kwargs={'data_np': data_np_handle_ng,
                                              'forest': forest_handle_ng,
                                              'k': idx,
                                              'kw_args': kw_args,
                                              },
                                      name=f'oob_ng_{idx}',
                                      )
                             for idx in range(n_g)
                             ]
                    idx = 0
                    for res in map_task_batches(executor=executor, tasks=tasks, int_cfg=int_cfg,
                                                maxworkers=maxworkers,
                                                min_worker_waves = (
                                                    4 if int_cfg.mp_backend == 'joblib' else 1
                                                    ),
                                                ):
                        iix = res[1]
                        oob_values[iix] = res[0]

                        idx += 1
                        mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                                     current_idx=idx, total=n_g,
                                                     )
        else:
            for idx in range(n_g):
                oob_values[idx], _ = get_oob_mcf(data_np, k=idx, forest=forest, no_mp=False,
                                                 **kw_args,
                                                 )
                mcf_gp.progress_clean_memory(output=gen_cfg.with_output and gen_cfg.verbose,
                                             current_idx=idx+1, total=n_g,
                                             )
        _, txt = vim_print(mse_ref, np.array(oob_values),
                           x_name=x_name, ind_list=ind_groups, with_output=gen_cfg.with_output,
                           single=False
                           )
        # vim_mg
        if gen_cfg.with_output:
            mcf_ps.print_mcf(gen_cfg, txt, summary=True)

    if (maxworkers > 1
        and int_cfg.mp_use_old_ray
        and ray is not None
            and ray_get_oob_mcf is not None
            ):
        (data_np_ref, forest_ref, finished_res, finished     # pylint: disable=W0632
         ) = mcf_ray.ray_del_refs(data_np_ref, forest_ref,
                                  f1=finished_res, f2=finished, mp_ray_del=int_cfg.mp_ray_del,
                                  )


def get_oob_mcf_backend(*, data: dict[str, Any],
                        k: int,
                        partner_k: Any,
                        kw_args: dict[str, Any],
                        ) -> Any:
    """Backend-agnostic wrapper for one OOB task."""
    return get_oob_mcf(data['data_np'],
                       k=k, forest=data['forest'], no_mp=True, partner_k=partner_k,
                       **kw_args,
                       )


def get_oob_mcf_backend_2(*, data_np: Any, forest: Any, k: int, kw_args: dict[str, Any],) -> Any:
    """Backend-agnostic wrapper for one OOB task."""
    return get_oob_mcf(data_np, k=k, forest=forest, no_mp=True, **kw_args,)


def get_oob_mcf_backend_ng(*, data_np: Any, forest: Any, k: int, kw_args: dict[str, Any],) -> Any:
    """Backend-agnostic wrapper for one OOB task (n_g variant) (same as get_oob_mcf_backend_2)."""
    return get_oob_mcf(data_np, k=k, forest=forest, no_mp=True, **kw_args,)



def vim_grouping(vim: tuple[NDArray], no_groups: int, accu: bool = False,) -> list[list[int]]:
    """Group variables according to their variable importance measure.

    Parameters
    ----------
    vim : Tuple (Numpy array list of INT). Relative vim and index.
    no_groups : INT. No of groups.
    accu : Bool. Build groups by accumulation. Default = False.

    Returns
    -------
    ind_groups : List of list of INT. Grouping of indices.

    """
    indices = vim[1]
    no_ind = len(indices)
    if not accu:
        group_size = no_ind / no_groups
        group_size_int = floor(group_size)
        one_more, start_i, ind_groups = 0, 0, []
    else:
        group_size_int = None
    for idx in range(no_groups):
        if accu:
            if idx < 2:
                ind_groups = [indices[0], indices[0] + indices[idx]]
            else:
                new_group = ind_groups[idx-1] + indices[idx]
                ind_groups.append(new_group)
        else:
            if idx == (no_groups - 1):
                end_i = no_ind - 1
            else:
                end_i = start_i + group_size_int - 1
                one_more += group_size - group_size_int
                if one_more >= 1:
                    one_more -= 1
                    end_i += 1
            ind_groups.append(indices[start_i:end_i+1])
            start_i = end_i + 1

    return ind_groups


def number_of_groups_vi(no_x_names: int) -> tuple[int, int]:
    """Determine no of groups for groupwise variable importance measure.

    Parameters
    ----------
    no_x_names :INT. No of variables considered in analysis.

    Returns
    -------
    groups : INT.
    merged_groups : INT.

    """
    match no_x_names:
        case n if n >= 100:      groups, merged_groups = 20, 19
        case n if 20 <= n < 100: groups, merged_groups = 10, 9
        case n if 10 <= n < 20:  groups, merged_groups = 5, 4
        case n if 4 <= n < 10:   groups, merged_groups = 2, 0
        case _:                  groups, merged_groups = 0, 0

    return groups, merged_groups


def vim_print(mse_ref: np.floating,
              mse_values: NDArray[Any],
              x_name: list[str], *,
              ind_list: list[int] | int = 0,
              with_output: bool = True,
              single: bool = True,
              partner_k: list[int | None] | None = None
              ) -> tuple[NDArray[Any]]:
    """Print Variable importance measure and create sorted output.

    Parameters
    ----------
    mse_ref : Numpy Float. Reference value of non-randomized x.
    mse_values : Numpy array. MSE's for randomly permuted x.
    x_name : List of strings. Variable names.
    ind_list : List of INT, optional. Variable positions. Default is 0.
    with_output : Boolean, optional. Default is True.
    single : Boolean, optional. The default is True.
    partner_k : List of None and Int or None. Index of variables that were
                jointly randomized. Default is None.

    Returns
    -------
    vim: Tuple of Numpy array and list of lists. MSE sorted and sort index.

    """
    if partner_k is not None:
        for idx, val in enumerate(partner_k):
            if val is not None:
                if (idx > (val-1)) and (idx > 0):
                    mse_values[idx-1] = mse_values[val-1]
    mse = mse_values / np.array(mse_ref) * 100
    var_indices = np.argsort(mse)
    var_indices = np.flip(var_indices)
    vim_sorted = mse[var_indices]
    if single:
        x_names_sorted = np.array(x_name, copy=True)
        x_names_sorted = x_names_sorted[var_indices]
        ind_sorted = list(var_indices)
    else:
        var_indices = list(var_indices)
        ind_sorted = []
        x_names_sorted = []
        for i in var_indices:
            ind_i = ind_list[i]
            ind_sorted.append(ind_i)
            x_name_i = [x_name[j] for j in ind_i]
            x_names_sorted.append(x_name_i)
    txt = ''
    if with_output:
        txt += '\n' * 2 + '-' * 100 + f'\nOut of bag MSE: {mse_ref:8.3f}'
        txt += '\n' + '- ' * 50
        txt += '\nVariable importance statistics in %-lost of base value'
        for idx, vim in enumerate(vim_sorted):
            if single:
                txt += f'\n{x_names_sorted[idx]:<50}: {vim-100:>7.4f}%'
            else:
                var_str = ' '.join(x_names_sorted[idx])
                txt += f'\n{var_str:<80s}: {vim-100:>7.4f}%'
        txt += '\n' + '- ' * 50
        txt += ('\nComputed as share of OOB MSE of estimated forest relative to OOB MSE of'
                '\nvariable (or group of variables) with randomized covariate values in %.'
                )
    ind_sorted.reverse()
    vim_sorted = np.flip(vim_sorted)
    vim = (vim_sorted, ind_sorted)
    if with_output:
        first_time = True
        if partner_k is not None:
            for idx, val in enumerate(partner_k):
                if val is not None:
                    if first_time:
                        txt += ('\nThe following variables are jointly'
                                ' analysed: ')
                        first_time = False
                    if idx < val:
                        txt += x_name[idx-1] + ' ' + x_name[val-1] + ' / '
        txt += '\n' + '-' * 100
    return vim, txt


# @ray.remote
def _ray_get_oob_mcf_impl(data_np: NDArray[Any], *,
                          y_i: int,
                          y_nn_i: NDArray[Any],
                          x_i: NDArray[Any],
                          d_i: int,
                          w_i: int,
                          gen_cfg: 'GenCfg', int_cfg: 'IntCfg', cf_cfg: 'CfCfg',
                          k: int,
                          single: bool,
                          group_ind_list: list[list[int]],
                          forest: list[dict],
                          no_mp=False,
                          partner_k=None,
                          cuda=False,
                          cython=True,
                          zero_tol: float = 1e-10,
                          ) -> Any:
    """Make function usable for Ray."""
    return get_oob_mcf(data_np,
                       y_i=y_i, y_nn_i=y_nn_i, x_i=x_i, d_i=d_i, w_i=w_i, gen_cfg=gen_cfg,
                       int_cfg=int_cfg, cf_cfg=cf_cfg, k=k, single=single,
                       group_ind_list=group_ind_list, forest=forest, no_mp=no_mp,
                       partner_k=partner_k, cuda=cuda, cython=cython, zero_tol=zero_tol,
                       )


ray_get_oob_mcf = ray.remote(_ray_get_oob_mcf_impl) if ray is not None else None


def get_oob_mcf(data_np: NDArray[Any], *,
                y_i: int,
                y_nn_i: NDArray[Any],
                x_i: NDArray[Any],
                d_i: int,
                w_i: int,
                gen_cfg: 'GenCfg', int_cfg: 'IntCfg', cf_cfg: 'CfCfg',
                k: int,
                single: bool,
                group_ind_list: list[list[int]],
                forest: list[dict],
                no_mp: bool = False,
                partner_k: int | None = None,
                cuda: bool = False,
                cython: bool = True,
                zero_tol: float = 1e-10,
                ) -> tuple[float | np.floating, int]:
    """Get the OOB value of a forest.

    Parameters
    ----------
    data_np : Numpy array. Data
    y_i : INT. Position in data_np.
    y_nn_i : Numpy array.
    x_i : Numpy array.
    d_i : INT.
    w_i : INT.
    gen_cfg, GenCfg. Dataclasses. Parameters.
    cf_cfg : CfCfg dataclass.
    k: INT. Number of groups/variables.
    single : Bool. Single variable.
    group_ind_list : List of Lists of Int.
    forest : List of Dicts. Estimated Trees in dictionary form.
    no_mp : Bool. No multiprocessing.  Default is False.
    partner_k : For single variables only: Allows to jointly randomize another
                single variables that strongly covaries with variable k.
    cuda : Boolean. Use GPU.

    Returns
    -------
    oob_value : Float. MSE based on out-of-bag observations.
    k: INT. Number of groups/variables.

    """
    oob_value = 0
    if gen_cfg.mp_parallel < 1.5 or no_mp:
        maxworkers = 1
    else:
        if gen_cfg.mp_automatic:
            maxworkers = mcf_sys.find_no_of_workers(gen_cfg.mp_parallel, gen_cfg.sys_share,
                                                    zero_tol=int_cfg.zero_tol,
                                                    )
        else:
            maxworkers = gen_cfg.mp_parallel
    if gen_cfg.with_output and not no_mp and gen_cfg.verbose:
        mcf_ps.print_mcf(gen_cfg, f'Number of parallel processes (VI): {maxworkers}', summary=False)
    if (maxworkers == 1) or no_mp:
        for idx in range(cf_cfg.boot):
            data_np_oob = data_np[forest[idx]['oob_indices']]
            oob_tree = get_oob_mcf_b(data_np_oob,
                                     y_i=y_i, y_nn_i=y_nn_i, x_i=x_i, d_i=d_i, w_i=w_i,
                                     gen_cfg=gen_cfg, cf_cfg=cf_cfg, k=k, single=single,
                                     group_ind_list=group_ind_list, tree_dict=forest[idx],
                                     partner_k=partner_k, cuda=cuda, cython=cython,
                                     zero_tol=int_cfg.zero_tol
                                     )
            oob_value += oob_tree
    else:
        if int_cfg.mp_weights_tree_batch > 1:  # User defined # of batches
            no_of_boot_splits = int_cfg.mp_weights_tree_batch
            split_forest = True
        elif int_cfg.mp_weights_tree_batch == 0:  # Automatic no. of batches
            size_of_forest_mb = mcf_sys.total_size(forest) / (1024 * 1024)
            no_of_boot_splits, txt = mcf_sys.no_of_boot_splits_fct(size_of_forest_mb, maxworkers)
            if gen_cfg.with_output and gen_cfg.verbose:
                mcf_ps.print_mcf(gen_cfg, txt, summary=False)
            split_forest = bool(no_of_boot_splits < cf_cfg.boot)
        else:
            split_forest = False
        if split_forest and gen_cfg.with_output and gen_cfg.verbose:
            txt = f'Number of tree chuncks: {no_of_boot_splits:5d}'
            mcf_ps.print_mcf(gen_cfg, txt, summary=False)
        if split_forest:
            b_ind_list = np.array_split(range(cf_cfg.boot),
                                        no_of_boot_splits)
            for idx, b_ind in enumerate(b_ind_list):
                forest_temp = forest[b_ind[0]:b_ind[-1]+1]
                oob_value += get_oob_mcf_chuncks(data_np,
                                                 y_i=y_i, y_nn_i=y_nn_i, x_i=x_i, d_i=d_i, w_i=w_i,
                                                 gen_cfg=gen_cfg, cf_cfg=cf_cfg, k=k, single=single,
                                                 group_ind_list=group_ind_list,
                                                 tree_dics=forest_temp, index_list=b_ind,
                                                 partner_k=partner_k, cuda=cuda, cython=cython,
                                                 zero_tol=zero_tol
                                                 )
    oob_value = oob_value / cf_cfg.boot

    return oob_value, k


def get_oob_mcf_chuncks(data: NDArray[Any], *,
                        y_i: int,
                        y_nn_i: NDArray[Any],
                        x_i: NDArray[Any],
                        d_i: int,
                        w_i: int,
                        gen_cfg: 'GenCfg', cf_cfg: 'CfCfg',
                        k: int,
                        single: bool,
                        group_ind_list: list[list[int]],
                        tree_dics: list[dict],
                        index_list: list,
                        partner_k: int | None = None,
                        cuda: bool = False,
                        cython: bool = True,
                        zero_tol: float = 1e-10,
                        ) -> float | np.floating:
    """Compute OOB value in chuncks."""
    oob_value = 0
    for idx, _ in enumerate(index_list):
        data_np_oob = data[tree_dics[idx]['oob_indices']]
        oob_value += get_oob_mcf_b(data_np_oob,
                                   y_i=y_i, y_nn_i=y_nn_i, x_i=x_i, d_i=d_i, w_i=w_i,
                                   gen_cfg=gen_cfg, cf_cfg=cf_cfg, k=k, single=single,
                                   group_ind_list=group_ind_list, tree_dict=tree_dics[idx],
                                   partner_k=partner_k, cuda=cuda, cython=cython, zero_tol=zero_tol,
                                   )
    return oob_value


def get_oob_mcf_b(data: NDArray[Any], *,
                  y_i: int,
                  y_nn_i: NDArray[Any],
                  x_i: NDArray[Any],
                  d_i: int,
                  w_i: int,
                  gen_cfg: 'GenCfg', cf_cfg: 'CfCfg',
                  k: int,
                  single: bool,
                  group_ind_list: list[list[int]],
                  tree_dict: dict,
                  partner_k: int | None = None,
                  cuda: bool = False,
                  cython: bool = True,
                  zero_tol: float = 1e-10,
                  ) -> float | np.floating:
    """Generate OOB contribution for single bootstrap."""
    x_dat, y_dat = data[:, x_i].copy(), data[:, y_i]
    y_nn = data[:, y_nn_i]
    d_dat = np.int32(np.round(data[:, d_i]))
    w_dat = data[:, [w_i]] if gen_cfg.weighted else None
    obs = len(y_dat)
    rng = np.random.default_rng(seed=55436356)
    if not (single and (k == 0)):
        if single:
            rng.shuffle(x_dat[:, k-1])
            if partner_k is not None:   # Randomises variable related to k-1
                rng.shuffle(x_dat[:, partner_k-1])
        else:
            rand_ind = np.arange(obs)
            rng.shuffle(rand_ind)
            for i in group_ind_list[k]:
                x_dat[:, i] = x_dat[rand_ind, i]
    obs_in_leaf = np.empty((obs, 2), dtype=np.uint32)
    for idx in range(obs):
        leaf_no = mcf_fo_add.get_terminal_leaf_no(tree_dict, x_dat[idx, :], zero_tol=zero_tol,)
        obs_in_leaf[idx, 0], obs_in_leaf[idx, 1] = idx, leaf_no
    oob_tree = oob_in_tree(obs_in_leaf, y_dat, y_nn, d_dat, w_dat,
                           mtot=cf_cfg.mtot, no_of_treat=gen_cfg.no_of_treat,
                           treat_values=gen_cfg.d_values, w_yes=gen_cfg.weighted,
                           cont=gen_cfg.d_type == 'continuous', cuda=cuda, cython=cython,
                           compare_only_to_zero=cf_cfg.compare_only_to_zero, zero_tol=zero_tol,
                           )
    return oob_tree


def determine_partner_k(x_name: list[str]):
    """Find variable that is descretized equivalent to other variable.

    Parameters
    ----------
    x_name : List of str. Variable names to check.

    Returns
    -------
    partner_k : List of int. Contains either index (+1) of partner or None.

    """
    no_of_vars = len(x_name)
    partner_k = [None for _ in range((no_of_vars + 1))]
    x_partner_name = [None for _ in range(no_of_vars + 1)]
    for idx, val in enumerate(x_name):  # check if it ends with catv & remove
        if len(val) > 4:
            if val.endswith('catv'):
                x_partner_name[idx+1] = val[:-4]
    for idx, val in enumerate(x_name):
        for jdx, jval in enumerate(x_partner_name):
            if (val == jval) and (partner_k[idx+1] is None):
                partner_k[idx+1] = jdx
                partner_k[jdx] = idx + 1
                break
    return partner_k


def print_variable_importance(clas_obj: BaseEstimator,
                              x_df: pd.DataFrame,
                              y_df: pd.DataFrame, *,
                              x_name: list[str],
                              names_uo: list[str] | None,
                              unordered_dummy_names: list[str] | None,
                              gen_cfg: 'GenCfg',
                              summary: bool = False,
                              name_label_dict: dict | None = None,
                              obs_bigdata: int = 1_000_000,
                              classification: bool=False,
                              scaler: Any | None = None,
                              ) -> None:
    """Compute and print variable importance by permutation for CS."""    
    x_train_df, x_test_df, y_train_df, y_test_df = train_test_split(x_df, y_df,
                                                                    test_size=0.25, random_state=42,
                                                                    )
    x_train_np = mcf_gp.to_numpy_big_data(x_train_df, obs_bigdata)
    if scaler is not None:
        x_train_np = scaler.transform(x_train_np)

    y_train_np = mcf_gp.to_numpy_big_data(y_train_df, obs_bigdata).ravel()
    clas_obj.fit(x_train_np, y_train_np)
    x_test_np = mcf_gp.to_numpy_big_data(x_test_df, obs_bigdata)
    if scaler is not None:
        x_test_np = scaler.transform(x_test_np)

    y_test_np = mcf_gp.to_numpy_big_data(y_test_df, obs_bigdata)

    if classification:
        score_y_full = accuracy_score(y_test_np, clas_obj.predict(x_test_np), normalize=True)
        score_name = 'Accuracy score'
    else:
        score_y_full = r2_score(y_test_np, clas_obj.predict(x_test_np))
        score_name = 'R2'

    vi_information = pd.DataFrame(0, columns=x_name, index=['score_w/o_x_%', 'rel_diff_%'])
    for name in x_name:
        if names_uo is not None and name in names_uo:
            names_to_shuffle = unordered_dummy_names[name]
        else:
            names_to_shuffle = name
        x_all_rnd_df = x_test_df.copy().reset_index(drop=True)
        x_rnd_df = x_test_df[names_to_shuffle].sample(frac=1, random_state=42)
        x_all_rnd_df[names_to_shuffle] = x_rnd_df.reset_index(drop=True)
        y_pred_rnd = clas_obj.predict(mcf_gp.to_numpy_big_data(x_all_rnd_df, obs_bigdata))
        if classification:
            y_score = accuracy_score(y_test_np, y_pred_rnd, normalize=True)
        else:
            y_score = r2_score(y_test_np, y_pred_rnd)

        if np.isclose(score_y_full, 0.0):
            y_rel_diff = np.nan
        else:
            y_rel_diff = (score_y_full - y_score) / score_y_full

        vi_information[name] = [np.round(y_score * 100, 2), np.round(y_rel_diff * 100, 2)]
    if name_label_dict is not None:
        vi_information.rename(columns=name_label_dict, inplace=True)

    mcf_ps.print_mcf(gen_cfg,
                     '\n' + '-' * 100 +
                     '\nVariable importance statistics '
                     f'(as loss of {score_name} if one feature is randomized)'
                     '\n' + '- ' * 50 +
                     f'\n{score_name} based on all features: {score_y_full:6.2%} '
                     '\n' + '- ' * 50,
                     summary=summary
                     )
    with pd.option_context('display.max_rows', None,
                           'display.expand_frame_repr', True,
                           'chop_threshold', 1e-13):
        mcf_ps.print_mcf(gen_cfg, vi_information.transpose().sort_values(by=['rel_diff_%'],
                                                                         ascending=False),
                         summary=summary
                         )
