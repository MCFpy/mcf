"""
Created on Sat Jun 17 15:51:30 2023.

@author: MLechner

Contains the functions needed for computing the weights.

@author: MLechner
-*- coding: utf-8 -*-
"""
from copy import deepcopy
from pathlib import Path
from time import time
from typing import Any, Sequence, TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray
from pandas import DataFrame
from scipy import sparse
try:
    import ray
except (ImportError, OSError):
    ray = None
try:
    from tqdm.auto import tqdm
except ImportError:
    tqdm = None

from mcf import mcf_forest_add as mcf_fo_add
from mcf import mcf_general as mcf_gp
from mcf import mcf_general_sys as mcf_sys
from mcf import mcf_print_stats as mcf_ps
from mcf import mcfoptp_parallel_backend_ray_classical as mcf_ray
from mcf.mcfoptp_parallel_backend_forest_executor import (forest_executor_with_shared,
                                                          map_task_batches,
                                                          )
from mcf.mcfoptp_parallel_backends_base import TaskSpec, print_runtime_info

if TYPE_CHECKING:
    from mcf.mcf_init import GenCfg, IntCfg, CtGrid, VarCfg
    from mcf.mcf_init_train import CfCfg
    from mcf.mcf_init_predict import PCfg


def get_weights_mp(data_df: DataFrame,
                   forest_dic: dict, *,
                   gen_cfg: 'GenCfg',
                   var_cfg: 'VarCfg',
                   int_cfg: 'IntCfg',
                   cf_cfg: 'CfCfg',
                   ct_cfg: 'CtGrid',
                   p_cfg: 'PCfg',
                   gen_tv_cfg_yes: bool = False,
                   reg_round: str = 'regular',
                   with_output: bool = True,
                   print_progress: bool = True,
                   ) -> dict:
    """Get weights for obs in pred_data & outcome and cluster from y_data.

    Parameters
    ----------
    mcf_ : mcf-object.
    data_df : DataFrame: Prediction data.
    forstest_dic : Dict. Forest and Training data as DataFrame.
    reg_round : str. True if standard effects are estimated, False if
                         efficient effects are estimated.

    Returns
    -------
    weights_dic : Dict. Weights and training data as Numpy arrays.
    time : float.
    """
    start_time = time()
    print_yes = gen_cfg.with_output and gen_cfg.verbose and with_output

    if print_yes:
        print('\nObtaining weights from estimated forest')
    if int_cfg.weight_as_sparse_splits is None:
        if len(data_df) < 5000:
            int_cfg.weight_as_sparse_splits = 1
        else:
            base_dim = 25000
            int_cfg.weight_as_sparse_splits = round(
                len(forest_dic['y_train_df']) * len(data_df) / cf_cfg.folds / (base_dim ** 2)
                )
        int_cfg.weight_as_sparse_splits = max(int_cfg.weight_as_sparse_splits, 1)
    # Preserve split-variable precision independently of prediction chunk size.
    x_dat_all = data_df[var_cfg.x_name].to_numpy(copy=True)
    if p_cfg.bt_yes:
        balance_data = forest_dic['x_bala_df']
        balance_names = var_cfg.x_name_balance_test
        missing = [name for name in balance_names
                   if balance_data is None or name not in balance_data.columns]
        if missing:
            raise ValueError('Balancing variables are unavailable in the saved training data: '
                             f'{", ".join(missing)}. Retrain with these covariates retained.')
        if balance_data is None:
            raise ValueError('No balancing data were saved. Retrain with p_bt_yes=True.')
        forest_dic = forest_dic.copy()
        forest_dic['x_bala_df'] = balance_data.loc[:, balance_names]

    kw_args_w_inner = {'cf_cfg': deepcopy(cf_cfg), 'ct_cfg': ct_cfg, 'gen_cfg': gen_cfg,
                       'int_cfg': int_cfg, 'p_cfg': p_cfg, 'with_output': with_output,
                       'bigdata_train': int_cfg.bigdata_train, 'subtreatments': gen_tv_cfg_yes,
                       'print_progress': print_progress,
                       }
    if int_cfg.weight_as_sparse_splits == 1 or not int_cfg.weight_as_sparse:
        (weights, y_dat, x_bala, cl_dat, w_dat, prog_dat, prop_dat, x_ba_dat, d_dat_train,
         tv_x_dat_train,) = get_weights_mp_inner(forest_dic, x_dat_all, **kw_args_w_inner)
    else:
        unique_str = str(int(round(time() * 10000000)))
        temp_weight_name = 'temp_weights' + unique_str
        if gen_cfg.outpath is None or not gen_cfg.outpath.is_dir():
            base_name = Path(__file__).parent.absolute()
            base_file = base_name.with_name(f'{base_name.name} {temp_weight_name}')
        else:
            base_file = gen_cfg.outpath / temp_weight_name
        x_dat_list = np.array_split(x_dat_all, int_cfg.weight_as_sparse_splits, axis=0)
        no_x_bala_return = True
        f_name = []
        reference_duration = +np.inf if int_cfg.bigdata_train else None
        for idx, x_dat in enumerate(x_dat_list):  # Das ist der Mastersplit
            time_start = time() if int_cfg.bigdata_train else None
            if print_yes:
                time1 = time()
                print('\n\nWeights computation with additional splitting. ',
                      f'Mastersplit {idx+1} ({len(x_dat_list)}) '
                      '\nComputing weight matrix (inner loop).'
                      )
            if idx == len(x_dat_list) - 1:  # Last iteration, get x_bala
                no_x_bala_return = False

            (weights_i, y_dat, x_bala, cl_dat, w_dat, prog_dat, prop_dat, x_ba_dat, d_dat_train,
             tv_x_dat_train,) = get_weights_mp_inner(forest_dic, x_dat,
                                                     **kw_args_w_inner,
                                                     no_x_bala_return=no_x_bala_return,
                                                     )
            if print_yes:
                print('\nComputing weight matrix (inner loop) took '
                      f'{int(round((time() - time1) / 60))} minutes.'
                      )
            f_name_i = []
            if int_cfg.weight_as_sparse_splits > 1:
                time1 = time()
                elem_per_chunk = len(weights_i)
                if print_yes:
                    print('Saving temporary weight matrix to harddrive.')
                for d_idx, weight_di in enumerate(weights_i):
                    f_name_d_idx = base_file.parent / (base_file.name + f'{idx}_{d_idx}.npz')
                    mcf_sys.delete_file_if_exists(f_name_d_idx)
                    sparse.save_npz(f_name_d_idx, weight_di)
                    f_name_i.append(f_name_d_idx)
                f_name.append(f_name_i)
                del weights_i
                if print_yes:
                    print('Saving temporary weight matrix to harddrive took '
                          f'{int(round((time()-time1)/60))} minutes.'
                          )
            else:
                weights = weights_i

            if int_cfg.bigdata_train and (int_cfg.mp_use_old_ray or int_cfg.mp_backend == 'ray'):
                duration = time() - time_start
                reference_duration, _ = mcf_ray.check_ray_shutdown_legacy(
                    gen_cfg, reference_duration, duration, gen_cfg.mp_parallel,
                    max_multiplier=5,
                    with_output=gen_cfg.with_output and gen_cfg.verbose and with_output,
                    err_txt='\nProblem in weight computation (outer function): ',
                    )
            else:
                duration = None
        del x_dat_list, x_dat_all
        if int_cfg.weight_as_sparse_splits > 1:
            weights = []
            for d_idx in range(elem_per_chunk):
                w_list = []
                for idx in range(int_cfg.weight_as_sparse_splits):
                    file_to_load = f_name[idx][d_idx]
                    w_list.append(sparse.load_npz(file_to_load))
                    mcf_sys.delete_file_if_exists(file_to_load)
                w_all = sparse.vstack(w_list)
                weights.append(w_all)
            del w_all, w_list

    no_of_treat = len(ct_cfg.grid_w_val) if gen_cfg.d_type == 'continuous' else gen_cfg.no_of_treat
    txt = mcf_sys.print_size_weight_matrix(weights, int_cfg.weight_as_sparse, no_of_treat)

    runde = 2 - int(reg_round) if isinstance(reg_round, bool) else 2 - int(reg_round == 'regular')

    if print_yes:
        mcf_ps.print_mcf(gen_cfg, f'Round {runde}. ' + txt, summary=False)
        if int_cfg.memory_print:
            mcf_sys.print_mememory_statistics(gen_cfg, 'Prediction: End of weights estimation')

    return ({'weights': weights,
            'y_dat_np': y_dat, 'x_bala_np': x_bala, 'cl_dat_np': cl_dat, 'w_dat_np': w_dat,
            'prog_dat_np': prog_dat, 'prop_dat_np': prop_dat,
            'x_ba_dat': x_ba_dat, 'd_dat': d_dat_train, 'x_tv_df': tv_x_dat_train,
            },
            time() - start_time,
            )


def get_weights_mp_inner(forest_dic: dict,
                         x_dat: NDArray[Any], *,
                         cf_cfg: 'CfCfg', ct_cfg: 'CtGrid', gen_cfg: 'GenCfg', int_cfg: 'IntCfg',
                         p_cfg: 'PCfg',
                         no_x_bala_return: bool = False,
                         with_output: bool = True,
                         bigdata_train: bool = False,
                         subtreatments: bool = False,
                         print_progress: bool = True,
                         ) -> tuple[tuple[list],
                                    NDArray[Any],
                                    NDArray[Any] | None, NDArray[Any] | None,
                                    NDArray[Any] | None, NDArray[Any] | None,
                                    NDArray[Any] | None, NDArray[Any] | None,
                                    NDArray[Any] | None, DataFrame | None,
                                    ]:
    """Get weights for obs in pred_data & outcome and cluster from y_data.

    Parameters
    ----------
    forest_dic : Dict. Contains data and node table of estimated forest.
    x_dat : Numpy array. X-data to make predictions for.
    cf_cfg :  CfCfg dataclass. Variables.
    ct_cfg :  Dataclass CtGrid. Variables.
    int_cfg :  Dataclass IntCfg. Variables.
    gen_cfg :  GenCfg Dataclass. Parameters.
    p_cfg : PCfg dataclass. Parameters.
    no_x_bala_return: Bool. Do not return X for balancing tests despite
                            p_cfg.bt_yes being True. Default is False.
    ...

    Returns
    -------
    weights : Tuple of lists (N_pred x 1 (x no_of_treat + 1).
    y_data : N_y x number of outcomes-Numpy array. Outcome variables.
    x_bala : N_y x number of balancing-vars-Numpy array. Balancing test vars.
    cl_dat : N_y x 1 Numpy array. Cluster number.
    w_dat : N_y x 1 Numpy array. Sampling weights (if used).
    prog_dat : N_y x number of treatments Numpy array. Prognostic score.
    prop_dat : N_y x number of treatments-1 Numpy array. Propensity score.
    x_ba_dat : N_y x number of variables in bias adjustment Numpy array.
    d_dat: N_y x 2 Numpy array or None. Treatment info with subtreatments
    x_tv_dat_df: N_y x 2 DataFrame or None. X for subtreatment regressions.
    """
    # Local dictionaries; do not copy or modify the underlying tree arrays and lists.
    forest_dic = forest_dic.copy()
    forest_dic['forest'] = [tree.copy() for tree in forest_dic['forest']]
    for tree in forest_dic['forest']:
        tree['_lookup_categorical'] = any(cat > 0.5 for cat in tree['cats_prime'])

    print_yes = gen_cfg.with_output and gen_cfg.verbose and with_output
    progress = print_yes and print_progress
    use_tqdm, output_clean = mcf_gp.tqdm_setup(tqdm, progress)
    y_dat = mcf_gp.to_numpy_big_data(forest_dic['y_train_df'], int_cfg.obs_bigdata)

    d_dat = forest_dic['d_train_df'].to_numpy(copy=True)
    if gen_cfg.d_type == 'discrete':
        d_dat = np.int32(np.round(d_dat))
    if subtreatments:
        d_dat_export = d_dat.copy()
        d_dat = d_dat[:, 0]
    else:
        d_dat_export = None
        if d_dat.shape[1] == 2:
            d_dat = d_dat[:, 0]

    x_tv_train_df = forest_dic['x_tv_train_df']  # None if treatment version is not used
    prog_dat = forest_dic['prog_dat_np']         # None if bias adj. is not used
    prop_dat = forest_dic['prop_dat_np']         # None if bias adj. is not used
    x_ba_dat = forest_dic['x_ba_dat_np']         # None if bias adj. is not used

    # This ensures that treatments are integers
    treat_is_integer = d_dat.min() >= 0
    # Check whether treatment labels are 0, 1, ..., T-1 in this exact order.
    if gen_cfg.d_type != 'continuous':
        d_values_0_treatm1 = np.array_equal(np.asarray(gen_cfg.d_values),
                                            np.arange(len(gen_cfg.d_values))
                                            )
    else:
        d_values_0_treatm1 = False

    n_x, n_y = len(x_dat), len(y_dat)
    # Cluster labels must not depend on the floating-point calculation precision.
    cl_dat = forest_dic['cl_train_df'].to_numpy(copy=True) if p_cfg.cluster_std else 0
    w_dat = forest_dic['w_train_df'].to_numpy(copy=True) if gen_cfg.weighted else 0
    x_bala = 0
    if p_cfg.bt_yes and not no_x_bala_return:
        x_bala = mcf_gp.to_numpy_big_data(forest_dic['x_bala_df'], int_cfg.obs_bigdata)
    empty_leaf_counter = merge_leaf_counter = 0
    if gen_cfg.mp_parallel < 1.5:
        maxworkers = 1
    else:
        if gen_cfg.mp_automatic:
            # This not really do anything ...
            maxworkers = mcf_sys.find_no_of_workers(gen_cfg.mp_parallel,
                                                    gen_cfg.sys_share,
                                                    zero_tol=int_cfg.zero_tol,
                                                    )
        else:
            maxworkers = gen_cfg.mp_parallel

    if maxworkers > 1 and int_cfg.mp_use_old_ray:
        if ray is None:
            raise ImportError('int_cfg.mp_use_old_ray=True, but ray is not installed. '
                              'Install ray or use the new backend with '
                              'mp_use_old_ray=False.'
                              )

        if not ray.is_initialized():
            if int_cfg.mp_weights_type == 2:
                mem_object_store = None
                ray_err_txt = 'Ray does not start in weight estimation.'
            else:
                mem_object_store = int_cfg.mem_object_store_3
                ray_err_txt = 'Ray does not start up in weight estimation 1'

            ray_is_running, maxworkers = mcf_ray.init_ray_with_fallback(
                maxworkers, gen_cfg,
                mem_object_store=mem_object_store,
                mem_object_store_2=int_cfg.mem_object_store_2,
                ray_err_txt=ray_err_txt,
                )
            if not ray_is_running:
                maxworkers = 1

    print_runtime_info(gen_cfg, int_cfg, maxworkers, txt_method='weight matrix')

    mp_over_boots = False if maxworkers == 1 else bool(int_cfg.mp_weights_type == 2)
    no_of_treat = len(ct_cfg.grid_w_val) if gen_cfg.d_type == 'continuous' else gen_cfg.no_of_treat

    kw_args = {'cf_cfg': cf_cfg, 'ct_cfg': ct_cfg, 'gen_cfg': gen_cfg, 'int_cfg': int_cfg,
               'treat_is_integer': treat_is_integer, 'd_values_0_treatm1': d_values_0_treatm1,
               }
    if maxworkers == 1 or mp_over_boots:
        weights = initialise_weights(n_x, n_y, no_of_treat, int_cfg.weight_as_sparse)
        split_forest = False
        iterator_idx = range(n_x)
        if use_tqdm:
            iterator_idx = tqdm(iterator_idx, total=n_x, desc='Weights',
                                leave=False, dynamic_ncols=True,
                                )
        for idx in iterator_idx:  # Iterate over i
            results_fut_idx = weights_obs_i(idx, n_y, forest_dic['forest'], x_dat, d_dat,
                                            **kw_args,
                                            mp_over_boots=mp_over_boots, maxworkers=maxworkers,
                                            split_forest=False,
                                            )
            mcf_gp.progress_clean_memory(output=output_clean, current_idx=idx+1, total=n_x)
            if int_cfg.weight_as_sparse:
                for d_idx in range(no_of_treat):
                    indices = results_fut_idx[1][d_idx][0]
                    weights_obs = results_fut_idx[1][d_idx][1]
                    weights[d_idx].set_row(idx, indices, weights_obs)
            else:
                weights[idx] = results_fut_idx[1]
            empty_leaf_counter += results_fut_idx[2]
        if int_cfg.weight_as_sparse:
            weights = weights_to_csr(weights, no_of_treat)

    else:
        no_of_splits_i, max_size_i = maxworkers, 1000
        if n_x / no_of_splits_i > max_size_i:
            while True:
                no_of_splits_i += maxworkers
                if n_x / no_of_splits_i <= max_size_i:
                    break
        if print_yes:
            txt = ('\nOperational characteristics of weight estimation I '
                   f'\nNumber of workers: {maxworkers:2} '
                   f'\nNumber of observation chunks: {no_of_splits_i:5} '
                   f'\nAverage # of observations per chunck: {n_x / no_of_splits_i:5.2f} '
                   )
            mcf_ps.print_mcf(gen_cfg, txt, summary=False)
        all_idx_split = np.array_split(range(n_x), no_of_splits_i)
        split_forest = False
        boot_indx_list = range(1)
        no_of_boot_splits = total_bootstraps = None

        if (not int_cfg.weight_as_sparse) and split_forest:
            if print_yes:
                txt = '\n' + 'XXXXXXXXDANGERXXXX' * 3
                txt += ('\nBootstrap splitting requires using sparse matrices.'
                        '\nProgramme continues without bootstrap splitting but may crash due to '
                        'insufficient memory.'
                        )
                txt += '\n' + 'XXXXXXXX DANGER XXXXXXXX' * 3
                mcf_ps.print_mcf(gen_cfg, txt, summary=True)

        reference_duration = +np.inf if bigdata_train else None
        for b_i, boots_ind in enumerate(boot_indx_list):
            time_start = time() if bigdata_train else None
            weights = initialise_weights(n_x, n_y, no_of_treat, int_cfg.weight_as_sparse)
            if split_forest:
                # get subforest
                forest_temp = forest_dic['forest'][boots_ind[0]: boots_ind[-1]+1]
                if print_yes and b_i == 0:
                    size = mcf_sys.total_size(forest_temp) / (1024*1024)
                    txt = f'\nSize of each submitted forest {size:6.2f} MB'
                    mcf_ps.print_mcf(gen_cfg, txt, summary=False)
                cf_cfg.boot = len(boots_ind)
                # weights über trees addieren
                if print_yes:
                    print(f'\nBoot Chunk {b_i+1:2} of {no_of_boot_splits:2}')
                    _, _, _, _, txt = mcf_sys.memory_statistics()
                    mcf_ps.print_mcf(gen_cfg, txt, summary=False)

            ray_err_txt='Ray does not start up in weight estimation 1'
            if int_cfg.mp_use_old_ray:
                if not ray.is_initialized():
                    if ray is None or ray_weights_many_obs_i is None:
                        raise ImportError('int_cfg.mp_use_old_ray=True, but ray is not installed. '
                                          'Install ray or use the new backend with '
                                          'mp_use_old_ray=False.'
                                          )
                    _, no_of_workers = mcf_ray.init_ray_with_fallback(
                        maxworkers, gen_cfg,
                        mem_object_store=int_cfg.mem_object_store_3,
                        mem_object_store_2=int_cfg.mem_object_store_2,
                        ray_err_txt=ray_err_txt,
                        )
                else:
                    no_of_workers = maxworkers
                mcf_ray.print_object_store(gen_cfg, int_cfg.mem_object_store_3)

                d_dat_ref, x_dat_ref, forest_ref = mcf_ray.ray_put_all(d_dat, x_dat,
                                                                       forest_dic['forest'],
                                                                       )
                still_running = [ray_weights_many_obs_i.remote(idx_list, n_y,
                                                               forest_ref, x_dat_ref, d_dat_ref,
                                                               **kw_args,
                                                               split_forest=split_forest,
                                                               )
                                 for idx_list in all_idx_split
                                 ]
                jdx = 0
                time_start_ray = time() if bigdata_train else 0
                pbar = (tqdm(total=no_of_splits_i, desc='Weights', leave=False, dynamic_ncols=True)
                        if use_tqdm else None
                        )
                try:
                    while len(still_running) > 0:
                        finished, still_running = ray.wait(still_running, num_returns=1)
                        # Perhaps avoid jamming the queue
                        finished_res = ray.get(finished)
                        for results_fut_idx in finished_res:
                            if pbar is not None:
                                pbar.update(1)
                            else:
                                if progress:
                                    if bigdata_train:
                                        time_diff = (time() - time_start_ray) / (jdx+1)
                                        td_str = ' (' + str(int(np.round(time_diff))) + 's)'
                                    else:
                                        td_str = ''

                                    if jdx == 0:
                                        print(f'\n   Obs chunk {jdx+1:2} '
                                              f'({no_of_splits_i}){td_str}', end=''
                                              )
                                    else:
                                        print(f' {jdx+1:2} ({no_of_splits_i}){td_str}', end='')
                            jdx += 1

                            for idx, val_list in enumerate(results_fut_idx[0]):
                                if int_cfg.weight_as_sparse:
                                    for d_idx in range(no_of_treat):
                                        indices = results_fut_idx[1][idx][d_idx][0]
                                        weights_obs = results_fut_idx[1][idx][d_idx][1]
                                        weights[d_idx].set_row(int(val_list), indices, weights_obs)
                                else:
                                    weights[val_list] = results_fut_idx[1][idx]
                            empty_leaf_counter += results_fut_idx[2]
                finally:
                    if pbar is not None:
                        pbar.close()
                (x_dat_ref, forest_ref, d_dat_ref, finished_res, finished
                 ) = mcf_ray.ray_del_refs(x_dat_ref, forest_ref, d_dat_ref,
                                          f1=finished_res, f2=finished,
                                          mp_ray_del=int_cfg.mp_ray_del,
                                          )
            else:
                shared_weight_data = {'d_dat': d_dat, 'x_dat': x_dat, 'forest': forest_dic['forest']
                                      }
                fail_txt='Failed to make executor in weight estimation 1.'
                with forest_executor_with_shared(int_cfg=int_cfg, maxworkers=maxworkers,
                                                 shared_obj=shared_weight_data,
                                                 shared_name='weight_estimation_1_data',
                                                 ray_err_txt=ray_err_txt, fail_txt=fail_txt,
                                                 ) as (executor, data_handle, maxworkers):
                    tasks = [TaskSpec(func=weights_many_obs_i_backend,
                                      kwargs={'idx_list': idx_list,
                                              'n_y': n_y,
                                              'data': data_handle,
                                              'kw_args': kw_args,
                                              'split_forest': split_forest,
                                              },
                                      name=f'weights_many_obs_i_{jdx}',
                                      )
                             for jdx, idx_list in enumerate(all_idx_split)
                             ]
                    jdx = 0
                    time_start_parallel = time() if bigdata_train else 0
                    pbar = (tqdm(total=no_of_splits_i, desc='Weights', leave=False,
                                 dynamic_ncols=True)
                            if use_tqdm else None
                            )
                    try:
                        for results_fut_idx in map_task_batches(executor=executor, tasks=tasks,
                                                                int_cfg=int_cfg,
                                                                maxworkers=maxworkers,
                                                                min_worker_waves=1,
                                                                stream_results=True,
                                                                ):
                            if pbar is not None:
                                pbar.update(1)
                            else:
                                if progress:
                                    if bigdata_train:
                                        time_diff = (time() - time_start_parallel) / (jdx + 1)
                                        td_str = ' (' + str(int(np.round(time_diff))) + 's)'
                                    else:
                                        td_str = ''

                                    if jdx == 0:
                                        print(f'\n   Obs chunk {jdx + 1:2} '
                                              f'({no_of_splits_i}){td_str}', end='',
                                              )
                                    else:
                                        print(f' {jdx + 1:2} ({no_of_splits_i}){td_str}', end='')

                            jdx += 1

                            for idx, val_list in enumerate(results_fut_idx[0]):
                                if int_cfg.weight_as_sparse:
                                    for d_idx in range(no_of_treat):
                                        indices = results_fut_idx[1][idx][d_idx][0]
                                        weights_obs = results_fut_idx[1][idx][d_idx][1]
                                        weights[d_idx].set_row(int(val_list), indices, weights_obs)
                                else:
                                    weights[val_list] = results_fut_idx[1][idx]

                            empty_leaf_counter += results_fut_idx[2]
                    finally:
                        if pbar is not None:
                            pbar.close()

            if int_cfg.weight_as_sparse:  # Transform to sparse matrix
                weights = weights_to_csr(weights, no_of_treat)
            if split_forest:
                if b_i == 0:  # only in case of splitted forests
                    weights_all = weights
                else:
                    for d_idx in range(no_of_treat):
                        weights_all[d_idx] += weights[d_idx]
                if print_yes:
                    print()
                    mcf_gp.print_size_weight_matrix(weights_all, int_cfg.weight_as_sparse,
                                                    no_of_treat
                                                    )
                    _, _, _, _, txt = mcf_sys.memory_statistics()
                    mcf_ps.print_mcf(gen_cfg, ' ' + txt, summary=False)

        # Check if restart of ray is necessary
        if bigdata_train and int_cfg.mp_use_old_ray:
            duration = time() - time_start
            reference_duration, _ = mcf_ray.check_ray_shutdown_legacy(
                gen_cfg, reference_duration, duration, no_of_workers,  # pylint: disable=E0606
                max_multiplier=5, with_output=print_yes,
                err_txt='\nProblem in weight computation (inner function): '
                )
        else:
            duration = None

    if split_forest:
        cf_cfg.boot = total_bootstraps
        weights = normalize_weights(weights_all, no_of_treat, int_cfg.weight_as_sparse, n_x)
    weights = tuple(weights)
    if ((empty_leaf_counter > 0) or (merge_leaf_counter > 0)) and print_yes:
        txt = (f'\n\n{merge_leaf_counter:5} observations attributed in merged leaves'
               f'\n{empty_leaf_counter:5} observations attributed to leaf w/o observations'
               )
        mcf_ps.print_mcf(gen_cfg, txt, summary=True)

    return (weights, y_dat, x_bala, cl_dat, w_dat, prog_dat, prop_dat, x_ba_dat, d_dat_export,
            x_tv_train_df,
            )


def weights_many_obs_i_backend(*, idx_list: Any,
                               n_y: int,
                               data: dict[str, Any],
                               kw_args: dict[str, Any],
                               split_forest: bool,
                               ) -> Any:
    """Backend-agnostic wrapper for one weight-estimation chunk."""
    return weights_many_obs_i(idx_list, n_y, data['forest'], data['x_dat'], data['d_dat'],
                              **kw_args,
                              split_forest=split_forest,
                              )


def normalize_weights(weights: list,
                      no_of_treat: int,
                      sparse_m: bool,
                      n_x: int
                      ) -> list:
    """Normalise weight matrix (needed when forest is split)."""
    for d_idx in range(no_of_treat):
        if sparse_m:
            weights[d_idx] = normal_weights_sparse(weights[d_idx], n_x)
        else:
            for i in range(n_x):
                weights[i][d_idx][1] = weights[i][d_idx][1] / np.sum(weights[i][d_idx][1])
                weights[i][d_idx][1] = weights[i][d_idx][1].astype(np.float32)

    return weights


def normal_weights_sparse_loop(weights: sparse.csr_matrix, n_x: int) -> sparse.csr_matrix:
    """Normalize sparse weight matrix (which is the heavy duty case)."""
    row_sum = 1 / weights.sum(axis=1)
    for i in range(n_x):
        weights[i, :] = weights[i, :].multiply(row_sum[i])
    weights = weights.astype(np.float32, casting='same_kind')

    return weights


def normal_weights_sparse(weights: sparse.csr_matrix,
                          n_x: int
                          ) -> sparse.csr_matrix:
    """Normalize rows of sparse weight matrix."""
    normalized_weights = weights.astype(np.float32,
                                         casting='same_kind',
                                         copy=True)
    row_sum = np.asarray(normalized_weights.sum(axis=1)).ravel()
    row_sum_inv = np.zeros(n_x, dtype=np.float32)
    np.divide(1.0, row_sum, out=row_sum_inv, where=row_sum != 0)  # In-place division

    normalized_weights.data *= np.repeat(row_sum_inv, np.diff(normalized_weights.indptr))

    return normalized_weights


class _SparseWeightBuilder:
    """Collect complete, sorted weight rows and consume them into one CSR array."""

    __slots__ = ('n_x', 'n_y', 'rows')

    def __init__(self, n_x: int, n_y: int) -> None:
        if n_x < 0 or n_y < 0:
            raise ValueError('Weight-matrix dimensions must be nonnegative.')
        self.n_x, self.n_y = n_x, n_y
        self.rows: list[tuple[NDArray[Any], NDArray[Any]] | None] | None = [None] * n_x

    def set_row(self, row_idx: int, indices: NDArray[Any], values: NDArray[Any]) -> None:
        """Copy one complete row; column indices must be sorted and unique."""
        if self.rows is None:
            raise RuntimeError('This weight builder has already been converted to CSR.')
        if not 0 <= row_idx < self.n_x:
            raise IndexError(f'Weight row {row_idx} is outside the prediction sample.')

        cols = np.asarray(indices).reshape(-1)
        vals = np.asarray(values, dtype=np.float32).reshape(-1)
        if cols.size != vals.size:
            raise RuntimeError(f'Weight reconstruction mismatch: row={row_idx}, '
                               f'cols={cols.size}, vals={vals.size}'
                               )
        if cols.size:
            if cols.dtype.kind not in 'iu':
                raise TypeError('Weight column indices must have an integer dtype.')
            if (cols[0] < 0 or cols[-1] >= self.n_y
                    or np.any(cols[1:] <= cols[:-1])):
                raise ValueError('Weight column indices must be in range, sorted and unique.')

        # LIL assignment discards exact zeros after conversion to float32.
        nonzero = vals != 0
        index_dtype = np.int32 if self.n_y <= np.iinfo(np.int32).max else np.int64
        if nonzero.all():
            cols = cols.astype(index_dtype, copy=True)
            vals = vals.copy()
        else:
            cols = cols[nonzero].astype(index_dtype, copy=False)
            vals = vals[nonzero]
        self.rows[row_idx] = (cols, vals) if cols.size else None

    def to_csr(self) -> sparse.csr_array:
        """Build CSR without numerical aggregation, releasing copied rows as they are written."""
        if self.rows is None:
            raise RuntimeError('This weight builder has already been converted to CSR.')

        indptr = np.empty(self.n_x + 1, dtype=np.int64)
        indptr[0] = 0
        for row_idx, row in enumerate(self.rows):
            indptr[row_idx + 1] = 0 if row is None else row[0].size
        np.cumsum(indptr, out=indptr)
        nnz = int(indptr[-1])

        index_dtype = (np.int32 if max(self.n_x, self.n_y, nnz) <= np.iinfo(np.int32).max
                       else np.int64
                       )
        indptr = indptr.astype(index_dtype, copy=False)
        indices = np.empty(nnz, dtype=index_dtype)
        data = np.empty(nnz, dtype=np.float32)
        for row_idx, row in enumerate(self.rows):
            if row is not None:
                start, stop = indptr[row_idx], indptr[row_idx + 1]
                indices[start:stop] = row[0]
                data[start:stop] = row[1]
                self.rows[row_idx] = None
        self.rows = None

        return sparse.csr_array((data, indices, indptr), shape=(self.n_x, self.n_y), copy=False)


def initialise_weights(n_x: int, n_y: int, no_of_treat: int, weight_as_sparse: bool,) -> list[Any]:
    """Initialise the weights matrix."""
    if weight_as_sparse:
        weights = []
        for _ in range(no_of_treat):
            weights.append(_SparseWeightBuilder(n_x, n_y))
    else:
        weights = [None for _ in range(n_x)]

    return weights


def weights_obs_i(idx: int,
                  n_y: int,
                  forest: list,
                  x_dat: NDArray[Any],
                  d_dat: NDArray[Any], *,
                  cf_cfg: 'CfCfg',
                  ct_cfg: 'CtGrid',
                  gen_cfg: 'GenCfg',
                  int_cfg: 'IntCfg',
                  mp_over_boots: bool = False,
                  maxworkers: int = 1,
                  split_forest: bool = False,
                  treat_is_integer: bool = True,
                  d_values_0_treatm1: bool = True,
                  ) -> tuple[int, list, int]:
    """
    Compute weight for single observation to predict.

    Parameters
    ----------
    idx : Int. Counter.
    n_y: Int. Length of training data.
    forest : List of Lists.
    x_dat : Numpy array. Prediction sample.
    d_dat: Numpy array. Training sample.
    cf_cfg : CfCfg dataclass. Parameters
    ct_cfg : CtGrid dataclass. Parameters
    gen_cfg : GenCfg dataclass. Parameters
    int_cfg : Instance of Dataclass. Parameters
    mp_over_boots : Bool. Multiprocessing at level of bootstraps. Default is False.
    maxworkers: Int. Number of workers if MP.
    split_forest : Boolean. True if chunks of bootstraps. Default is False.

    Returns
    -------
    idx : Int. Counter.
    weights_i : List of lists.
    empty_leaf_counter : Int.

    """
    bigdata_train = int_cfg.bigdata_train
    empty_leaf_counter = 0

    if gen_cfg.d_type == 'continuous':
        no_of_treat = len(ct_cfg.grid_w_val)
        d_values = ct_cfg.grid_w_val
        continuous = True
    else:
        no_of_treat, d_values = gen_cfg.no_of_treat, gen_cfg.d_values
        continuous = False

    x_dat_i = x_dat[idx, :]

    weight_with_triplet = not continuous

    if weight_with_triplet:
        rows_parts: list[NDArray[np.integer]] = []
        cols_parts: list[NDArray[np.integer]] = []
        vals_parts: list[NDArray[np.floating]] = []
    else:
        dtype = np.float32 if bigdata_train else np.float64
        # Row positions identify outcomes; store only treatment weights.
        weights_i_np = np.zeros((n_y, no_of_treat), dtype=dtype)
        buffer = np.zeros((n_y, no_of_treat), dtype=dtype)

    kw_args = {'n_y': n_y, 'no_of_treat': no_of_treat, 'd_values': d_values,
               'continuous': continuous, 'bigdata_train': bigdata_train,
               'zero_tol': int_cfg.zero_tol, 'd_values_0_treatm1': d_values_0_treatm1,
               }
    if mp_over_boots:
        ray_err_txt='Ray does not start in weight estimation.'
        if int_cfg.mp_use_old_ray:
            if (ray is None
                or ray_weights_obs_i_inside_boot_triplet is None
                    or ray_weights_obs_i_inside_boot is None
                    ):
                raise ImportError('int_cfg.mp_use_old_ray=True, but ray is not installed. '
                                  'Install ray or use the new backend with '
                                  'mp_use_old_ray=False.'
                                  )
            if not ray.is_initialized():
                mcf_ray.init_ray_with_fallback(maxworkers, gen_cfg,
                                               mem_object_store_2=int_cfg.mem_object_store_2,
                                               ray_err_txt=ray_err_txt,
                                               )
            d_dat_ref = mcf_ray.ray_put_all(d_dat)

            if weight_with_triplet:  # Added Oct, 30, 2025
                still_running = [ray_weights_obs_i_inside_boot_triplet.remote(forest[boot],
                                                                              x_dat_i=x_dat_i,
                                                                              d_dat=d_dat_ref,
                                                                              **kw_args,
                                                                              )
                                 for boot in range(cf_cfg.boot)
                                 ]
                while len(still_running) > 0:
                    finished, still_running = ray.wait(still_running, num_returns=1)
                    finished_res = ray.get(finished)
                    for result in finished_res:
                        if result[3]:
                            empty_leaf_counter += 1
                        else:
                            # np.add.at(weights_i_np, (result[0], 1 + result[1]), result[2])
                            rows_parts.append(result[0])
                            cols_parts.append(result[1])
                            vals_parts.append(result[2])
            else:
                still_running = [ray_weights_obs_i_inside_boot.remote(forest[boot],
                                                                      x_dat_i=x_dat_i,
                                                                      d_dat=d_dat_ref,
                                                                      **kw_args,
                                                                      treat_is_integer=
                                                                          treat_is_integer,
                                                                      buffer=buffer,
                                                                      )
                                 for boot in range(cf_cfg.boot)
                                 ]
                while len(still_running) > 0:
                    finished, still_running = ray.wait(still_running, num_returns=1)
                    finished_res = ray.get(finished)
                    for result in finished_res:
                        if result[1]:
                            empty_leaf_counter += 1
                        else:
                            weights_i_np += result[0]
        else:
            shared_weight_estimation_data = {'d_dat': d_dat}

            fail_txt='Failed to make executor in weight estimation.'
            with forest_executor_with_shared(int_cfg=int_cfg, maxworkers=maxworkers,
                                             shared_obj=shared_weight_estimation_data,
                                             shared_name='weight_estimation_data',
                                             ray_err_txt=ray_err_txt, fail_txt=fail_txt,
                                             ) as (executor, data_handle, maxworkers_):
                if weight_with_triplet:
                    tasks = [TaskSpec(func=weights_obs_i_inside_boot_triplet_backend,
                                      kwargs={'forest_boot': forest[boot],
                                              'x_dat_i': x_dat_i,
                                              'data': data_handle,
                                              'kw_args': kw_args,
                                              },
                                      name=f'weights_obs_triplet_{boot}',
                                      )
                             for boot in range(cf_cfg.boot)
                             ]
                else:
                    tasks = [TaskSpec(func=weights_obs_i_inside_boot_backend,
                                      kwargs={'forest_boot': forest[boot],
                                              'x_dat_i': x_dat_i,
                                              'data': data_handle,
                                              'kw_args': kw_args,
                                              'treat_is_integer': treat_is_integer,
                                              'buffer': buffer,
                                              },
                                      name=f'weights_obs_{boot}',
                                      )
                             for boot in range(cf_cfg.boot)
                             ]
                for result in map_task_batches(executor=executor, tasks=tasks, int_cfg=int_cfg,
                                               maxworkers=maxworkers_,
                                               min_worker_waves=1,
                                               stream_results=True,
                                               ):
                    if weight_with_triplet:
                        if result[3]:
                            empty_leaf_counter += 1
                        else:
                            # np.add.at(weights_i_np, (result[0], 1 + result[1]), result[2])
                            rows_parts.append(result[0])
                            cols_parts.append(result[1])
                            vals_parts.append(result[2])
                    else:
                        if result[1]:
                            empty_leaf_counter += 1
                        else:
                            weights_i_np += result[0]

    else:
        # This is the default branch
        for boot in range(cf_cfg.boot):
            if weight_with_triplet:  # Added Oct, 30, 2025
                rows, cols, vals, empty_leaf = weights_obs_i_inside_boot_triplet(forest[boot],
                                                                                 x_dat_i=x_dat_i,
                                                                                 d_dat=d_dat,
                                                                                 **kw_args,
                                                                                 )
                if empty_leaf:
                    empty_leaf_counter += 1
                else:
                    # np.add.at(weights_i_np, (rows, 1 + cols), vals)
                    rows_parts.append(rows)
                    cols_parts.append(cols)
                    vals_parts.append(vals)
            else:
                weights_ij_np, empty_leaf = weights_obs_i_inside_boot(forest[boot],
                                                                      x_dat_i=x_dat_i, d_dat=d_dat,
                                                                      **kw_args,
                                                                      treat_is_integer=
                                                                          treat_is_integer,
                                                                      buffer=buffer,
                                                                      )
                if empty_leaf:
                    empty_leaf_counter += 1
                else:
                    weights_i_np += weights_ij_np

    obs_without_leaf = 1 if empty_leaf_counter == cf_cfg.boot else 0
    normalize = not split_forest

    # weights_i = final_trans(weights_i_np, no_of_treat, normalize)
    if weight_with_triplet:
        weights_i = final_trans_from_triplets(rows_parts, cols_parts, vals_parts,
                                              n_y=n_y, no_of_treat=no_of_treat, normalize=normalize,
                                              zero_tol=1e-14,
                                              )
    else:
        weights_i = final_trans(weights_i_np, no_of_treat, normalize)

    return idx, weights_i, obs_without_leaf


def weights_obs_i_inside_boot_triplet_backend(*, forest_boot: Any,
                                              x_dat_i: Any,
                                              data: dict[str, Any],
                                              kw_args: dict[str, Any],
                                              ) -> Any:
    """Backend-agnostic wrapper for one bootstrap weight task (triplet)."""
    return weights_obs_i_inside_boot_triplet(forest_boot,
                                             x_dat_i=x_dat_i, d_dat=data['d_dat'],
                                             **kw_args,
                                             )


def weights_obs_i_inside_boot_backend(*, forest_boot: Any,
                                      x_dat_i: Any,
                                      data: dict[str, Any],
                                      kw_args: dict[str, Any],
                                      treat_is_integer: bool,
                                      buffer: Any,
                                      ) -> Any:
    """Backend-agnostic wrapper for one bootstrap weight task."""
    return weights_obs_i_inside_boot(forest_boot,
                                     x_dat_i=x_dat_i, d_dat=data['d_dat'],
                                     **kw_args,
                                     treat_is_integer=treat_is_integer, buffer=buffer,
                                     )


# @ray.remote
def _ray_weights_obs_i_inside_boot_impl(forest_b: dict, *,
                                        x_dat_i: NDArray[Any],
                                        n_y: int,
                                        no_of_treat: int,
                                        d_values: Sequence[int | float],
                                        d_dat: NDArray[Any],
                                        continuous: bool,
                                        bigdata_train: bool = False,
                                        treat_is_integer: bool = True,
                                        buffer: NDArray[np.floating] | None = None,
                                        d_values_0_treatm1: bool = True,
                                        zero_tol: float = 1e-10,
                                        ) -> tuple[NDArray[Any], bool]:
    """Allow for MP at bootstrap level (intermediate procedure) with ray."""
    weights_ij_np, empty_leaf = weights_obs_i_inside_boot(
        forest_b,
        x_dat_i=x_dat_i, n_y=n_y, no_of_treat=no_of_treat, d_values=d_values, d_dat=d_dat,
        continuous=continuous, bigdata_train=bigdata_train, treat_is_integer=treat_is_integer,
        buffer=buffer, d_values_0_treatm1=d_values_0_treatm1, zero_tol=zero_tol,
        )
    return weights_ij_np, empty_leaf


ray_weights_obs_i_inside_boot = (ray.remote(_ray_weights_obs_i_inside_boot_impl) if ray is not None
                                 else None
                                 )


# @ray.remote
def _ray_weights_obs_i_inside_boot_triplet_impl(forest_b: dict, *,
                                                x_dat_i: NDArray[Any],
                                                n_y: int,
                                                no_of_treat: int,
                                                d_values: Sequence[int | float],
                                                d_dat: NDArray[Any],
                                                continuous: bool,
                                                bigdata_train: bool = False,
                                                d_values_0_treatm1: bool = True,
                                                zero_tol: float = 1e-10,
                                                ) -> tuple[NDArray[np.intp], NDArray[np.intp],
                                                           NDArray[np.floating], bool
                                                           ]:
    """Allow for MP at bootstrap level (intermediate procedure) with ray."""
    rows, cols, vals, empty_leaf = weights_obs_i_inside_boot_triplet(
        forest_b, x_dat_i=x_dat_i, n_y=n_y, no_of_treat=no_of_treat, d_values=d_values, d_dat=d_dat,
        continuous=continuous, bigdata_train=bigdata_train, d_values_0_treatm1=d_values_0_treatm1,
        zero_tol=zero_tol,
        )
    return rows, cols, vals, empty_leaf


ray_weights_obs_i_inside_boot_triplet = (ray.remote(_ray_weights_obs_i_inside_boot_triplet_impl)
                                         if ray is not None
                                         else None
                                         )


def weights_obs_i_inside_boot(forest_b: dict, *,
                              x_dat_i: NDArray[Any],
                              n_y: int,
                              no_of_treat: int,
                              d_values: Sequence[int | float],
                              d_dat: NDArray[Any],
                              continuous: bool,
                              treat_is_integer: bool = True,
                              bigdata_train: bool = False,
                              buffer: NDArray[np.floating] | None = None,
                              d_values_0_treatm1: bool = True,
                              zero_tol: float = 1e-10,
                              ) -> tuple[NDArray[Any], bool]:
    """Allow for MP at bootstrap level (intermediate procedure)."""
    # This is the default branch
    if continuous:
        # Continuous treatments
        # buffer is ignored, might be added later after update of cont.treatm.
        return weights_obs_i_inside_boot_treat_cont(forest_b,
                                                    x_dat_i=x_dat_i, n_y=n_y,
                                                    no_of_treat=no_of_treat, d_values=d_values,
                                                    d_dat=d_dat, bigdata_train=bigdata_train,
                                                    zero_tol=zero_tol,
                                                    )
    # Discrete treatments
    return weights_obs_i_inside_boot_treat_disc(forest_b,
                                                x_dat_i=x_dat_i, n_y=n_y, no_of_treat=no_of_treat,
                                                d_values=d_values, d_dat=d_dat,
                                                bigdata_train=bigdata_train,
                                                treat_is_integer=treat_is_integer,
                                                out_buffer=buffer,
                                                d_values_0_treatm1=d_values_0_treatm1,
                                                zero_tol=zero_tol,
                                                )


def weights_obs_i_inside_boot_triplet(forest_b: dict, *,
                                      x_dat_i: NDArray[Any],
                                      n_y: int,
                                      no_of_treat: int,
                                      d_values: Sequence[int | float],
                                      d_dat: NDArray[Any],
                                      continuous: bool,
                                      bigdata_train: bool = False,
                                      d_values_0_treatm1: bool = True,
                                      zero_tol: float = 1e-10,
                                      ) -> tuple[NDArray[np.intp], NDArray[np.intp],
                                                 NDArray[np.floating], bool
                                                 ]:
    """Allow for MP at bootstrap level (intermediate procedure)."""
    # This is the default branch
    kw_args = {'bigdata_train': bigdata_train, 'zero_tol': zero_tol,}
    if continuous:
        # Only 2 returns
        weights_ij_np, empty_leaf = weights_obs_i_inside_boot_treat_cont(
            forest_b,
            x_dat_i=x_dat_i, n_y=n_y, no_of_treat=no_of_treat, d_values=d_values, d_dat=d_dat,
            **kw_args,
            )
         # Only for consistency, should not work with current vertsion
        return weights_ij_np, empty_leaf, None, None
    # Discrete treatments: 4 returns
    return weights_obs_i_inside_boot_treat_disc_triplets(forest_b, x_dat_i, no_of_treat, d_values,
                                                         d_dat,
                                                         d_values_0_treatm1=d_values_0_treatm1,
                                                         **kw_args,
                                                         )


def weights_obs_i_inside_boot_treat_cont(forest_b: dict, *,
                                         x_dat_i: NDArray[Any],
                                         n_y: int,
                                         no_of_treat: int,
                                         d_values: Sequence[int | float],
                                         d_dat: NDArray[Any],
                                         bigdata_train: bool = False,
                                         zero_tol: float = 1e-10,
                                         ) -> tuple[NDArray[Any], bool]:
    """Allow for MP at bootstrap level (intermediate procedure)."""
    # here is the information for the different treatments needed
    # Problem ist dass man hier für die x alle potential outcomes berechnet
    # Bei continuous treatments gehören aber verschiedene leafs zu den gleichen
    # X. Ausserdem werden d=0 und die anderen Werte von d verschieden behandelt
    # x_dat_i ist eine design matrix, die dann auch die verschiedenen werte von
    # d enthalten sollte
    # d = 0 zu setzen scheint aber überflüssig bei der designmatrix bzgl. d
    fill_y_empty_leave = forest_b['fill_y_empty_leave']
    fill_y_indices_list = forest_b['fill_y_indices_list']

    leaf_id_list = []
    # We get a list of leafs that contains relevant elements, some of them
    # may be identical, but this does not matter
    for treat in d_values[1:]:
        x_dat_i_t = np.append(x_dat_i, treat)
        leaf_id = mcf_fo_add.get_terminal_leaf_no(forest_b, x_dat_i_t)
        leaf_id_list.append(leaf_id)
        if fill_y_empty_leave[leaf_id] == 1 or fill_y_indices_list[leaf_id] is None:
            empty_leaf, weights_ij_np = True, 0
            # If any of the subleaves is None, then stop ...
            break
        empty_leaf = False

    if not empty_leaf:
        fb_lid_14_list = [fill_y_indices_list[leaf_id] for leaf_id in leaf_id_list]
        if bigdata_train:
            weights_ij_np = np.zeros((n_y, no_of_treat))
        else:
            weights_ij_np = np.zeros((n_y, no_of_treat), dtype=np.float32)

        # We need to collect information over various leafs for the 0
        # For the other leaves, the leaves are treatment specific
        leaf_0_complete, leaf_pos_complete = False, True
        # Zuerst 0 einsammeln
        for jdx, fb_lid_14 in enumerate(fb_lid_14_list):
            d_ib = d_dat[fb_lid_14].reshape(-1)  # view
            indices_ibj_0 = d_ib < zero_tol
            indices_ibj_pos = d_ib >= zero_tol
            if np.any(indices_ibj_0):  # any valid observations?
                fb_lid_14_indi_0 = fb_lid_14[indices_ibj_0]
                n_x_i_0 = len(fb_lid_14_indi_0)
                weights_ij_np[fb_lid_14_indi_0, 0] += 1 / n_x_i_0
                leaf_0_complete = True
            if np.any(indices_ibj_pos):  # any valid observations?
                fb_lid_14_indi_pos = fb_lid_14[indices_ibj_pos]
                n_x_i_pos = len(fb_lid_14_indi_pos)
                weights_ij_np[fb_lid_14_indi_pos, jdx+1] += 1 / n_x_i_pos
            else:
                leaf_pos_complete = False
                break
        leaf_complete = leaf_0_complete and leaf_pos_complete

        if not leaf_complete:
            empty_leaf, weights_ij_np = True, 0

    return weights_ij_np, empty_leaf


def weights_obs_i_inside_boot_treat_disc_triplets(forest_b: dict,
                                                  x_dat_i: NDArray[Any],
                                                  no_of_treat: int,
                                                  d_values: Sequence[int | float],
                                                  d_dat: NDArray[np.integer | np.floating], *,
                                                  bigdata_train: bool = False,
                                                  d_values_0_treatm1: bool = True,
                                                  zero_tol: float = 1e-10,
                                                  ) -> tuple[NDArray[np.intp], NDArray[np.intp],
                                                             NDArray[np.floating], bool
                                                             ]:
    """Allow for MP at bootstrap level (intermediate procedure).

    Like weights_obs_i_inside_boot_treat_disc but returns (rows, cols, vals,
    empty).
    Memory-light: only len(leaf_inds) elements are produced.
    """
    dtype_float = np.float32 if bigdata_train else np.float64
    if not d_values_0_treatm1:
        d_dat = encode_treatments(d_dat, d_values, zero_tol=zero_tol)

    empty_flags = forest_b['fill_y_empty_leave']
    inds_list = forest_b['fill_y_indices_list']

    leaf_id = mcf_fo_add.get_terminal_leaf_no(forest_b, x_dat_i)
    leaf_inds = inds_list[leaf_id]
    if empty_flags[leaf_id] == 1 or leaf_inds is None:
        return (np.empty(0, dtype=np.intp), np.empty(0, dtype=np.intp),
                np.empty(0, dtype=dtype_float), True,
                )
    leaf_inds = np.asarray(leaf_inds, dtype=np.intp)
    if leaf_inds.size == 0:
        return leaf_inds, leaf_inds, np.empty(0, dtype=dtype_float), True

    # --- Build column indices d_leaf (0..no_of_treat-1) ---
    d_leaf = np.asarray(d_dat[leaf_inds], dtype=np.intp).ravel()

    # --- Completeness & per-observation weights ---
    counts = np.bincount(d_leaf, minlength=no_of_treat)

    if (counts[:no_of_treat] == 0).any():
        return leaf_inds, d_leaf, np.empty(0, dtype=dtype_float), True

    vals = (1.0 / counts[d_leaf]).astype(dtype_float, copy=False)

    return leaf_inds, d_leaf, vals, False


def weights_obs_i_inside_boot_treat_disc(forest_b: dict, *,
                                         x_dat_i: NDArray[Any],
                                         n_y: int,
                                         no_of_treat: int,
                                         d_values: Sequence[int | float],
                                         d_dat: NDArray[np.integer | np.floating],
                                         treat_is_integer: bool = True,
                                         bigdata_train: bool = False,
                                         out_buffer: NDArray[np.floating] | None = None,
                                         # Predefined out_buffer to reduce memory allocation time
                                         d_values_0_treatm1: bool = True,
                                         zero_tol: float = 1e-10,
                                         ) -> tuple[NDArray[np.floating] | int, bool]:
    """Allow for MP at bootstrap level (intermediate procedure)."""
    # This function is used in the default computations.
    if not d_values_0_treatm1:
        d_dat = encode_treatments(d_dat, d_values, zero_tol=zero_tol)
        treat_is_integer = True                  # safe from now on
    empty_flags = forest_b['fill_y_empty_leave']
    inds_list = forest_b['fill_y_indices_list']

    leaf_id = mcf_fo_add.get_terminal_leaf_no(forest_b, x_dat_i)
    leaf_inds = inds_list[leaf_id]
    if empty_flags[leaf_id] == 1 or leaf_inds is None:
        return 0, True

    leaf_inds = np.asarray(leaf_inds, dtype=np.intp)
    if leaf_inds.size == 0:
        return 0, True

    # 1) pull out the raw treatment slice
    if treat_is_integer:
        d_leaf = np.asarray(d_dat[leaf_inds], dtype=np.intp).ravel()
    else:
        raw = d_dat[leaf_inds]
        # 2) make sure we get a 1-D int array
        if raw.dtype == object:
            # each element is likely an array/sequence → concatenate
            d_leaf = np.concatenate([np.asarray(r).ravel() for r in raw])
        else:
            # a normal numeric slice → just flatten
            d_leaf = raw.ravel()
        # d_leaf = d_leaf.astype(int)  23.10.2025
        d_leaf = np.asarray(d_leaf, dtype=np.intp, copy=False)

    # 3) count and check completeness
    counts = np.bincount(d_leaf, minlength=no_of_treat)
    if (counts[:no_of_treat] == 0).any():
        return 0, True

    # 4) per-obs weight and scatter
    dtype = np.float32 if bigdata_train else np.float64
    if out_buffer is None:
        weights = np.zeros((n_y, no_of_treat), dtype=dtype)
    else:
        if out_buffer.shape != (n_y, no_of_treat):
            raise ValueError(f'out_buffer has wrong shape; expected {n_y, no_of_treat}')
        if out_buffer.dtype != dtype:
            raise TypeError(f'out_buffer has wrong dtype; expected {dtype} got {out_buffer.dtype}')
        weights = out_buffer
        weights.fill(0)
    per_obs = (1.0 / counts[d_leaf]).astype(weights.dtype, copy=False)
    weights[leaf_inds, d_leaf] = per_obs

    return weights, False


def final_trans(weights_i_np: NDArray[Any],
                no_of_treat: int,
                normalize: bool = True
                ) -> list[list[NDArray[Any]]]:
    """
    Compute last transformations of (positive only) weights.

    Returns a list of (indices, weights) pairs for each treatment.
    Row positions identify observations in the forest's outcome sample.

    Parameters
    ----------
    weights_i_np : 2D Numpy array. One column per treatment, without an index column.
    no_of_treat : Int. Number of treatments.
    normalize : Bool. Normalize each treatment's weights to sum to 1. Default is True.

    Returns
    -------
    weights_i: List of arrays.
    """
    if weights_i_np.ndim != 2 or weights_i_np.shape[1] != no_of_treat:
        raise ValueError('weights_i_np must have one column per treatment and no index column.')

    index_dtype = np.int32 if weights_i_np.shape[0] - 1 <= np.iinfo(np.int32).max else np.int64
    weights_i: list[list[NDArray[Any]]] = []

    for j in range(no_of_treat):
        col = weights_i_np[:, j]
        mask = col > 1e-14
        sel_idx = np.flatnonzero(mask).astype(index_dtype, copy=False)

        if sel_idx.size:
            sel_w = col[mask]
            if normalize:
                total = sel_w.sum()
                if total > 0:
                    sel_w = sel_w / total
            sel_w = sel_w.astype(np.float32)
        else:
            sel_w = np.empty(0, dtype=np.float32)

        weights_i.append([sel_idx, sel_w])

    return weights_i


def final_trans_from_triplets(rows_parts: list[NDArray[np.integer]],
                              cols_parts: list[NDArray[np.integer]],
                              vals_parts: list[NDArray[np.floating]], *,
                              n_y: int,
                              no_of_treat: int,
                              normalize: bool = True,
                              zero_tol: float = 1e-14,
                              ) -> list[list[NDArray[Any]]]:
    """Convert bootstrap triplets into per-treatment sparse weight lists.

    This replaces the dense n_y x no_of_treat accumulator for discrete treatments.
    """
    if not rows_parts:
        return [[np.empty(0, dtype=np.int32), np.empty(0, dtype=np.float32)]
                for _ in range(no_of_treat)
                ]
    rows = np.concatenate(rows_parts).astype(np.int64, copy=False)
    cols = np.concatenate(cols_parts).astype(np.int64, copy=False)
    vals = np.concatenate(vals_parts).astype(np.float64, copy=False)

    if not rows.size == cols.size == vals.size:
        raise RuntimeError(f'Triplet length mismatch: rows={rows.size}, cols={cols.size}, '
                           f'vals={vals.size}'
                           )
    if rows.size == 0:
        return [[np.empty(0, dtype=np.int32), np.empty(0, dtype=np.float32)]
                for _ in range(no_of_treat)
                ]
    if rows.min() < 0 or rows.max() >= n_y:
        raise RuntimeError(f'Triplet row index out of range: '
                           f'min={rows.min()}, max={rows.max()}, n_y={n_y}'
                           )
    if cols.min() < 0 or cols.max() >= no_of_treat:
        raise RuntimeError(f'Triplet treatment index out of range: '
                           f'min={cols.min()}, max={cols.max()}, no_of_treat={no_of_treat}'
                           )
    # Reuse the local concatenated columns; no input part is modified.
    key = cols
    key *= int(n_y)
    key += rows
    del rows, cols

    unique_key, inverse = np.unique(key, return_inverse=True)
    del key
    summed_vals = np.bincount(inverse, weights=vals)
    del inverse, vals

    keep = np.abs(summed_vals) > zero_tol
    unique_key = unique_key[keep]
    summed_vals = summed_vals[keep]

    del keep
    weights_i: list[list[NDArray[Any]]] = []
    start = 0

    # Sorted keys put each treatment's outcome indices in one contiguous slice.
    for t_idx in range(no_of_treat):
        stop = int(np.searchsorted(unique_key, (t_idx + 1) * int(n_y)))
        sel_idx = (unique_key[start:stop] - t_idx * int(n_y)).astype(np.int32, copy=False)
        sel_w = summed_vals[start:stop]
        start = stop

        if normalize and sel_w.size:
            total = sel_w.sum()
            if total > 0:
                sel_w = sel_w / total

        weights_i.append([sel_idx, sel_w.astype(np.float32, copy=False),])

    return weights_i


def weights_to_csr(weights: list[_SparseWeightBuilder],
                   no_of_treat: int,
                   ) -> list[sparse.csr_array]:
    """Consume the row builders into CSR arrays, one treatment at a time."""
    return [weights[d_idx].to_csr() for d_idx in range(no_of_treat)]


# @ray.remote
def _ray_weights_many_obs_i_impl(idx_list: list[int],
                                 n_y: int,
                                 forest: list[list],
                                 x_dat: NDArray[Any],
                                 d_dat: NDArray[Any], *,
                                 cf_cfg: 'CfCfg', ct_cfg: 'CtGrid', gen_cfg: 'GenCfg',
                                 int_cfg: 'IntCfg',
                                 split_forest: bool = False,
                                 treat_is_integer: bool = True,
                                 d_values_0_treatm1: bool = True,
                                 ) -> tuple[Any]:
    """Make function compatible with Ray."""
    return weights_many_obs_i(idx_list, n_y, forest, x_dat, d_dat, cf_cfg=cf_cfg,
                              ct_cfg=ct_cfg, gen_cfg=gen_cfg, int_cfg=int_cfg,
                              split_forest=split_forest, treat_is_integer=treat_is_integer,
                              d_values_0_treatm1=d_values_0_treatm1,
                              )


ray_weights_many_obs_i = ray.remote(_ray_weights_many_obs_i_impl) if ray is not None else None


def weights_many_obs_i(idx_list: list[int],
                       n_y: int,
                       forest: list[list],
                       x_dat: NDArray[Any],
                       d_dat: NDArray[Any], *,
                       cf_cfg: 'CfCfg', ct_cfg: 'CtGrid', gen_cfg: 'GenCfg', int_cfg: 'IntCfg',
                       split_forest=False,
                       treat_is_integer=True,
                       d_values_0_treatm1: bool = True,
                       ) -> tuple[list[int], list[list], int]:
    """
    Create chunks of task to be efficiently executed by MP.

    Parameters
    ----------
    idx_list : List of Int. Counter.
    n_y: Int. Length of training data.
    forest : List of Lists.
    x_dat : Numpy array. Prediction sample.
    d_dat: Numpy array. Training sample.
    cf_cfg, ct_cfg, gen_cfg : DataClasses. Parameters
    split_forest : Boolean. True if chunks of bootstraps. Default is False.
    ...

    Returns
    -------
    idx : List of Int. Int. Counter.
    weights : List of lists.
    empty_leaf_counter : Int.

    """
    weights = [None for _ in range(len(idx_list))]
    empty_leaf_counter = 0
    for idx, val in enumerate(idx_list):
        ret = weights_obs_i(val, n_y, forest, x_dat, d_dat,
                            cf_cfg=cf_cfg, ct_cfg=ct_cfg, gen_cfg=gen_cfg, int_cfg=int_cfg,
                            mp_over_boots=False, maxworkers=1,
                            split_forest=split_forest,
                            treat_is_integer=treat_is_integer,
                            d_values_0_treatm1=d_values_0_treatm1,
                            )
        weights[idx] = ret[1]
        empty_leaf_counter += ret[2]

    return idx_list, weights, empty_leaf_counter


def encode_treatments(d_dat: NDArray[np.floating | np.integer],
                      d_values: Sequence[int | float],
                      zero_tol: float = 1e-10,
                      ) -> NDArray[np.intp]:
    """Map labels in d_dat to 0..T-1 according to the order in d_values.

    Raises if d_dat contains a label not present in d_values.
    Works for numeric d_dat (int/float). For object arrays, see note below.
    """
    dv = np.asarray(d_values)
    dvsize = dv.size

    # Fast path: already 0..T-1 in the right order
    if np.issubdtype(dv.dtype, np.integer) and np.array_equal(dv, np.arange(dvsize)):
        return np.asarray(d_dat, dtype=np.intp)

    # General path: sort d_values and map via searchsorted (O(N log T))
    order = np.argsort(dv)
    dv_sorted = dv[order]

    raw = np.asarray(d_dat).ravel()
    pos = np.searchsorted(dv_sorted, raw)
    pos_clip = np.minimum(pos, dvsize - 1)

    in_range = ((pos < dvsize)
                & np.isclose(dv_sorted[pos_clip], raw, atol=zero_tol, rtol=zero_tol)
                )
    if not in_range.all():
        bad = np.unique(raw[~in_range])
        raise ValueError(f'Unknown treatment label(s) in d_dat: {bad!r}')

    # Map positions in the sorted labels back to the original treatment order.
    codes = order[pos].astype(np.intp, copy=False)

    return codes.reshape(np.shape(d_dat))


def sparse_row_indices_weights(weight_mat: Any,
                               row_idx: int,
                               ) -> tuple[NDArray[np.integer], NDArray[np.floating]]:
    """Extract nonzero column indices and values from one sparse row.

    Works for both scipy sparse matrices and sparse arrays.
    """
    if hasattr(weight_mat, 'getrow'):
        row = weight_mat.getrow(row_idx)
    else:
        # csr_array has no getrow(); slicing keeps the result 2-dimensional.
        row = weight_mat[row_idx: row_idx + 1, :]

    row = row.tocsr()

    return row.indices.copy(), row.data.copy()
