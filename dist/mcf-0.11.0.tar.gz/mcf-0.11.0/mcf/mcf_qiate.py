"""
Created on Fri Oct 11 14:13:30 2024.

@author: MLechner

Contains additional functions needed for computing the QIATE.

@author: MLechner
-*- coding: utf-8 -*-
"""

from itertools import compress
from os import remove
from pathlib import Path
from textwrap import fill
from typing import Any, TYPE_CHECKING
import warnings

import numpy as np
from numpy.typing import NDArray
import matplotlib.pyplot as plt
try:
    import ray
except (ImportError, OSError):
    ray = None
import pandas as pd
from scipy.stats import norm
from scipy.interpolate import PchipInterpolator
try:
    from tqdm.auto import tqdm
except ImportError:
    tqdm = None

from mcf import mcf_ate
from mcf import mcf_estimation as mcf_est
from mcf import mcf_general_sys as mcf_sys
from mcf import mcf_print_stats as mcf_ps
from mcf import mcfoptp_parallel_backend_ray_classical as mcf_ray
from mcf.mcf_estimation_generic import bandwidth_nw_rule_of_thumb
from mcf.mcf_estimation_generic import kernel_proc
from mcf.mcf_general import (bound_norm_weights, bound_norm_weights_not_one, progress_clean_memory,
                             tqdm_setup,
                             )
from mcf.mcf_weight import sparse_row_indices_weights
from mcf.mcfoptp_parallel_backend_forest_executor import (forest_executor_with_shared,
                                                          map_task_batches,
                                                          )
from mcf.mcfoptp_parallel_backends_base import TaskSpec

if TYPE_CHECKING:
    from mcf.mcf_main import ModifiedCausalForest
    from mcf.mcf_init import GenCfg, IntCfg
    from mcf.mcf_init_predict import PCfg


def qiate_est(mcf_: 'ModifiedCausalForest',
              data_df: pd.DataFrame,
              weights_dic: dict,
              y_pot: NDArray[Any], *,
              y_pot_var: NDArray | None = None,
              with_output: bool = True,
              iv: bool = False,
              ) -> tuple[NDArray[Any], NDArray[Any] | None,
                         NDArray[Any], NDArray[Any] | None,
                         NDArray[Any], NDArray[Any] | None,
                         dict,
                         str
                         ]:
    """Estimate QIATEs and their standard errors."""
    gen_cfg, int_cfg = mcf_.gen_cfg, mcf_.int_cfg
    p_cfg, var_cfg, p_ba_cfg = mcf_.p_cfg, mcf_.var_cfg, mcf_.p_ba_cfg
    zero_tol = int_cfg.zero_tol
    output_yes = gen_cfg.with_output and gen_cfg.verbose and with_output
    use_tqdm, output_clean = tqdm_setup(tqdm, output_yes)

    if gen_cfg.with_output and gen_cfg.verbose and with_output:
        print('\nComputing QIATE')

    if gen_cfg.d_type == 'continuous':
        raise NotImplementedError('QIATE only implemented for discrete treatments. Maybe (!) '
                                  'support for continuous treatments will be added in the future.'
                                  )
    y_dat, weights_all, w_dat, cl_dat = assign_data(weights_dic, gen_cfg, p_cfg)
    d_p, _, w_p, _ = mcf_ate.get_data_for_final_ate_estimation(data_df,
                                                               gen_cfg, p_cfg, var_cfg,
                                                               ate=False, need_count=False,
                                                               )
    n_y, no_of_out = len(y_dat), len(var_cfg.y_name)

    no_of_treat, t_probs = gen_cfg.no_of_treat, p_cfg.choice_based_probs
    treat_comp_label = get_comparison_labels(no_of_treat, gen_cfg.d_values)
    i_d_val = np.arange(no_of_treat)

    # Define dictionary that relates the respective treatment comparison and
    # outcome variable to the order for this particular IATE (
    # & get that quantile data)
    iate_q_np, iate_q_key_dic = get_iate_order(y_pot, y_pot_var, no_of_treat, no_of_out, p_cfg)
    if p_cfg.qiate_smooth:
        bandwidth_nw, kernel_nw = get_nadarya_watson_parameters(iate_q_np[:, 0, 0],
                                                                p_cfg.qiate_smooth_bandwidth,
                                                                zero_tol=int_cfg.zero_tol,
                                                                )
    else:
        bandwidth_nw = kernel_nw = None

    # Initialize q-variables, comparison specific potential outcomes, weights
    q_values = p_cfg.qiate_quantiles
    no_of_q_values = len(q_values)
    (y_pot, y_pot_var, y_pot_mmed, y_pot_mmed_var, y_pot_mopp, y_pot_mopp_var
     ) = initialise_pot_qiate(no_of_q_values, len(iate_q_key_dic), no_of_out)
    # 3rd dimension of y_pot contains both POs of QIATE for respective
    # comparisons
    w_qiate, w_qiate_unc, w_censored, _ = initialise_weights_qiate(no_of_q_values,
                                                                   len(iate_q_key_dic), n_y,
                                                                   no_of_out,
                                                                   )
    # Optimisations concerning the use of the weights matrix and ray.
    files_to_delete, _, weights_all, maxworkers, txt = optimize_initialize_mp_qiate(weights_all,
                                                                                    gen_cfg,
                                                                                    int_cfg,
                                                                                    with_output
                                                                                    )
    # Define some tuples needed for QIATE-potential outcome computation
    data = (y_dat, cl_dat, w_dat, d_p, w_p,)
    iate_q = (iate_q_np, iate_q_key_dic,)
    dics = (gen_cfg, int_cfg, p_cfg, p_ba_cfg,)
    parameters = (i_d_val, t_probs, no_of_out, bandwidth_nw, kernel_nw, p_cfg.qiate_m_mqiate,
                  p_cfg.qiate_m_opp,
                  )
    # Types and dimension of important variables
    # - QIATE Weights (for potential outcomes):
    # -- w_qiate, w_qiate_unc: 5D arrays (no_of_qval,no_of_comp,2,n_y,no_of_out)
    # -- w_censored: 4D array            (no_of_qval, no_of_comp, 2, no_of_out))
    # -- w_median: 4D array              (no_of_comparisons, 2, n_y, no_of_out)
    # Potential outcomes
    # - y_pot, y_pot_var, y_pot_mmed, y_pot_mmed_var
    # -- 4D array:                 (no_of_qval, no_of_comparisons, 2, no_of_out)

    # 1st step-(i): Compute weights of median (if needed; no multiprocessing)
    if p_cfg.qiate_m_mqiate or p_cfg.qiate_m_opp:
        parameters_diff = (*parameters[:5], False, False)
        w_qiate_0, w_qiate_unc_0 = w_qiate[0].copy(), w_qiate_unc[0].copy()
        w_censored_0 = w_censored[0].copy()
        qiate_weights_q = (w_qiate_0, w_qiate_unc_0, w_censored_0, None, None)
    else:
        qiate_weights_q = parameters_diff = None
    # 1st step-(ii): Compute weights of quantile difference
    if p_cfg.qiate_m_mqiate:
        _, _, _, _, _, _, _, w_median, _, _ = qiate_q(0.5, 0, data, weights_all,
                                                      iate_q=iate_q,
                                                      qiate_weights_q=qiate_weights_q,
                                                      pot_q=None, dics=dics,
                                                      parameters=parameters_diff,
                                                      iv=iv, weights_only=True, zero_tol=zero_tol,
                                                      )
    else:
        y_pot_mmed = y_pot_mmed_var = w_median = None

    # Compute weights to get quantile differences later on
    w_mopp_list = [None] * no_of_q_values

    if maxworkers > 1:
        w_qiate_dim = w_qiate[0].shape
        w_qiate_unc_dim = w_qiate_unc[0].shape
        w_censored_dim = w_censored[0].shape

    kw_args = {'iate_q': iate_q, 'pot_q': None,  'dics': dics, 'parameters': parameters_diff,
               'iv': iv, 'weights_only': True, 'zero_tol': zero_tol,
               }
    if p_cfg.qiate_m_opp:
        if maxworkers == 1:
            for q_idx, q_value in enumerate(q_values):
                qiate_weights_q = w_qiate[q_idx], w_qiate_unc[q_idx], w_censored[q_idx], None, None
                (_, _, _, _, _, _, _, w_mopp_list[q_idx], _, _
                 ) = qiate_q(q_value, q_idx, data, weights_all,
                             **kw_args,
                             qiate_weights_q=qiate_weights_q,
                             )
        else:
            if int_cfg.mp_use_old_ray:
                if ray is None or ray_qiate_mp is None:
                    raise ImportError('int_cfg.mp_use_old_ray=True, but ray is not installed. '
                                      'Install ray or use the new backend with '
                                      'mp_use_old_ray=False.'
                                      )
                data_ref = mcf_ray.ray_put_all(data)
                still_running = [ray_qiate_mp.remote(q_value, q_idx, data_ref, weights_all,
                                                     **kw_args,
                                                     qiate_weights_q=(w_qiate_dim, w_qiate_unc_dim,
                                                                      w_censored_dim, None, None),
                                                     )
                                 for q_idx, q_value in enumerate(q_values)
                                 ]
                idx = 1
                w_qiate0 = w_qiate.copy()
                w_qiate_unc0 = w_qiate_unc.copy()
                w_censored0 = w_censored.copy()
                pbar = tqdm(total=no_of_q_values,
                            desc='QIATE weights') if use_tqdm else None
                try:
                    while len(still_running) > 0:
                        finished, still_running = ray.wait(still_running, num_returns=1)
                        finished_res = ray.get(finished)
                        for results_fut_idx in finished_res:
                            q_idx = results_fut_idx[8]
                            w_qiate0, w_qiate_unc0, w_censored0 = assign_w_q(
                                w_qiate0, w_qiate_unc0, w_censored0,
                                results_fut_idx, q_idx,
                                )
                            w_mopp_list[q_idx] = w_qiate_unc0[q_idx].copy()
                            if pbar is not None:
                                pbar.update()
                            progress_clean_memory(output=output_clean,
                                                  current_idx=idx,
                                                  total=no_of_q_values,
                                                  )
                            idx += 1
                finally:
                    if pbar is not None:
                        pbar.close()
            else:
                ray_err_txt = 'Ray does not start in QIATE estimation.'
                fail_txt = 'Failed to make executor in QIATE estimation.'
                with forest_executor_with_shared(int_cfg=int_cfg, maxworkers=maxworkers,
                                                 shared_obj=data, shared_name='qiate_data',
                                                 ray_err_txt=ray_err_txt, fail_txt=fail_txt,
                                                 ) as (executor, data_handle, maxworkers):
                    tasks = [TaskSpec(func=qiate_mp_backend,
                                      kwargs={'q_value': q_value,
                                              'q_idx': q_idx,
                                              'data': data_handle,
                                              'weights_all': weights_all,
                                              'kw_args': kw_args,
                                              'qiate_weights_q': (w_qiate_dim, w_qiate_unc_dim,
                                                                  w_censored_dim, None, None,),
                                              },
                                      name=f'qiate_{q_idx}',
                                      )
                             for q_idx, q_value in enumerate(q_values)
                             ]
                    idx = 1
                    w_qiate0 = w_qiate.copy()
                    w_qiate_unc0 = w_qiate_unc.copy()
                    w_censored0 = w_censored.copy()

                    result_iter = map_task_batches(executor=executor,
                                                   tasks=tasks,
                                                   int_cfg=int_cfg,
                                                   maxworkers=maxworkers,
                                                   min_worker_waves=(
                                                       4 if int_cfg.mp_backend == 'joblib' else 1
                                                       ),
                                                   )
                    if use_tqdm:
                        result_iter = tqdm(result_iter, total=len(q_values), desc='QIATE weights')

                    for results_fut_idx in result_iter:
                        q_idx = results_fut_idx[8]
                        w_qiate0, w_qiate_unc0, w_censored0 = assign_w_q(w_qiate0, w_qiate_unc0,
                                                                         w_censored0,
                                                                         results_fut_idx, q_idx,
                                                                         )
                        w_mopp_list[q_idx] = w_qiate_unc0[q_idx].copy()

                        progress_clean_memory(output=output_clean,
                                              current_idx=idx, total=len(q_values),
                                              )
                        idx += 1

            del w_qiate0, w_qiate_unc0, w_censored0
    else:
        y_pot_mopp = y_pot_mopp_var = None

    # 2nd step: All quantiles and all effects (i)
    kw_args = {'iate_q': iate_q, 'dics': dics, 'parameters': parameters, 'iv': iv,
               'zero_tol': zero_tol,
               }
    if maxworkers == 1:
        for q_idx, q_value in enumerate(q_values):
            q_idx_opp = no_of_q_values - 1 - q_idx
            qiate_weights_q = (w_qiate[q_idx], w_qiate_unc[q_idx], w_censored[q_idx], w_median,
                               w_mopp_list[q_idx_opp],
                               )
            if p_cfg.qiate_m_mqiate:
                y_pot_mmed_q_idx = y_pot_mmed[q_idx]
                y_pot_mmed_var_q_idx = y_pot_mmed_var[q_idx]
            else:
                y_pot_mmed_q_idx = y_pot_mmed_var_q_idx = None

            if p_cfg.qiate_m_opp:
                y_pot_mopp_q_idx = y_pot_mopp[q_idx]
                y_pot_mopp_var_q_idx = y_pot_mopp_var[q_idx]
            else:
                y_pot_mopp_q_idx = y_pot_mopp_var_q_idx = None

            pot_q = (y_pot[q_idx], y_pot_var[q_idx],
                     y_pot_mmed_q_idx, y_pot_mmed_var_q_idx,
                     y_pot_mopp_q_idx, y_pot_mopp_var_q_idx
                     )
            results_fut_q = qiate_q(q_value, q_idx, data, weights_all,
                                    qiate_weights_q=qiate_weights_q, pot_q=pot_q,
                                    **kw_args,
                                    )
            y_pot, y_pot_var, y_pot_mmed, y_pot_mmed_var, y_pot_mopp, y_pot_mopp_var = assign_pot_q(
                 y_pot, y_pot_var,
                 y_pot_mmed=y_pot_mmed, y_pot_mmed_var=y_pot_mmed_var, y_pot_mopp=y_pot_mopp,
                 y_pot_mopp_var=y_pot_mopp_var, results_fut_q=results_fut_q, q_idx=q_idx,
                 qiate_m_mqiate=p_cfg.qiate_m_mqiate, qiate_m_opp=p_cfg.qiate_m_opp,
                 )
            w_qiate, w_qiate_unc, w_censored = assign_w_q(w_qiate, w_qiate_unc, w_censored,
                                                          results_fut_q, q_idx,
                                                          )
    else:
        y_pot_dim, y_pot_var_dim = y_pot[0].shape, y_pot_var[0].shape
        if y_pot_mmed is None:
            y_pot_mmed_dim = y_pot_mmed_var_dim = None
        else:
            y_pot_mmed_dim = y_pot_mmed[0].shape
            y_pot_mmed_var_dim = y_pot_mmed_var[0].shape
        if y_pot_mopp is None:
            y_pot_mopp_dim = y_pot_mopp_var_dim = None
        else:
            y_pot_mopp_dim = y_pot_mopp[0].shape
            y_pot_mopp_var_dim = y_pot_mopp_var[0].shape

        if int_cfg.mp_use_old_ray:
            if ray is None or ray_qiate_mp is None:
                raise ImportError('int_cfg.mp_use_old_ray=True, but ray is not installed. '
                                  'Install ray or use the new backend with mp_use_old_ray=False.'
                                  )
            data_ref = mcf_ray.ray_put_all(data)

            pot_q = (y_pot_dim, y_pot_var_dim, y_pot_mmed_dim, y_pot_mmed_var_dim, y_pot_mopp_dim,
                     y_pot_mopp_var_dim,
                     )
            still_running = [ray_qiate_mp.remote(q_value, q_idx, data_ref, weights_all,
                                                 pot_q=pot_q,
                                                 qiate_weights_q=(w_qiate_dim, w_qiate_unc_dim,
                                                                  w_censored_dim, w_median,
                                                                  w_mopp_list[no_of_q_values - 1
                                                                              - q_idx],
                                                                  ),
                                                 weights_only=False,
                                                 **kw_args,
                                                 )
                             for q_idx, q_value in enumerate(q_values)
                             ]
            idx = 1
            pbar = tqdm(total=no_of_q_values, desc='QIATE') if use_tqdm else None
            try:
                while len(still_running) > 0:
                    finished, still_running = ray.wait(still_running, num_returns=1)
                    finished_res = ray.get(finished)
                    for results_fut_idx in finished_res:
                        q_idx = results_fut_idx[8]
                        (y_pot, y_pot_var, y_pot_mmed, y_pot_mmed_var,
                         y_pot_mopp, y_pot_mopp_var) = assign_pot_q(
                             y_pot, y_pot_var,
                             y_pot_mmed=y_pot_mmed,
                             y_pot_mmed_var=y_pot_mmed_var,
                             y_pot_mopp=y_pot_mopp,
                             y_pot_mopp_var=y_pot_mopp_var,
                             results_fut_q=results_fut_idx,
                             q_idx=q_idx,
                             qiate_m_mqiate=p_cfg.qiate_m_mqiate,
                             qiate_m_opp=p_cfg.qiate_m_opp,
                             )
                        w_qiate, w_qiate_unc, w_censored = assign_w_q(
                            w_qiate, w_qiate_unc, w_censored,
                            results_fut_idx, q_idx,
                            )
                        if pbar is not None:
                            pbar.update()
                        progress_clean_memory(output=output_clean,
                                              current_idx=idx,
                                              total=no_of_q_values,
                                              )
                        idx += 1
            finally:
                if pbar is not None:
                    pbar.close()
            *_, finished_res, finished = mcf_ray.ray_del_refs(f1=finished_res, f2=finished,
                                                              mp_ray_del=int_cfg.mp_ray_del,
                                                              )
        else:
            ray_err_txt='Ray does not start in full QIATE estimation.'
            fail_txt='Failed to make executor in full QIATE estimation.'
            with forest_executor_with_shared(int_cfg=int_cfg,
                                             maxworkers=maxworkers,
                                             shared_obj=data,
                                             shared_name='qiate_full_data',
                                             ray_err_txt=ray_err_txt, fail_txt=fail_txt,
                                             ) as (executor, data_handle, maxworkers):
                tasks = [TaskSpec(func=qiate_mp_full_backend,
                                  kwargs={'q_value': q_value,
                                          'q_idx': q_idx,
                                          'data': data_handle,
                                          'weights_all': weights_all,
                                          'qiate_weights_q': (w_qiate_dim, w_qiate_unc_dim,
                                                              w_censored_dim, w_median,
                                                              w_mopp_list[no_of_q_values-1-q_idx],),
                                          'pot_q': (y_pot_dim, y_pot_var_dim, y_pot_mmed_dim,
                                                    y_pot_mmed_var_dim, y_pot_mopp_dim,
                                                    y_pot_mopp_var_dim,),
                                          'kw_args': kw_args,
                                          },
                                  name=f'qiate_full_{q_idx}',
                                  )
                         for q_idx, q_value in enumerate(q_values)
                         ]
                idx = 1
                result_iter = map_task_batches(executor=executor,
                                               tasks=tasks,
                                               int_cfg=int_cfg,
                                               maxworkers=maxworkers,
                                               min_worker_waves=(4 if int_cfg.mp_backend == 'joblib'
                                                                 else 1
                                                                 ),
                                               )
                if use_tqdm:
                    result_iter = tqdm(result_iter, total=len(q_values), desc='QIATE')

                for results_fut_idx in result_iter:
                    q_idx = results_fut_idx[8]
                    (y_pot, y_pot_var, y_pot_mmed, y_pot_mmed_var, y_pot_mopp, y_pot_mopp_var,
                     ) = assign_pot_q(y_pot, y_pot_var,
                                      y_pot_mmed=y_pot_mmed, y_pot_mmed_var=y_pot_mmed_var,
                                      y_pot_mopp=y_pot_mopp, y_pot_mopp_var=y_pot_mopp_var,
                                      results_fut_q=results_fut_idx, q_idx=q_idx,
                                      qiate_m_mqiate=p_cfg.qiate_m_mqiate,
                                      qiate_m_opp=p_cfg.qiate_m_opp,
                                      )
                    w_qiate, w_qiate_unc, w_censored = assign_w_q(w_qiate, w_qiate_unc, w_censored,
                                                                  results_fut_idx, q_idx,
                                                                  )
                    progress_clean_memory(output=output_clean,
                                          current_idx=idx, total=no_of_q_values,
                                          )
                    idx += 1

    if files_to_delete:  # delete temporary files
        for file in files_to_delete:
            remove(file)

    qiate_est_dic = {'d_values': gen_cfg.d_values,
                     'no_of_out': no_of_out,
                     'var_cfg': var_cfg,
                     'q_values': q_values,
                     'ref_pop_lab': 'All',
                     'iate_q_key_dic': iate_q_key_dic,
                     'p_cfg': p_cfg,
                     'treat_comp_label': treat_comp_label
                     }
    return (y_pot, y_pot_var, y_pot_mmed, y_pot_mmed_var, y_pot_mopp, y_pot_mopp_var, qiate_est_dic,
            txt
            )


def qiate_mp_backend(*, q_value: Any,
                     q_idx: int,
                     data: Any,
                     weights_all: Any,
                     kw_args: dict[str, Any],
                     qiate_weights_q: tuple[Any, Any, Any, Any, Any],
                     ) -> Any:
    """Backend-agnostic wrapper for one QIATE task."""
    return qiate_q(q_value, q_idx, data, weights_all,
                   **kw_args,
                   qiate_weights_q=qiate_weights_q,
                   multi_ray=True,
                   )


def qiate_mp_full_backend(*, q_value: Any,
                          q_idx: int,
                          data: Any,
                          weights_all: Any,
                          qiate_weights_q: tuple[Any, Any, Any, Any, Any],
                          pot_q: tuple[Any, Any, Any, Any, Any, Any],
                          kw_args: dict[str, Any],
                          ) -> Any:
    """Backend-agnostic wrapper for one full QIATE task."""
    return qiate_q(q_value, q_idx, data, weights_all, qiate_weights_q=qiate_weights_q, pot_q=pot_q,
                   weights_only=False, **kw_args, multi_ray=True,
                   )


# @ray.remote
def _ray_qiate_mp_impl(q_value: list[float] | NDArray[np.floating | float],
                       q_value_idx: Any,
                       data: tuple[NDArray[Any], ...],
                       weights_all: Any, *,
                       iate_q: tuple[NDArray[Any], dict],
                       qiate_weights_q: tuple[Any, ...],
                       pot_q: tuple[Any, ...],
                       dics: tuple[dict, ...],
                       parameters: tuple[Any],
                       iv: bool = False,
                       weights_only: bool = False,
                       zero_tol: float = 1e-10,
                       ) -> tuple[Any]:
    """Make function compatible with Ray."""
    return qiate_q(q_value, q_value_idx, data, weights_all,
                   iate_q=iate_q, qiate_weights_q=qiate_weights_q, pot_q=pot_q, dics=dics,
                   parameters=parameters, multi_ray=True, iv=iv, weights_only=weights_only,
                   zero_tol=zero_tol,
                   )


ray_qiate_mp = ray.remote(_ray_qiate_mp_impl) if ray is not None else None


def qiate_q(q_value: list[float] | NDArray[np.floating | float],
            q_value_idx: Any,
            data: tuple[NDArray[Any], ...],
            weights_all: Any, *,
            iate_q: tuple[NDArray[Any], dict],
            qiate_weights_q: tuple[Any, ...],
            pot_q: tuple[Any, ...],
            dics: tuple[dict, ...],
            parameters: tuple[Any],
            multi_ray: bool = False,
            iv: bool = False,
            weights_only: bool = False,
            zero_tol: float = 1e-10,
            ) -> tuple[Any, Any, Any, Any, Any, Any,
                       NDArray[Any], NDArray[Any], Any, NDArray[Any],
                       ]:
    """Compute QIATEs and their variances."""
    # Unpack variables
    y_dat, cl_dat, w_dat, d_p, w_p = data
    iate_q_np, iate_q_key_dic = iate_q
    gen_cfg, int_cfg, p_cfg, p_ba_cfg = dics
    sum_tol = int_cfg.sum_tol
    i_d_val, t_probs, no_of_out, bandw_q, kernel, qiate_m_mqiate, qiate_m_opp = parameters
    y_pot_q = y_pot_var_q = y_pot_mmed_q = y_pot_mmed_var_q = None
    y_pot_mopp_q = y_pot_mopp_var_q = None
    if multi_ray:  # Needed because object is otherwise 'read_only'
        w_qiate_q_dim, w_qiate_unc_q_dim, w_censored_q_dim, w_median, w_opp = qiate_weights_q
        w_qiate_q = np.zeros(w_qiate_q_dim)
        w_qiate_unc_q = np.zeros(w_qiate_unc_q_dim)
        w_censored_q = np.zeros(w_censored_q_dim)
        if not weights_only:
            (y_pot_q_dim, y_pot_var_q_dim, y_pot_mmed_q_dim, y_pot_mmed_var_q_dim, y_pot_mopp_q_dim,
             y_pot_mopp_var_q_dim,) = pot_q
            y_pot_q = np.zeros(y_pot_q_dim)
            y_pot_var_q = np.zeros(y_pot_var_q_dim)

            if y_pot_mmed_q_dim is None:
                y_pot_mmed_q = y_pot_mmed_var_q = None
            else:
                y_pot_mmed_q = np.zeros(y_pot_mmed_q_dim)
                y_pot_mmed_var_q = np.zeros(y_pot_mmed_var_q_dim)

            if y_pot_mopp_q_dim is None:
                y_pot_mopp_q = y_pot_mopp_var_q = None
            else:
                y_pot_mopp_q = np.zeros(y_pot_mopp_q_dim)
                y_pot_mopp_var_q = np.zeros(y_pot_mopp_var_q_dim)

    else:
        w_qiate_q, w_qiate_unc_q, w_censored_q, w_median, w_opp = qiate_weights_q

        if not weights_only:
            (y_pot_q, y_pot_var_q, y_pot_mmed_q, y_pot_mmed_var_q, y_pot_mopp_q, y_pot_mopp_var_q
             ) = pot_q

    # Define frequently used variables
    d_values = gen_cfg.d_values
    no_of_comp, n_y = len(iate_q_key_dic), len(y_dat)

    weights_q, relevant_data_q, w_q = get_w_rel_q(
        iate_q_np, iate_q_key_dic, q_value, weights_all,
        bandwidth=bandw_q, kernel_str=kernel, no_of_outcomes=no_of_out,
        w_is_csr=int_cfg.weight_as_sparse, zero_tol=int_cfg.zero_tol,
        )
    if gen_cfg.weighted:
        w_p_q = [[w_p[relevant_data_q[comparison][out_idx]]
                  for out_idx in range(no_of_out)]
                 for comparison in range(no_of_comp)]
    if p_cfg.choice_based_sampling:
        if d_p is None:
            raise ValueError('Choice-based sampling requires prediction treatments d_p.')
        d_p_main = np.asarray(d_p)
        if d_p_main.ndim > 1:
            d_p_main = d_p_main[:, 0]

        d_p_q = [[d_p_main[relevant_data_q[comparison][out_idx]]
                  for out_idx in range(no_of_out)] for comparison in range(no_of_comp)
                 ]
    else:
        d_p_q = None
    # Types and dimension of important variables
    # - QIATE Weights (for potential outcomes):
    # -- w_qiate_q, w_qiate_unc_q: 4D arr (no_of_comparisons, 2, n_y, no_of_out)
    # -- w_censored_q: 3D array           (no_of_comparisons, 2, no_of_out)
    # -- w_median: 4D array               (no_of_comparisons, 2, n_y, no_of_out)
    # -- w_opp: 4D array                  (no_of_comparisons, 2, n_y, no_of_out)
    # Potential outcomes
    # - y_pot_q, y_pot_var_q, y_pot_mmed_q, y_pot_mmed_var_q
    # -- 3D array:                        (no_of_comparisons, 2, no_of_out)

    # Weights: weights_q, relevant_data_q, w_q
    # Type: List (no_of_comparisons) of Lists (no_of_outcomes) of objects
    # - object of weights_q: List of 2 2D arrays (relevant n_p x n_y) (if crs)
    # - array of relevant_data_q: 1D of Boolean (all n_p elements)
    # - w_q:  1D of float (relevant n_p obs) - kernel weights in n_p

    # Step 1: Aggregate weights
    for out_idx in range(no_of_out):               # Outcomes
        for comp_idx in range(no_of_comp):         # Comparisons
            if int_cfg.weight_as_sparse:
                n_x = weights_q[comp_idx][out_idx][0].shape[0]
            else:
                n_x = len(weights_q[comp_idx][out_idx])
            for n_idx in range(n_x):               # relevant n_p observations
                for t_idx in range(2):             # Both relevant treatments
                    w_q_add = np.zeros((n_y))
                    if int_cfg.weight_as_sparse:
                        w_mat = weights_q[comp_idx][out_idx][t_idx]
                        w_index, w_i = sparse_row_indices_weights(w_mat, n_idx)
                    else:  # Ind weights > 0
                        w_index = weights_q[comp_idx][out_idx][n_idx][t_idx][0].copy()
                        w_i = weights_q[comp_idx][out_idx][n_idx][t_idx][1].copy()
                    if gen_cfg.weighted:
                        w_i = w_i * w_dat[w_index].reshape(-1)
                    w_i_sum = np.sum(w_i)
                    if abs(w_i_sum) > zero_tol and not 1-sum_tol < w_i_sum < 1+sum_tol:
                        w_i = w_i / w_i_sum
                    if gen_cfg.weighted:
                        w_i = w_i * w_p_q[comp_idx][out_idx][n_idx]
                    w_i = w_i * w_q[comp_idx][out_idx][n_idx]
                    if p_cfg.choice_based_sampling:
                        d_value = d_p_q[comp_idx][out_idx][n_idx]
                        i_pos = i_d_val[np.isclose(d_value, d_values, atol=zero_tol, rtol=zero_tol)]
                        if i_pos.size != 1:
                            raise ValueError('Could not uniquely identify treatment '
                                             f'{d_value!r} in d_values.'
                                             )
                        w_q_add[w_index] = w_i * t_probs[int(i_pos[0])]
                    else:
                        w_q_add[w_index] = w_i.copy()
                    w_qiate_q[comp_idx, t_idx, :, out_idx] += w_q_add

    # Step 2: Get potential outcomes for particular q_value
            sum_w_qiate_q = np.sum(w_qiate_q, axis=2)
            # regression bias adjustment is unsupported for QIATE.
            for t_idx in range(2):
                w_median_ = w_median[comp_idx, t_idx, :, out_idx] if w_median is not None else None
                w_opp_ = w_opp[comp_idx, t_idx, :, out_idx] if w_opp is not None else None

                (w_qiate_q[comp_idx, t_idx, :, out_idx], w_diff_med, w_diff_opp,
                 w_censored_q[comp_idx, t_idx, out_idx], w_qiate_unc_q[comp_idx, t_idx, :, out_idx]
                 ) = w_qiate_func(sum_w_qiate_q[comp_idx, t_idx, out_idx],
                                  w_qiate_q[comp_idx, t_idx, :, out_idx],
                                  w_censored_q[comp_idx, t_idx, out_idx],
                                  w_mmed=w_median_, w_mopp=w_opp_,
                                  compute_w_diff_med=qiate_m_mqiate,
                                  compute_w_diff_opp=qiate_m_opp,
                                  max_weight_share=p_cfg.max_weight_share,
                                  iv=iv, zero_tol=int_cfg.zero_tol, sum_tol=int_cfg.sum_tol,
                                  p_ba_yes=p_ba_cfg.yes,
                                  )
                if not weights_only:
                    ret = mcf_est.weight_var(
                        w_qiate_q[comp_idx, t_idx, :, out_idx],
                        y_dat[:, out_idx], cl_dat, p_cfg,
                        residual_dat=None, bootstrap=p_cfg.se_boot_qiate,
                        keep_all=int_cfg.keep_w0, se_yes=p_cfg.qiate_se,
                        normalize=not iv,
                        zero_tol=int_cfg.zero_tol, sum_tol = int_cfg.sum_tol,
                        seed=123345, min_obs=5,
                        )
                    y_pot_q[comp_idx, t_idx, out_idx] = ret[0]
                    if p_cfg.qiate_se:
                        y_pot_var_q[comp_idx, t_idx, out_idx] = ret[1]

                    if qiate_m_mqiate:
                        ret2 = mcf_est.weight_var(w_diff_med, y_dat[:, out_idx], cl_dat, p_cfg,
                                                  residual_dat=None, normalize=False,
                                                  bootstrap=p_cfg.se_boot_qiate,
                                                  keep_all=int_cfg.keep_w0,
                                                  se_yes=p_cfg.qiate_se,
                                                  zero_tol=int_cfg.zero_tol,
                                                  sum_tol=int_cfg.sum_tol, seed=123345, min_obs=5,
                                                  )
                        y_pot_mmed_q[comp_idx, t_idx, out_idx] = ret2[0]
                        if p_cfg.qiate_se:
                            y_pot_mmed_var_q[comp_idx, t_idx, out_idx] = ret2[1]

                    if qiate_m_opp:
                        ret2 = mcf_est.weight_var(w_diff_opp, y_dat[:, out_idx], cl_dat, p_cfg,
                                                  residual_dat=None, normalize=False,
                                                  bootstrap=p_cfg.se_boot_qiate,
                                                  keep_all=int_cfg.keep_w0, se_yes=p_cfg.qiate_se,
                                                  zero_tol=int_cfg.zero_tol,
                                                  sum_tol=int_cfg.sum_tol, seed=123345, min_obs=5,
                                                  )
                        y_pot_mopp_q[comp_idx, t_idx, out_idx] = ret2[0]
                        if p_cfg.qiate_se:
                            y_pot_mopp_var_q[comp_idx, t_idx, out_idx] = ret2[1]

    if weights_only:
        return (None, None, None, None, None, None, w_qiate_q, w_qiate_unc_q, q_value_idx,
                w_censored_q
                )
    if y_pot_mmed_var_q is not None:
        y_pot_mmed_var_q[np.abs(y_pot_mmed_q) < int_cfg.zero_tol] = 0
    if y_pot_mopp_var_q is not None:
        y_pot_mopp_var_q[np.abs(y_pot_mopp_q) < int_cfg.zero_tol] = 0

    return (y_pot_q, y_pot_var_q, y_pot_mmed_q, y_pot_mmed_var_q, y_pot_mopp_q, y_pot_mopp_var_q,
            w_qiate_q, w_qiate_unc_q, q_value_idx, w_censored_q
            )


def assign_pot_q(y_pot: NDArray[any],
                 y_pot_var: NDArray[any] | None, *,
                 y_pot_mmed: NDArray[any],
                 y_pot_mmed_var: NDArray[any] | None,
                 y_pot_mopp: NDArray[any],
                 y_pot_mopp_var: NDArray[any] | None,
                 results_fut_q: Any,
                 q_idx: int,
                 qiate_m_mqiate: NDArray[any] | None,
                 qiate_m_opp: NDArray[any] | None,
                 ) -> tuple[NDArray[any], NDArray[any] | None,
                            NDArray[any], NDArray[any] | None,
                            NDArray[any], NDArray[any] | None,
                            ]:
    """Reduce repetetive code."""
    y_pot[q_idx] = results_fut_q[0]
    y_pot_var[q_idx] = results_fut_q[1]
    if qiate_m_mqiate:
        y_pot_mmed[q_idx] = results_fut_q[2]
        y_pot_mmed_var[q_idx] = results_fut_q[3]
    if qiate_m_opp:
        y_pot_mopp[q_idx] = results_fut_q[4]
        y_pot_mopp_var[q_idx] = results_fut_q[5]

    return y_pot, y_pot_var, y_pot_mmed, y_pot_mmed_var, y_pot_mopp, y_pot_mopp_var


def assign_w_q(w_qiate: NDArray[Any],
               w_qiate_unc: NDArray[Any],
               w_censored: NDArray[Any],
               results_fut_q: Any,
               q_idx: int,
               ) -> tuple[NDArray[Any], NDArray[Any], NDArray[Any]]:
    """Reduce repetetive code."""
    w_qiate[q_idx] = results_fut_q[6]
    w_qiate_unc[q_idx] = results_fut_q[7]
    w_censored[q_idx] = results_fut_q[9]

    return w_qiate, w_qiate_unc, w_censored


def w_qiate_func(sum_w_qiate: NDArray[Any],
                 w_qiate_q: NDArray[Any],
                 w_censored_q: NDArray[Any], *,
                 w_mmed: NDArray[Any],
                 w_mopp: NDArray[Any],
                 compute_w_diff_med: bool,
                 compute_w_diff_opp: bool,
                 max_weight_share: float | np.floating,
                 iv: bool = False,
                 zero_tol: float = 1e-10,
                 sum_tol: float = 1e-8,
                 p_ba_yes: bool = False,
                 ) -> tuple[NDArray[Any], NDArray[Any], NDArray[Any], NDArray[Any], NDArray[Any]]:
    """Compute weights for discrete case."""
    if (not 1-sum_tol < sum_w_qiate < 1+sum_tol) and (sum_w_qiate > sum_tol):
        w_qiate_q = w_qiate_q / sum_w_qiate
    w_qiate_unc_q = w_qiate_q

    if max_weight_share < 1:
        if iv:
            w_qiate_q, _, w_censored_q = bound_norm_weights_not_one(w_qiate_q, max_weight_share,
                                                                    zero_tol=zero_tol,
                                                                    sum_tol=sum_tol,
                                                                    )
        else:
            w_qiate_q, _, w_censored_q = bound_norm_weights(w_qiate_q,
                                                            max_weight_share=max_weight_share,
                                                            zero_tol=zero_tol, sum_tol=sum_tol,
                                                            negative_weights_possible=p_ba_yes,
                                                            )
    w_diff_med = w_qiate_unc_q - w_mmed if compute_w_diff_med else None
    w_diff_opp = w_qiate_unc_q - w_mopp if compute_w_diff_opp else None

    return w_qiate_q, w_diff_med, w_diff_opp, w_censored_q, w_qiate_unc_q


def get_w_rel_q(iate_q_np: NDArray[Any],
                iate_q_key_dic: dict,
                q_val: float | np.floating,
                weights_all_ref: Any, *,
                no_of_outcomes: int = 1,
                bandwidth: float | np.floating | None = 1,
                kernel_str: str = 'epanechikov',
                w_is_csr: bool = False,
                zero_tol: float = 1e-10,
                ) -> tuple[list[list[Any]],
                           list[list[NDArray[np.bool_]]],
                           list[list[NDArray[Any]]]
                           ]:
    """Get relevant observations and their weights."""
    # Get neighbouring observation (comparison specific)
    no_of_comparisons = len(iate_q_key_dic)
    weights = [[None for _ in range(no_of_outcomes)] for _ in range(no_of_comparisons)]
    w_q = [[None for _ in range(no_of_outcomes)] for _ in range(no_of_comparisons)]
    relevant_data = [[None for _ in range(no_of_outcomes)] for _ in range(no_of_comparisons)]

    if ray is not None and isinstance(weights_all_ref, ray.ObjectRef):
        weights_all = ray.get(weights_all_ref)
    else:
        weights_all = weights_all_ref

    kernel = 1 if kernel_str == 'epanechikov' else 2

    for value in iate_q_key_dic.values():   # Treatment comparisons
        for out_idx in range(no_of_outcomes):
            order_dat = iate_q_np[:, value[0], out_idx]
            quantil = np.quantile(order_dat, q_val)

            arg = order_dat - quantil
            if bandwidth is None:
                # If no smoothing use observations closest to quantil
                w_q_val = np.zeros_like(arg)
                no_closest = 1
                for _ in range(no_closest):
                    idx = np.argmin(abs(arg))
                    w_q_val[idx] = 1
                    arg[idx] += 1e100
            else:
                w_q_val = kernel_proc(arg / bandwidth, kernel)

            relevant_data_points = w_q_val > zero_tol

            if not np.any(relevant_data_points):
                closest_idx = int(np.argmin(np.abs(arg)))
                w_q_val = np.zeros_like(arg)
                w_q_val[closest_idx] = 1.0
                relevant_data_points = w_q_val > zero_tol

            w_q_val = w_q_val[relevant_data_points]
            w_q_val = w_q_val / np.sum(w_q_val) * len(w_q_val)

            if w_is_csr:
                weights[value[0]][out_idx] = [weights_all[t_idx][relevant_data_points, :]
                                              for t_idx in value[1:]
                                              ]
            else:
                # Remove n_p data that are not needed
                reduce_n = list(
                    compress(weights_all, relevant_data_points))
                # Remove all treatments not relevant for comparison
                n_x = len(reduce_n)
                weights[value[0]][out_idx] = [[reduce_n[n_idx][t_idx]
                                               for t_idx in value[1:]]
                                              for n_idx in range(n_x)
                                              ]
            w_q[value[0]][out_idx] = w_q_val.copy()
            relevant_data[value[0]][out_idx] = relevant_data_points.copy()

    return weights, relevant_data, w_q


def initialise_weights_qiate(no_of_qval: int,
                             no_of_comparisons: int,
                             n_y: int,
                             no_of_out: int,
                             ) -> tuple[NDArray[Any], NDArray[Any], NDArray[Any], NDArray[Any]]:
    """Initialize weights."""
    w_qiate = np.zeros((no_of_qval, no_of_comparisons, 2, n_y, no_of_out))
    w_qiate_unc = np.zeros_like(w_qiate)
    w_censored = np.zeros((no_of_qval, no_of_comparisons, 2, no_of_out))
    w_median = np.zeros((no_of_comparisons, 2, n_y, no_of_out))

    return w_qiate, w_qiate_unc, w_censored, w_median


def initialise_pot_qiate(no_of_qval: int,
                         no_of_comparisons: int,
                         no_of_out: int
                         ) -> tuple[NDArray[Any], NDArray[Any], NDArray[Any], NDArray[Any],
                                    NDArray[Any], NDArray[Any],
                                    ]:
    """Initialise variables that store the potential outcomes."""
    y_pot = np.empty((no_of_qval, no_of_comparisons, 2, no_of_out))
    y_pot_var = np.zeros_like(y_pot)
    y_pot_mmed = np.empty_like(y_pot)
    y_pot_mmed_var = np.zeros_like(y_pot)
    y_pot_mopp = np.empty_like(y_pot)
    y_pot_mopp_var = np.zeros_like(y_pot)

    return y_pot, y_pot_var, y_pot_mmed, y_pot_mmed_var, y_pot_mopp, y_pot_mopp_var


def get_nadarya_watson_parameters(x_dat: NDArray[Any],
                                  qiate_smooth_bandwidth: float,
                                  zero_tol: float = 1e-10,
                                  ) -> tuple[np.floating | float, str]:
    """Smoothing parameters in Nadaraya-Watson estimation."""
    kernel = 'epanechikov'
    bandwidth = bandwidth_nw_rule_of_thumb(x_dat, kernel=1, zero_tol=zero_tol)
    bandwidth *= qiate_smooth_bandwidth

    return bandwidth, kernel


def optimize_initialize_mp_qiate(weights_all: Any,
                                 gen_cfg: 'GenCfg',
                                 int_cfg: 'IntCfg',
                                 with_output: bool,
                                 ) -> tuple[set, None, Any, int, str]:
    """Define multiprocession and initialize ray (if used)."""
    files_to_delete, save_w_file = set(), None
    txt = ''
    weights_all2 = weights_all

    if gen_cfg.mp_parallel < 1.5:
        maxworkers = 1
    else:
        if gen_cfg.mp_automatic:
            maxworkers = mcf_sys.find_no_of_workers(gen_cfg.mp_parallel, gen_cfg.sys_share / 2,
                                                    zero_tol=int_cfg.zero_tol,
                                                    )
        else:
            maxworkers = gen_cfg.mp_parallel
        if weights_all2 is None:
            maxworkers = round(maxworkers / 2)
        if not maxworkers > 0:
            maxworkers = 1

    if gen_cfg.with_output and gen_cfg.verbose and with_output:
        print('Number of parallel processes (QIATE): ', maxworkers, flush=True)

    if maxworkers > 1 and int_cfg.mp_use_old_ray:
        if ray is None or ray_qiate_mp is None:
            raise ImportError('int_cfg.mp_use_old_ray=True, but ray is not installed. '
                              'Install ray or use the new backend with mp_use_old_ray=False.'
                              )

        if not ray.is_initialized():
            ray_is_running, maxworkers = mcf_ray.init_ray_with_fallback(
                maxworkers, gen_cfg,
                mem_object_store=int_cfg.mem_object_store_3,
                mem_object_store_2=int_cfg.mem_object_store_2,
                ray_err_txt='Ray does not start up in QIATE estimation.',
                )
        else:
            ray_is_running = True

        if ray_is_running:
            mcf_ray.print_object_store(gen_cfg, int_cfg.mem_object_store_3)
            weights_all_ref = mcf_ray.ray_put_all(weights_all)
        else:
            maxworkers = 1
            weights_all_ref = weights_all
    else:
        weights_all_ref = weights_all

    return files_to_delete, save_w_file, weights_all_ref, maxworkers, txt


def assign_data(weights_dic: dict,
                gen_cfg: 'GenCfg',
                p_cfg: dict,
                ) -> tuple[NDArray[Any], Any, NDArray[Any] | None, NDArray[Any] | None]:
    """Assign variables from weights_dic dictionary."""
    y_dat = weights_dic['y_dat_np']
    weights_all = weights_dic['weights']
    w_dat = weights_dic['w_dat_np'] if gen_cfg.weighted else None
    cl_dat = weights_dic['cl_dat_np'] if p_cfg.cluster_std else None

    return y_dat, weights_all, w_dat, cl_dat


def get_comparison_labels(no_of_treat: int,
                          d_values: (list[np.floating | np.integer | int | float]
                                     | NDArray[np.floating | np.integer]),
                          ) -> list[str]:
    """Compute labels for treatment comparisons."""
    jdx = 0
    treat_comp_label = [None for _ in range(round(no_of_treat * (no_of_treat - 1) / 2))]
    for t1_idx, t1_lab in enumerate(d_values):
        for t2_idx in range(t1_idx+1, no_of_treat):
            treat_comp_label[jdx] = str(d_values[t2_idx]) + 'vs' + str(t1_lab)
            jdx += 1

    return treat_comp_label


def get_iate_order(y_pot: NDArray[Any],
                   y_pot_var: NDArray[Any] | None,
                   no_of_treat: int,
                   no_of_out: int,
                   p_cfg: 'PCfg',
                   ) -> tuple[NDArray[Any], dict]:
    """Compute the position for IATE and also a key to find it later."""
    obs = len(y_pot)
    quantile_key_dic = {}
    quantile_np = np.empty((obs, round(no_of_treat * (no_of_treat - 1) / 2), no_of_out))

    running_idx = 0
    for t1_idx in range(no_of_treat - 1):
        str1 = str(t1_idx) + '_'
        for t2_idx in range(t1_idx + 1, no_of_treat):
            key_str = str1 + str(t2_idx)
            for o_idx in range(no_of_out):
                iate = y_pot[:, t2_idx, o_idx] - y_pot[:, t1_idx, o_idx]
                quantile_np[:, running_idx, o_idx] = (np.argsort(np.argsort(iate)) + 0.5) / obs

                if p_cfg.qiate_bias_adjust:
                    iate_se = np.sqrt(y_pot_var[:, t2_idx, o_idx] + y_pot_var[:, t1_idx, o_idx])
                    quantile_np[:, running_idx, o_idx] = bias_adjust_qiate(
                        quantile_np[:, running_idx, o_idx], iate, iate_se,
                        draws=p_cfg.qiate_bias_adjust_draws,
                        simex=False
                        )
                quantile_key_dic[key_str] = (running_idx, t1_idx, t2_idx, )
            running_idx += 1

    return quantile_np, quantile_key_dic


def bias_adjust_qiate(iate_quantile_np: NDArray[Any],
                      iate_np: NDArray[Any],
                      iate_se_np: NDArray[Any],
                      draws: int = 100,
                      simex: bool = False,
                      ) -> NDArray[Any]:
    """Compute bias adjustment."""
    OLD_SIMULATION = False                          # pylint: disable=C0103

    obs = iate_quantile_np.shape[0]
    rng_qiate = np.random.default_rng(seed=125435)

    if simex:
        est_error_simul_np = rng_qiate.normal(loc=0, scale=1, size=(obs, draws))
        grid = (0.05, 0.1, 0.25, 0.5, 0.75, 1, 1.25, 1.5,)
        len_grid = len(grid)
        iate_simul_rank = np.empty((len(iate_np), len_grid, draws))

        for g_idx, noise_level in enumerate(grid):
            iate_est_simul = iate_np.reshape(-1, 1) + est_error_simul_np * np.sqrt(noise_level)
            for h in range(draws):
                iate_simul_rank[:, g_idx, h] = iate_est_simul[:, h].argsort(
                    axis=0).argsort(axis=0) + 0.5  # .reshape(-1)

        iate_simul_rank_mean = np.mean(iate_simul_rank, axis=-1)
        iate_rank_np = iate_quantile_np * obs

        rank_iate_adj_np = simex_diff_rank_adjustment(iate_rank_np, iate_se_np,
                                                      iate_simul_rank_mean, grid
                                                      )
        iate_quantile_adj_np = np.clip(rank_iate_adj_np / obs, 0, 1)

    elif OLD_SIMULATION:
        est_error_simul_np = rng_qiate.normal(loc=0, scale=1, size=(obs, draws))
        iate_simul_rank = np.empty_like(est_error_simul_np)   # OBS x DRAWS
        iate_est_simul = iate_np.reshape(-1, 1) + est_error_simul_np
        for h in range(est_error_simul_np.shape[1]):
            iate_simul_rank[:, h] = iate_est_simul[:, h].argsort(
                axis=0).argsort(axis=0).reshape(-1) + 0.5

        iate_simul_rank_mean = np.mean(iate_simul_rank, axis=1).reshape(-1, 1)

        for h in range(est_error_simul_np.shape[1]):
            iate_simul_rank[:, h] = iate_est_simul[:, h].argsort(
                axis=0).argsort(axis=0).reshape(-1) + 0.5
        iate_simul_rank_mean = np.mean(iate_simul_rank, axis=1).reshape(-1, 1)
        iate_quantile_adj_np = np.clip(
            delta_quantile_adjustment(iate_quantile_np, iate_simul_rank_mean / obs),
            0, 1
            )
    else:
        iate_bias_adjust_np = bias_adjust_value(iate_np, iate_quantile_np, iate_se_np,)
        iate_quantile_adj_np = switch_ranks(iate_bias_adjust_np, iate_np)

    return iate_quantile_adj_np


def bias_adjust_value(iate_np: NDArray[Any],
                      iate_quantile_np: NDArray[Any],
                      iate_se_np: NDArray[Any],
                      tolerance_0_1: float | np.floating = 1e-10,
                      ) -> NDArray[Any]:
    """Bias adjustment of IATE keeping quantile position."""
    obs = len(iate_np)
    bias = norm.ppf(iate_quantile_np.clip(min=tolerance_0_1, max=1 - tolerance_0_1),
                    loc=np.zeros(obs),
                    scale=iate_se_np,
                    )
    iate_bias_adjust_np = iate_np - bias

    return iate_bias_adjust_np


def switch_ranks(iate_bias_adjust_np: NDArray[Any],
                 iate_np: NDArray[Any],
                 ) -> NDArray[Any]:
    """Find quantiles of bias adjusted IATEs in old distribution of IATEs."""
    iate_bias_adjust_np_sorted = np.sort(iate_bias_adjust_np)
    indices = np.searchsorted(iate_bias_adjust_np_sorted, iate_np, side='right')
    quantile_iate_adj_np = (indices + 0.5) / len(iate_np)

    return quantile_iate_adj_np


def simex_diff_rank_adjustment(iate_est_rank: NDArray[Any],
                               iate_est_se: NDArray[Any] | None,
                               iate_simul_rank: NDArray[Any],
                               grid: list[float | np.floating],
                               ) -> NDArray[Any]:
    """Adjust ranks by regression."""
    x_dim = 6

    x_var = np.empty((len(iate_est_rank), x_dim, len(grid)))
    y_var = np.empty((len(iate_est_rank), len(grid),))
    ones = np.ones(len(iate_est_rank))

    for gidx, noise_level in enumerate(grid):
        y_var[:, gidx] = iate_est_rank - iate_simul_rank[:, gidx]
        x_var[:, :, gidx] = make_x_simex_diff(x_dim, ones, iate_est_se, noise_level)

    x_var_pred = make_x_simex_diff(x_dim, ones, iate_est_se, -1)

    x_list = [x_var[:, :, gidx] for gidx, _ in enumerate(grid)]
    x_varf = np.concatenate(x_list, axis=0)

    y_list = [y_var[:, gidx] for gidx, _ in enumerate(grid)]
    y_varf = np.concatenate(y_list, axis=0)
    # Does OLS make sense for a difference in rank regression?
    beta = np.linalg.solve(x_varf.T @ x_varf, x_varf.T @ y_varf)

    delta = x_var_pred @ beta

    rank_adjusted = iate_est_rank - delta

    return rank_adjusted


def make_x_simex_diff(x_dim: int,
                      ones: NDArray[Any],
                      iate_est_se: NDArray[Any],
                      noise_level: float | np.floating,
                      ) -> NDArray[Any]:
    """Make matrices with independent variables."""
    x_var = np.zeros((len(iate_est_se), x_dim))
    x_var[:, 0] = ones
    x_var[:, 1] = noise_level
    if x_dim > 2:
        x_var[:, 2] = noise_level ** 2
    if x_dim > 3:
        x_var[:, 3] = iate_est_se * noise_level
    if x_dim > 4:
        x_var[:, 4] = iate_est_se * (noise_level ** 2)
    if x_dim > 5:
        x_var[:, 5] = (iate_est_se * noise_level) ** 2

    return x_var


def delta_quantile_adjustment(est_q: NDArray[Any],
                              simul_q: NDArray[Any]
                              ) -> NDArray[Any]:
    """Compute adjusted quantile positions of estimated IATEs."""
    delta = simul_q - est_q.reshape(-1, 1)
    new_quantil = est_q.reshape(-1, 1) - delta

    return new_quantil.reshape(-1)


def qiate_effects_print(mcf_: 'ModifiedCausalForest',
                        effect_dic: dict,
                        effect_m_med_dic: dict | None,
                        effect_m_opp_dic: dict | None,
                        qiate_est_dic: dict, *,
                        special_txt: str | None = None
                        ) -> tuple[NDArray[Any], NDArray[Any] | None,
                                   NDArray[Any] | None, NDArray[Any] | None,
                                   NDArray[Any] | None, NDArray[Any] | None,
                                   list[Path]]:
    """Compute QIATE results, print statistics, and generate figures."""
    continuous = False
    p_cfg, int_cfg, gen_cfg = mcf_.p_cfg, mcf_.int_cfg, mcf_.gen_cfg
    q_values = p_cfg.qiate_quantiles
    no_of_qval = len(q_values)
    mid_value = int(np.argmin(np.abs(q_values - 0.5)))
    y_pot, y_pot_var = effect_dic['y_pot'], effect_dic['y_pot_var']

    m_med_yes = effect_m_med_dic is not None
    m_opp_yes = effect_m_opp_dic is not None
    figure_list: list[Path] = []

    if m_med_yes:
        y_pot_m_med = effect_m_med_dic['y_pot']
        y_pot_m_med_var = effect_m_med_dic['y_pot_var']
    else:
        y_pot_m_med = y_pot_m_med_var = None

    if m_opp_yes:
        y_pot_m_opp = effect_m_opp_dic['y_pot']
        y_pot_m_opp_var = effect_m_opp_dic['y_pot_var']
    else:
        y_pot_m_opp = y_pot_m_opp_var = None

    if special_txt is not None:
        mcf_ps.print_mcf(gen_cfg, '\n' + '=' * 100 + special_txt, summary=True, non_summary=False)

    treat_comp_labels = qiate_est_dic['treat_comp_label']
    seq_dic = qiate_est_dic['iate_q_key_dic']
    no_of_out, var_cfg = qiate_est_dic['no_of_out'], qiate_est_dic['var_cfg']
    p_cfg = qiate_est_dic['p_cfg']
    effect_type_label = 'QIATE', 'QIATE(q) - QIATE(0.5)', 'QIATE(q) - QIATE(1-q)', 'Distribution'

    qiate = np.empty((no_of_qval, no_of_out, len(treat_comp_labels)))
    qiate_se = np.empty_like(qiate) if p_cfg.qiate_se else None
    qiate_mmed = np.empty_like(qiate) if m_med_yes else None
    qiate_mmed_se = np.empty_like(qiate) if m_med_yes and p_cfg.qiate_se else None
    qiate_mopp = np.empty_like(qiate) if m_opp_yes else None
    qiate_mopp_se = np.empty_like(qiate) if m_opp_yes and p_cfg.qiate_se else None

    txt = ''
    if gen_cfg.with_output and gen_cfg.qiate_eff and p_cfg.qiate_se:
        txt += mcf_ps.print_efficiency_se_info()

    old_filters = warnings.filters.copy()
    warnings.filterwarnings('error', category=RuntimeWarning)
    try:
        for o_idx in range(no_of_out):
            if gen_cfg.with_output:
                txt += '\n' + '-' * 100 + f'\nOutcome variable: {var_cfg.y_name[o_idx]}      '
                txt += 'Reference population: All'
                txt += '\n' + '- ' * 50

            ret_qiate = [None for _ in range(no_of_qval)]
            ret_qiate_mmed = [None for _ in range(no_of_qval)] if m_med_yes else None
            ret_qiate_mopp = [None for _ in range(no_of_qval)] if m_opp_yes else None

            for q_idx, _ in enumerate(q_values):
                ret = mcf_est.effect_from_potential(y_pot[q_idx][:, :, o_idx],
                                                    y_pot_var[q_idx][:, :, o_idx],
                                                    gen_cfg.d_values, continuous=continuous,
                                                    sequential=True, sequential_dic=seq_dic,
                                                    se_yes=p_cfg.qiate_se
                                                    )
                ret_qiate[q_idx] = ret
                qiate[q_idx, o_idx, :] = ret[0]
                if p_cfg.qiate_se:
                    qiate_se[q_idx, o_idx, :] = ret[1]

                if m_med_yes:
                    ret = mcf_est.effect_from_potential(y_pot_m_med[q_idx][:, :, o_idx],
                                                        y_pot_m_med_var[q_idx][:, :, o_idx],
                                                        gen_cfg.d_values, continuous=continuous,
                                                        sequential=True, sequential_dic=seq_dic,
                                                        se_yes=p_cfg.qiate_se,
                                                        )
                    ret_qiate_mmed[q_idx] = ret
                    qiate_mmed[q_idx, o_idx, :] = ret[0]
                    if p_cfg.qiate_se:
                        qiate_mmed_se[q_idx, o_idx, :] = ret[1]

                if m_opp_yes:
                    ret = mcf_est.effect_from_potential(y_pot_m_opp[q_idx][:, :, o_idx],
                                                        y_pot_m_opp_var[q_idx][:, :, o_idx],
                                                        gen_cfg.d_values, continuous=continuous,
                                                        sequential=True, sequential_dic=seq_dic,
                                                        se_yes=p_cfg.qiate_se,
                                                        )
                    ret_qiate_mopp[q_idx] = ret
                    qiate_mopp[q_idx, o_idx, :] = ret[0]
                    if p_cfg.qiate_se:
                        qiate_mopp_se[q_idx, o_idx, :] = ret[1]

            if gen_cfg.with_output:
                txt += '\nQuantile Individualized Average Treatment Effects\n' + '- ' * 50
                txt += f'\nOutcome: {var_cfg.y_name[o_idx]} Ref. pop.: All\n'
                txt += mcf_ps.print_effect_z(ret_qiate, ret_qiate_mmed, q_values, 'QIATE', 'ATE',
                                             gates_minus_previous=False, qiate=True,
                                             gmopp_r=ret_qiate_mopp, z_values_org=None,
                                             gen_tv_cfg_yes=mcf_.gen_tv_cfg.yes,
                                             )
                if p_cfg.qiate_se:
                    txt += '\n' + mcf_ps.print_se_info(p_cfg.cluster_std, p_cfg.se_boot_qiate)
                txt += mcf_ps.print_minus_ate_info(gen_cfg.weighted)

        if gen_cfg.with_output:
            for o_idx, o_lab in enumerate(var_cfg.y_name):
                for t_idx, t_lab in enumerate(treat_comp_labels):
                    for e_idx, e_lab in enumerate(effect_type_label):
                        figure_disc = None
                        if e_idx == 0:
                            effects = qiate[:, o_idx, t_idx]
                            ste = qiate_se[:, o_idx, t_idx] if p_cfg.qiate_se else None
                            med_f = qiate[mid_value, o_idx, t_idx]
                            med_f_se = qiate_se[mid_value, o_idx, t_idx] if p_cfg.qiate_se else 0.0
                            cdf_pdf = False
                        elif e_idx == 1:
                            med_f, med_f_se = 0, None
                            if m_med_yes:
                                effects = qiate_mmed[:, o_idx, t_idx]
                                ste = qiate_mmed_se[:, o_idx, t_idx] if p_cfg.qiate_se else None
                            else:
                                effects = ste = None
                            cdf_pdf = False
                        elif e_idx == 2:
                            med_f, med_f_se = 0, None
                            if m_opp_yes:
                                effects = qiate_mopp[:, o_idx, t_idx]
                                ste = qiate_mopp_se[:, o_idx, t_idx] if p_cfg.qiate_se else None
                            else:
                                effects = ste = None
                            cdf_pdf = False
                        else:
                            effects = qiate[:, o_idx, t_idx]
                            ste = qiate_se[:, o_idx, t_idx] if p_cfg.qiate_se else None
                            med_f, med_f_se = 0, None
                            cdf_pdf = True

                        if not continuous and effects is not None:
                            left, right = t_lab.split('vs')
                            effect_label = 'QIATE(q)' if e_idx == 0 else e_lab
                            title_effect = ('Distribution from QIATEs' if cdf_pdf
                                            else effect_label)
                            title_parts = (f'{title_effect}: T{left} vs T{right}',
                                           f'Outcome: {o_lab}; reference population: All',
                                           )
                            display_title = '\n'.join(fill(part, width=70)
                                                     for part in title_parts)
                            file_title = e_lab + ' ' + ' ' + o_lab + ' ' + t_lab
                            figure_disc = make_qiate_figures_discr(file_title, q_values,
                                                                   effects, ste,
                                                                   gen_cfg=gen_cfg,
                                                                   int_cfg=int_cfg,
                                                                   p_cfg=p_cfg,
                                                                   effect_label=effect_label,
                                                                   med=med_f, med_se=med_f_se,
                                                                   cdf_pdf=cdf_pdf,
                                                                   display_title=display_title
                                                                   )
                        reference_label = str(gen_cfg.d_values[0])
                        vs0 = t_lab.endswith('vs' + reference_label)
                        if vs0 and e_idx != 2 and ( (m_med_yes and e_idx == 1)
                                                   or (not m_med_yes and e_idx == 0)
                                                   ):
                            if figure_disc is not None:
                                figure_list.append(figure_disc)

            txt += '-' * 100
            mcf_ps.print_mcf(gen_cfg, txt, summary=True, non_summary=True)
    finally:
        warnings.filters = old_filters

    return qiate, qiate_se, qiate_mmed, qiate_mmed_se, qiate_mopp, qiate_mopp_se, figure_list


def make_qiate_figures_discr(titel: str,
                             q_values: list[float] | NDArray[Any],
                             effects: NDArray[Any],
                             stderr: NDArray[Any] | None, *,
                             gen_cfg: 'GenCfg',
                             int_cfg: 'IntCfg',
                             p_cfg: 'PCfg',
                             effect_label: str,
                             med: int | float | None = 0,
                             med_se: int | float | None = None,
                             cdf_pdf: bool = False,
                             display_title: str | None = None
                             ) -> Path | None:
    """Plot QIATE results or their reconstructed distribution and export plot data."""
    titel_f = titel.replace(' ', '').replace('-', 'M').replace('.', '')
    titel_tmp = (titel.replace('vs', ' vs ') if display_title is None
                 else display_title)

    file_name_jpeg = p_cfg.paths['qiate_fig_pfad_jpeg'] / f'{titel_f}.jpeg'
    file_name_pdf = p_cfg.paths['qiate_fig_pfad_pdf'] / f'{titel_f}.pdf'
    file_name_csv = p_cfg.paths['qiate_fig_pfad_csv'] / f'{titel_f}plotdat.csv'
    file_name_f_jpeg = p_cfg.paths['qiate_fig_pfad_jpeg'] / f'{titel_f}fill.jpeg'
    file_name_f_pdf = p_cfg.paths['qiate_fig_pfad_pdf'] / f'{titel_f}fill.pdf'

    q_values_np = np.asarray(q_values).reshape(-1)
    effects = np.asarray(effects).reshape(-1)

    if cdf_pdf:
        try:
            pdf_smooth, cdf, values = make_cdf_pdf(effects, q_values_np)
        except ValueError as exc:
            for file_name in (file_name_jpeg, file_name_pdf, file_name_csv,
                              file_name_f_jpeg, file_name_f_pdf):
                mcf_sys.delete_file_if_exists(file_name)
            txt = f'\nDistribution plot omitted: {titel}\nReason: {exc}\n'
            mcf_ps.print_mcf(gen_cfg, txt, summary=True)
            return None

        figs, (axs_cdf, axs_pdf) = plt.subplots(2, 1, sharex=True, figsize=(7, 6),
                                               constrained_layout=True)
        axs_cdf.plot(values, cdf, color='b')
        axs_cdf.set_ylabel('CDF')
        axs_cdf.set_ylim(0, 1)
        axs_pdf.plot(values, pdf_smooth, color='r')
        axs_pdf.set_ylabel('Density')
        axs_pdf.set_ylim(0, 1.05 * float(np.max(pdf_smooth)))
        axs_pdf.set_xlabel('Treatment effect')
        figs.suptitle(titel_tmp, fontsize=int_cfg.fontsize)

        mcf_sys.delete_file_if_exists(file_name_f_jpeg)
        mcf_sys.delete_file_if_exists(file_name_f_pdf)
        figs.savefig(file_name_f_jpeg, dpi=int_cfg.dpi, bbox_inches='tight')
        figs.savefig(file_name_f_pdf, dpi=int_cfg.dpi, bbox_inches='tight')
        if int_cfg.show_plots:
            plt.show()
        plt.close(figs)

        datasave = pd.DataFrame({'values': np.asarray(values).reshape(-1),
                                'cdf': np.asarray(cdf).reshape(-1),
                                'pdf': np.asarray(pdf_smooth).reshape(-1)}
                                )
        mcf_sys.delete_file_if_exists(file_name_csv)
        datasave.to_csv(file_name_csv, index=False)
        return file_name_f_jpeg

    with_se = stderr is not None
    med_label = '_nolegend_' if med_se is None else 'QIATE(0.5)'
    med_curve = None if med is None else med * np.ones(len(q_values_np))
    ci_level = f'{p_cfg.ci_level:.0%}'
    label_ci_effect = f'{effect_label}: {ci_level} pointwise CI'
    label_ci_reference = f'{med_label}: {ci_level} CI'
    med_upper: NDArray[Any] | None = None
    med_lower: NDArray[Any] | None = None

    if with_se:
        stderr = np.asarray(stderr).reshape(-1)
        cint = norm.ppf(p_cfg.ci_level + 0.5 * (1 - p_cfg.ci_level))
        upper = effects + stderr * cint
        lower = effects - stderr * cint
        if med_curve is not None and med_se is not None:
            med_upper = med_curve + med_se * cint
            med_lower = med_curve - med_se * cint

    figs, axs = plt.subplots()
    axs.plot(q_values_np, effects, label=effect_label, color='b')
    if with_se:
        axs.fill_between(q_values_np, upper, lower, alpha=0.3, color='b',
                         label=label_ci_effect)
    if med_curve is not None:
        if with_se and med_se is not None:
            axs.fill_between(q_values_np, med_upper, med_lower, alpha=0.3, color='r',
                             label=label_ci_reference)
        axs.plot(q_values_np, med_curve, '-r', label=med_label)

    axs.set_ylabel(effect_label)
    axs.legend(loc=int_cfg.legend_loc, shadow=True, fontsize=int_cfg.fontsize)
    axs.set_title(titel_tmp, fontsize=int_cfg.fontsize)
    axs.set_xlabel('Quantiles')
    figs.tight_layout()
    mcf_sys.delete_file_if_exists(file_name_f_jpeg)
    mcf_sys.delete_file_if_exists(file_name_f_pdf)
    figs.savefig(file_name_f_jpeg, dpi=int_cfg.dpi, bbox_inches='tight')
    figs.savefig(file_name_f_pdf, dpi=int_cfg.dpi, bbox_inches='tight')
    if int_cfg.show_plots:
        plt.show()
    plt.close(figs)

    if with_se:
        fig, axe = plt.subplots()
        for idx, q_value in enumerate(q_values_np):
            axe.plot([q_value, q_value], [upper[idx], lower[idx]], 'b-', linewidth=0.7)

        axe.plot(q_values_np, effects, '_-b', label=effect_label)
        axe.plot(q_values_np, upper, 'v-b', label=label_ci_effect)
        axe.plot(q_values_np, lower, '^-b', label='_nolegend_')
        if med_curve is not None:
            axe.plot(q_values_np, med_curve, '-r', label=med_label)
            if med_se is not None:
                axe.plot(q_values_np, med_upper, '--r', label=label_ci_reference)
                axe.plot(q_values_np, med_lower, '--r', label='_nolegend_')

        axe.set_ylabel(effect_label)
        axe.legend(loc=int_cfg.legend_loc, shadow=True, fontsize=int_cfg.fontsize)
        axe.set_title(titel_tmp, fontsize=int_cfg.fontsize)
        axe.set_xlabel('Quantiles')
        fig.tight_layout()
        mcf_sys.delete_file_if_exists(file_name_jpeg)
        mcf_sys.delete_file_if_exists(file_name_pdf)
        fig.savefig(file_name_jpeg, dpi=int_cfg.dpi, bbox_inches='tight')
        fig.savefig(file_name_pdf, dpi=int_cfg.dpi, bbox_inches='tight')
        if int_cfg.show_plots:
            plt.show()
        plt.close(fig)

    plot_values = {}
    if with_se:
        plot_values['upper'] = upper
    plot_values[effect_label] = effects
    if with_se:
        plot_values['lower'] = lower
    if med_curve is not None:
        reference_name = 'zero_reference' if med_se is None else 'QIATE(0.5)'
        plot_values[reference_name] = med_curve
        if with_se and med_se is not None:
            plot_values['med_upper'] = med_upper
            plot_values['med_lower'] = med_lower
    plot_values['q_values'] = q_values_np

    datasave = pd.DataFrame({name: np.asarray(values).reshape(-1)
                            for name, values in plot_values.items()})
    mcf_sys.delete_file_if_exists(file_name_csv)
    datasave.to_csv(file_name_csv, index=False)

    return file_name_f_jpeg


def make_cdf_pdf(values: NDArray[Any],
                 q_values: NDArray[Any] | list[float]
                 ) -> tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]:
    """Reconstruct a CDF and continuous density over the supplied quantile range.

    The density integrates to q_values[-1] - q_values[0] on this range.
    Tails are not extrapolated, and quantile estimates are not rearranged.
    """
    values = np.asarray(values, dtype=np.float64)
    quantiles = np.asarray(q_values, dtype=np.float64)
    if values.ndim != 1 or quantiles.ndim != 1 or values.shape != quantiles.shape:
        raise ValueError('Effect values and quantile probabilities must be matching 1D arrays.')
    if values.size < 2:
        raise ValueError('At least two quantile estimates are required.')
    if not np.all(np.isfinite(values)) or not np.all(np.isfinite(quantiles)):
        raise ValueError('Effect values and quantile probabilities must be finite.')
    if np.any((quantiles < 0) | (quantiles > 1)) or np.any(np.diff(quantiles) <= 0):
        raise ValueError('Quantile probabilities must increase strictly within [0, 1].')
    if np.any(values[1:] < values[:-1]):
        raise ValueError('Crossing QIATE estimates do not define an increasing quantile curve.')
    if np.any(values[1:] == values[:-1]):
        raise ValueError('Tied QIATE estimates do not define a continuous density.')

    try:
        with np.errstate(over='raise', divide='raise', invalid='raise'):
            cdf_interp = PchipInterpolator(values, quantiles, extrapolate=False)
            # Include every original knot and resolve each interval separately.
            intervals = np.linspace(values[:-1], values[1:], 33, axis=1)
            grid = np.append(intervals[:, :-1].reshape(-1), values[-1])
            cdf = cdf_interp(grid)
            pdf = cdf_interp.derivative()(grid)
    except FloatingPointError as error:
        raise ValueError('Density reconstruction is numerically unstable.') from error
    if not np.all(np.isfinite(cdf)) or not np.all(np.isfinite(pdf)):
        raise ValueError('Density reconstruction produced non-finite values.')

    # A monotone interpolant has a nonnegative derivative; remove round-off negatives.
    pdf = np.maximum(pdf, 0.0)
    return pdf, cdf, grid
