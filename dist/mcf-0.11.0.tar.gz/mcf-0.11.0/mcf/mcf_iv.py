"""Created on Thu Oct 31 10:08:06 2024.

Contains IV specific functions.

@author: MLechner
# -*- coding: utf-8 -*-
"""
from copy import copy, deepcopy
from dataclasses import fields
from time import time
from typing import Any, TYPE_CHECKING

import pandas as pd
try:
    import ray
except (ImportError, OSError):
    ray = None

from mcf import mcf_ate
from mcf import mcf_common_support as mcf_cs
from mcf import mcf_data
from mcf import mcf_estimation as mcf_est
from mcf import mcf_feature_selection as mcf_fs
from mcf import mcf_forest as mcf_fo
from mcf import mcf_gateout
from mcf import mcf_iate
from mcf import mcf_init_update_helper as mcf_init_update
from mcf import mcf_local_centering as mcf_lc
from mcf import mcf_print_stats as mcf_ps
from mcf import mcf_iv_add
from mcf.mcfoptp_parallel_backend_ray_classical import check_ray_shutdown

if TYPE_CHECKING:
    from mcf.mcf_main import ModifiedCausalForest


def train_iv_main(mcf_: 'ModifiedCausalForest', data_df: pd.DataFrame) -> dict:
    """
    Train the modified causal forest IV on the training data.

    Parameters
    ----------
    data_df : DataFrame
        Data used to compute the causal forest. It must contain information
        about outcomes, treatment, and features.

    Returns
    -------
    results : Dictionary.
        Contains the results. This dictionary has the following structure:
        'tree_df' : DataFrame
            Dataset used to build the forest.
        'fill_y_df' : DataFrame
            Dataset used to populate the forest with outcomes.
        'common_support_probabilities_tree': pd.DataFrame containing
            treatment probabilities for all treatments, the identifier of
            the observation, and a dummy variable indicating
            whether the observation is inside or outside the common support.
            This is for the data used to build the trees.
            None if _int_with_output is False.
        'common_support_probabilities_fill_y': pd.DataFrame containing
            treatment probabilities for all treatments, the identifier of
            the observation, and a dummy variable indicating
            whether the observation is inside or outside the common support.
            This is for the data used to fill the trees with outcome values.
            None if _int_with_output is False.
        'outpath' : Pathlib object
            Location of directory in which output is saved.

    """
    time_start = time()
    # Check treatment data
    data_df, _ = mcf_data.data_frame_vars_lower(data_df)
    data_df = mcf_data.check_recode_treat_variable(mcf_, data_df, train=True)
    # Initialise again with data information. Order of the following
    # init functions important. Change only if you know what you do.

    mcf_.gen_cfg.iv = True
    if not mcf_.var_cfg.iv_name:
        raise ValueError('Instrument must be specified for IV estimation.')
    if not mcf_.int_cfg.weight_as_sparse:
        raise ValueError('Weights must be handled using the sparse format for IV estimation. '
                         'Change "_int_weight_as_sparse" to "True".'
                         )

    # These standard updates remain as some are important for the predict method
    mcf_init_update.var_update_train(mcf_, data_df)
    mcf_init_update.gen_update_train(mcf_, data_df)
    mcf_init_update.ct_update_train(mcf_, data_df)
    mcf_init_update.cs_update_train(mcf_)           # Used updated gen_cfg info
    mcf_init_update.cf_update_train(mcf_, data_df)
    mcf_init_update.int_update_train(mcf_)
    mcf_init_update.lc_update_train(mcf_, data_df)
    mcf_init_update.p_update_train(mcf_)
    if mcf_.p_ba_cfg.yes:
        mcf_init_update.p_ba_update_train(mcf_, data_df)
    if mcf_.gen_cfg.with_output:
        mcf_ps.print_dic_values_all(mcf_, summary_top=True, summary_dic=False, title='(IV training)'
                                    )
    # Prepare data: Add and recode variables for GATES (Z)
    #             Recode categorical variables to prime numbers, cont. vars
    data_df = mcf_data.create_xz_variables(mcf_, data_df, train=True)
    if mcf_.gen_cfg.with_output and mcf_.gen_cfg.verbose:
        mcf_data.print_prime_value_corr(mcf_.data_train_dict, mcf_.gen_cfg, summary=False)

    # Clean data and remove missings and unncessary variables
    if mcf_.dc_cfg.clean_data:
        data_df, report = mcf_data.clean_data(mcf_, data_df, train=True)
        if mcf_.gen_cfg.with_output:
            mcf_.report['training_obs'] = report
    if mcf_.dc_cfg.screen_covariates:   # Only training
        (mcf_.gen_cfg, mcf_.var_cfg, mcf_.var_x_type, mcf_.var_x_values, report
         ) = mcf_data.screen_adjust_variables(mcf_, data_df)
        if mcf_.gen_cfg.with_output:
            mcf_.report['removed_vars'] = report

    # Ensure that treatment and instrument are binary (and coded as integer)
    data_df = ensure_binary_binary(mcf_, data_df)

    # Descriptives by treatment
    if mcf_.int_cfg.descriptive_stats and mcf_.gen_cfg.with_output:
        mcf_ps.desc_by_treatment(mcf_, data_df, summary=False, stage=1)
    time_1 = time()

    # Feature selection on the first stage only
    if mcf_.fs_cfg.yes:
        mcf_inst_fs = deepcopy(mcf_)
        mcf_inst_fs.var_cfg.d_name = mcf_.var_cfg.iv_name
        mcf_inst_fs.var_cfg.y_name = mcf_.var_cfg.d_name
        mcf_inst_fs.var_cfg.y_tree_name = mcf_.var_cfg.d_name
        (data_df, report, mcf_inst_fs.var_cfg, mcf_inst_fs.var_x_type, mcf_inst_fs.var_x_values
         ) = mcf_fs.feature_selection(data_df,
                                      gen_cfg=mcf_inst_fs.gen_cfg,
                                      fs_cfg=mcf_inst_fs.fs_cfg,
                                      var_cfg=mcf_inst_fs.var_cfg,
                                      var_x_type=copy(mcf_inst_fs.var_x_type),
                                      var_x_values=copy(mcf_inst_fs.var_x_values),
                                      boot=mcf_inst_fs.cf_cfg.boot,
                                      versions=mcf_inst_fs.gen_tv_cfg.yes,
                                      replication=mcf_inst_fs.int_cfg.replication,
                                      obs_bigdata=mcf_inst_fs.int_cfg.obs_bigdata,
                                      mcf_estimation=True,
                                      )
        mcf_.var_cfg.x_name = mcf_inst_fs.var_cfg.x_name.copy()
        mcf_.var_x_type = mcf_inst_fs.var_x_type.copy()
        mcf_.var_x_values = mcf_inst_fs.var_x_values.copy()
        if mcf_.gen_cfg.with_output:
            mcf_.report['fs_vars_deleted'] = report
        del mcf_inst_fs

    # Split sample for tree building and tree-filling-with-y
    tree_df, fill_y_df = mcf_data.split_sample_for_mcf(mcf_, data_df)

    del data_df
    time_2 = time()

    # Compute Common support on full sample
    if mcf_.cs_cfg.type_:
        mcf_inst_cs = deepcopy(mcf_)
        mcf_inst_cs.var_cfg.d_name = mcf_.var_cfg.iv_name
        (tree_df, fill_y_df, rep_sh_del, obs_remain, rep_fig, cs_tree_prob, cs_fill_y_prob, _
         ) = mcf_cs.common_support_p_score(mcf_inst_cs, tree_df, fill_y_df,
                                           train=True, p_score_only=False
                                           )
        if mcf_.gen_cfg.with_output:
            mcf_.report['cs_t_share_deleted'] = rep_sh_del
            mcf_.report['cs_t_obs_remain'] = obs_remain
            mcf_.report['cs_t_figs'] = rep_fig
        mcf_.cs_cfg = deepcopy(mcf_inst_cs.cs_cfg)
        del mcf_inst_cs
    else:
        cs_tree_prob = cs_fill_y_prob = None

    # Descriptives by treatment on common support
    if mcf_.int_cfg.descriptive_stats and mcf_.gen_cfg.with_output:
        mcf_ps.desc_by_treatment(mcf_,
                                 pd.concat([tree_df, fill_y_df], axis=0),
                                 summary=True,
                                 stage=1
                                 )
    time_3 = time()

    # Create new instances for 1st stage and reduced form
    mcf_1st, mcf_redf = new_instances_iv_train(mcf_)

    # Local centering
    if mcf_.lc_cfg.yes:
        tree_df, _, _, report_1st = mcf_lc.local_centering(mcf_1st, tree_df, fill_y_df=None,
                                                           title='(1st stage)'
                                                           )
        tree_df, fill_y_df, _, report_redf = mcf_lc.local_centering(mcf_redf, tree_df,
                                                                    fill_y_df=fill_y_df,
                                                                    title='(reduced form)'
                                                                    )
        if mcf_.gen_cfg.with_output:
            mcf_.report["lc_r2_1st"] = report_1st
            mcf_.report["lc_r2_redform"] = report_redf
    time_4 = time()

    # Train forests
    # 1st stage: Train forest on tree data only (not honest)
    if mcf_.gen_cfg.with_output:
        mcf_ps.variable_features(mcf_, summary=False)
        txt = '\n' * 2 + '-' * 100 + '\n' + '1st stage forest' + '\n' + '-' * 100
        mcf_ps.print_mcf(mcf_.gen_cfg, txt, summary=True)
    (mcf_1st.cf_cfg, mcf_1st.p_ba_cfg, mcf_1st.forest, time_vi_1st, report_1st
     ) = mcf_fo.train_forest(mcf_1st, tree_df, tree_df, ' (1st stage)')
    time_5 = time()

    # if mcf_.int_cfg.mp_ray_shutdown and mcf_.gen_cfg.mp_parallel > 1 and is_initialized():
    #     shutdown()
    if (mcf_.int_cfg.mp_use_old_ray
        and mcf_.int_cfg.mp_ray_shutdown
        and mcf_.gen_cfg.mp_parallel > 1
        and ray is not None
            and ray.is_initialized()
            ):
        ray.shutdown()

    # Reduced form (honest)
    if mcf_.gen_cfg.with_output:
        txt = '\n' * 2 + '-' * 100 + '\n' + 'Reduced form forest' + '\n' + '-' * 100
        mcf_ps.print_mcf(mcf_.gen_cfg, txt, summary=True)

    (mcf_redf.cf_cfg, mcf_redf.p_ba_cfg, mcf_redf.forest, time_vi_redf, report_redf
     ) = mcf_fo.train_forest(mcf_redf, tree_df, fill_y_df, ' (reduced form)')

    if mcf_.gen_cfg.with_output:
        mcf_.report['cf_1st'] = report_1st
        mcf_.report['cf_redf'] = report_redf

    mcf_.iv_mcf['firststage'] = mcf_1st
    mcf_.iv_mcf['reducedform'] = mcf_redf

    time_end = time()
    time_string = ['Data preparation and stats I:                   ',
                   'Feature preselection:                           ',
                   'Common support:                                 ',
                   'Local centering (recoding of Y & D):            ',
                   'Training the causal forest (1st stage):         ',
                   '  ... of which is time for variable importance: ',
                   'Training the causal forest (reduced form):      ',
                   '  ... of which is time for variable importance: ',
                   '\nTotal time training:                            '
                   ]
    time_difference = [time_1 - time_start, time_2 - time_1, time_3 - time_2, time_4 - time_3,
                       time_5 - time_4, time_vi_1st, time_end - time_5, time_vi_redf,
                       time_end - time_start
                       ]
    if mcf_.gen_cfg.with_output:
        time_train = mcf_ps.print_timing(mcf_.gen_cfg, 'Training', time_string, time_difference,
                                         summary=True
                                         )
        mcf_.time_strings['time_train'] = time_train

    results = {'tree_df': tree_df,
               'fill_y_df': fill_y_df,
               'common_support_probabilities_tree': cs_tree_prob,
               'common_support_probabilities_fill_y': cs_fill_y_prob,
               'path_output': mcf_.gen_cfg.outpath
               }
    return results


def predict_iv_main(mcf_: 'ModifiedCausalForest', data_df: pd.DataFrame
                    ) -> tuple[dict[str, Any], dict[str, Any]]:
    """
    Compute all effects based on causal forests estimated by the train_iv.

    Parameters
    ----------
    data_df : DataFrame
        Data used to compute the predictions. It must contain information
        about features (and treatment if effects for treatment specific
        subpopulations are desired as well).

    Returns
    -------
    results : Dictionary.
        Results.

    """
    time_start = time()
    report = {}

    # Get instances that contain the results from training
    mcf_1st = mcf_.iv_mcf['firststage']
    mcf_redf = mcf_.iv_mcf['reducedform']
    update_mcf_(mcf_, mcf_1st)

    # Initialise again with data information
    data_df = update_inst_data(mcf_, mcf_1st, mcf_redf, data_df)

    # Print information of dictionaries
    if mcf_.gen_cfg.with_output:
        print_dics(mcf_, mcf_1st, mcf_redf)

    # Prepare data and some descriptive stats
    data_df, report = prepare_data_pred(mcf_, data_df, report)
    for stage in (mcf_1st, mcf_redf):
        stage.var_cfg.x_name_balance_test = mcf_.var_cfg.x_name_balance_test.copy()
    time_1 = time()

    # Common support
    data_df, report, cs_pred_prob = common_support_pred(mcf_, data_df, report)
    time_2 = time()

    # Local centering for IATE
    if mcf_.lc_cfg.yes and mcf_.lc_cfg.uncenter_po:
        y_pred_x_df, d_pred_x_df = local_center(mcf_1st, mcf_redf, data_df)
        if mcf_.gen_cfg.ate_eff or mcf_.gen_cfg.iate_eff:
            y_pred_add_df, d_pred_add_df = local_center(
                mcf_1st, mcf_redf, data_df, prediction_round='additional',
                )
            y_pred_eff_df = (y_pred_x_df + y_pred_add_df) / 2
            d_pred_eff_df = (d_pred_x_df + d_pred_add_df) / 2
        else:
            y_pred_eff_df, d_pred_eff_df = y_pred_x_df, d_pred_x_df
    else:
        y_pred_x_df = d_pred_x_df = y_pred_eff_df = d_pred_eff_df = 0
    y_pred_ate_df = y_pred_eff_df if mcf_.gen_cfg.ate_eff else y_pred_x_df
    d_pred_ate_df = d_pred_eff_df if mcf_.gen_cfg.ate_eff else d_pred_x_df
    y_pred_iate_df = y_pred_eff_df if mcf_.gen_cfg.iate_eff else y_pred_x_df
    d_pred_iate_df = d_pred_eff_df if mcf_.gen_cfg.iate_eff else d_pred_x_df
    time_3 = time()

    # Initialise time related variables
    time_delta_weight = time_delta_late = time_delta_lbala = 0
    time_delta_lgate = time_delta_lcbgate = time_delta_lbgate = 0
    time_delta_liate = time_delta_lqiate = 0

    results_global, results_local = {}, {}
    effect_rounds = {}
    effect_groups = (
        (('late_global', 'late_local', 'ate_1st', 'ate_redf', 'bala_1st', 'bala_redf'),
         mcf_.gen_cfg.ate_eff),
        (('lgate', 'lgate_m_late', 'lbgate', 'lbgate_m_late', 'lcbgate', 'lcbgate_m_late'),
         mcf_.gen_cfg.gate_eff),
        (('liate', 'liate_m_late', 'iate_1st', 'iate_m_ate_1st', 'iate_redf', 'iate_m_ate_redf'),
         mcf_.gen_cfg.iate_eff),
    )
    for names, efficient in effect_groups:
        for name in names:
            effect_rounds[name] = [None, None] if efficient else [None]
    lgate_est_local_dic = lbgate_est_local_dic = lcbgate_est_local_dic = None
    txt_lbg = txt_lcbg = None

    global_effects = 'global' in mcf_.p_cfg.iv_aggregation_method
    local_effects = 'local' in mcf_.p_cfg.iv_aggregation_method
    need_local_weights = local_effects or mcf_.p_cfg.iate
    local_gate = local_effects and mcf_.p_cfg.gate
    local_bgate = local_effects and mcf_.p_cfg.bgate
    local_cbgate = local_effects and mcf_.p_cfg.cbgate
    only_one_fold_one_round = mcf_.cf_cfg.folds == 1 and len(mcf_.cf_cfg.est_rounds) == 1

    # Start with 1st stage only (as IATEs of 1st stage are needed for scaling)
    scaling_1st_dic, scaling_eff_1st_dic = mcf_iv_add.iate_1st_stage_all_folds_rounds(
        mcf_, mcf_1st, data_df, only_one_fold_one_round
        )
    time_1stscale = time()
    # Aggregate folds within each round, then combine only the requested efficient estimates.
    for fold in range(mcf_.cf_cfg.folds):
        for round_ in mcf_.cf_cfg.est_rounds:
            idx_round = 0 if round_ == 'regular' else 1
            estimate_ate = round_ == 'regular' or mcf_.gen_cfg.ate_eff
            estimate_gate = round_ == 'regular' or mcf_.gen_cfg.gate_eff
            estimate_iate = round_ == 'regular' or mcf_.gen_cfg.iate_eff
            time_w_start = time()
            forest_1st_dic, forest_redf_dic = get_forests(
                mcf_, mcf_1st=mcf_1st, mcf_redf=mcf_redf,
                only_one_fold_one_round=only_one_fold_one_round, fold=fold, round_=round_,
                )
            weights_1st_dic, weights_redf_dic, weights_local_dic = mcf_iv_add.get_weights_iv_local(
                mcf_, mcf_1st=mcf_1st, mcf_redf=mcf_redf,
                forest_1st_dic=forest_1st_dic, forest_redf_dic=forest_redf_dic,
                iate_1st_dic=scaling_1st_dic, iate_eff_1st_dic=scaling_eff_1st_dic,
                data_df=data_df, round_=round_, local_effects=need_local_weights,
                )
            time_delta_weight += time() - time_w_start
            weights = (weights_local_dic, weights_1st_dic, weights_redf_dic)
            instances = (mcf_, mcf_1st, mcf_redf)

            time_a_start = time()
            if estimate_ate:
                (_, w_late_local, effect_rounds['late_global'][idx_round],
                 effect_rounds['late_local'][idx_round], w_ate_1st,
                 effect_rounds['ate_1st'][idx_round], w_ate_redf,
                 effect_rounds['ate_redf'][idx_round]) = mcf_iv_add.ate_iv(
                    instances, weights=weights,
                    late_global_dic=effect_rounds['late_global'][idx_round],
                    late_local_dic=effect_rounds['late_local'][idx_round],
                    ate_1st_dic=effect_rounds['ate_1st'][idx_round],
                    ate_redf_dic=effect_rounds['ate_redf'][idx_round], data_df=data_df,
                    fold=fold, global_effects=global_effects, local_effects=need_local_weights,
                    )
            else:
                w_late_local = w_ate_1st = w_ate_redf = None
            time_delta_late += time() - time_a_start

            time_b_start = time()
            if estimate_ate and mcf_.p_cfg.bt_yes:
                (effect_rounds['bala_1st'][idx_round], effect_rounds['bala_redf'][idx_round]
                 ) = mcf_iv_add.bala_1st_redf(
                    instances, weights=weights,
                    bala_1st_dic=effect_rounds['bala_1st'][idx_round],
                    bala_redf_dic=effect_rounds['bala_redf'][idx_round], data_df=data_df, fold=fold,
                    )
            time_delta_lbala += time() - time_b_start

            iv_tuple = (mcf_1st, mcf_redf, forest_1st_dic, forest_redf_dic)
            time_lbgate_start = time()
            if estimate_gate and local_bgate:
                (_, effect_rounds['lbgate'][idx_round], _,
                 effect_rounds['lbgate_m_late'][idx_round], _, lbgate_est_local_dic, txt_lbg
                 ) = mcf_iv_add.bgate_iv(
                    mcf_, data_df, lbgate_global_dic=None,
                    lbgate_local_dic=effect_rounds['lbgate'][idx_round],
                    lbgate_m_late_global_dic=None,
                    lbgate_m_late_local_dic=effect_rounds['lbgate_m_late'][idx_round], fold=fold,
                    iv_tuple=iv_tuple, gate_type='BGATE', title='LBGATE', global_effects=False,
                    local_effects=True, round_=round_,
                    )
            time_delta_lbgate += time() - time_lbgate_start

            time_cbg_start = time()
            if estimate_gate and local_cbgate:
                (_, effect_rounds['lcbgate'][idx_round], _,
                 effect_rounds['lcbgate_m_late'][idx_round], _, lcbgate_est_local_dic, txt_lcbg
                 ) = mcf_iv_add.bgate_iv(
                    mcf_, data_df, lbgate_global_dic=None,
                    lbgate_local_dic=effect_rounds['lcbgate'][idx_round],
                    lbgate_m_late_global_dic=None,
                    lbgate_m_late_local_dic=effect_rounds['lcbgate_m_late'][idx_round], fold=fold,
                    iv_tuple=iv_tuple, gate_type='CBGATE', title='LCBGATE', global_effects=False,
                    local_effects=True, round_=round_,
                    )
            time_delta_lcbgate += time() - time_cbg_start
            if mcf_.int_cfg.del_forest:
                del forest_1st_dic['forest'], forest_redf_dic['forest']

            time_i_start = time()
            if mcf_.p_cfg.iate and estimate_iate:
                effect_rounds['liate'][idx_round], effect_rounds['liate_m_late'][idx_round] = (
                    mcf_iv_add.iate_iv(
                        mcf_, weights_dic=weights_local_dic,
                        iate_dic=effect_rounds['liate'][idx_round],
                        iate_m_ate_dic=effect_rounds['liate_m_late'][idx_round],
                        w_ate=w_late_local, round_=round_, fold=fold, iv=True, title='LIATE',
                        )
                    )
                effect_rounds['iate_1st'][idx_round], effect_rounds['iate_m_ate_1st'][idx_round] = (
                    mcf_iv_add.iate_iv(
                        mcf_1st, weights_dic=weights_1st_dic,
                        iate_dic=effect_rounds['iate_1st'][idx_round],
                        iate_m_ate_dic=effect_rounds['iate_m_ate_1st'][idx_round],
                        w_ate=w_ate_1st, round_=round_, fold=fold, iv=False,
                        title='IATE (1st stage)',
                        )
                    )
                (effect_rounds['iate_redf'][idx_round],
                 effect_rounds['iate_m_ate_redf'][idx_round]) = (
                    mcf_iv_add.iate_iv(
                        mcf_redf, weights_dic=weights_redf_dic,
                        iate_dic=effect_rounds['iate_redf'][idx_round],
                        iate_m_ate_dic=effect_rounds['iate_m_ate_redf'][idx_round],
                        w_ate=w_ate_redf, round_=round_, fold=fold, iv=False,
                        title='IATE (reduced form)',
                        )
                    )
            time_delta_liate += time() - time_i_start

            # QIATE estimation is not implemented for IV.
            time_q_start = time()
            mcf_.p_cfg.qiate = False
            time_delta_lqiate += time() - time_q_start

            time_g_start = time()
            if estimate_gate and local_gate:
                (_, effect_rounds['lgate'][idx_round], _,
                 effect_rounds['lgate_m_late'][idx_round], _, lgate_est_local_dic
                 ) = mcf_iv_add.gate_iv(
                    mcf_, data_df, weights=weights, w_late_local=w_late_local,
                    lgate_global_dic=None, lgate_local_dic=effect_rounds['lgate'][idx_round],
                    lgate_m_late_global_dic=None,
                    lgate_m_late_local_dic=effect_rounds['lgate_m_late'][idx_round], fold=fold,
                    global_effects=False, local_effects=True,
                    )
            time_delta_lgate += time() - time_g_start

        if not only_one_fold_one_round and mcf_.int_cfg.del_forest:
            mcf_redf.forest[fold] = None
            # BGATE/CBGATE reference samples still need every first-stage fold for scaling.
            if not (local_bgate or local_cbgate):
                mcf_1st.forest[fold] = None
        if mcf_.int_cfg.mp_use_old_ray:
            check_ray_shutdown(mcf_.int_cfg.mp_ray_shutdown, mcf_.gen_cfg.mp_parallel)

    if mcf_.int_cfg.del_forest:
        mcf_.forest = mcf_1st.forest = mcf_redf.forest = None

    del weights, weights_local_dic, weights_1st_dic, weights_redf_dic

    # IATE additional-round variances are zero; averaging retains the factor 1/2.
    late_global_dic = mcf_est.average_vals(effect_rounds['late_global'])
    late_local_dic = mcf_est.average_vals(effect_rounds['late_local'])
    ate_1st_dic = mcf_est.average_vals(effect_rounds['ate_1st'])
    ate_redf_dic = mcf_est.average_vals(effect_rounds['ate_redf'])
    bala_1st_dic = mcf_est.average_vals(effect_rounds['bala_1st'])
    bala_redf_dic = mcf_est.average_vals(effect_rounds['bala_redf'])
    lgate_local_dic = mcf_est.average_vals(effect_rounds['lgate'])
    lgate_m_late_local_dic = mcf_est.average_vals(effect_rounds['lgate_m_late'])
    lbgate_local_dic = mcf_est.average_vals(effect_rounds['lbgate'])
    lbgate_m_late_local_dic = mcf_est.average_vals(effect_rounds['lbgate_m_late'])
    lcbgate_local_dic = mcf_est.average_vals(effect_rounds['lcbgate'])
    lcbgate_m_late_local_dic = mcf_est.average_vals(effect_rounds['lcbgate_m_late'])
    liate_dic = mcf_est.average_vals(effect_rounds['liate'])
    liate_m_late_dic = mcf_est.average_vals(effect_rounds['liate_m_late'])
    iate_1st_dic = mcf_est.average_vals(effect_rounds['iate_1st'])
    iate_m_ate_1st_dic = mcf_est.average_vals(effect_rounds['iate_m_ate_1st'])
    iate_redf_dic = mcf_est.average_vals(effect_rounds['iate_redf'])
    iate_m_ate_redf_dic = mcf_est.average_vals(effect_rounds['iate_m_ate_redf'])

    # ATE
    time_a_start = time()
    # Initialise variable
    late_global = late_se_global = late_local = late_se_local = None
    late_effect_list = None

    if global_effects:
        late_global, late_se_global, late_effect_list = mcf_ate.ate_effects_print(
             mcf_, late_global_dic, y_pred_ate_df, balancing_test=False, extra_title='(LATE-global)'
             )
    if local_effects:
        late_local, late_se_local, late_effect_list = mcf_ate.ate_effects_print(
            mcf_, late_local_dic, y_pred_ate_df, balancing_test=False, extra_title='(LATE-local)'
            )
    ate_1st, ate_1st_se, ate_1st_effect_list = mcf_ate.ate_effects_print(
        mcf_1st, ate_1st_dic, d_pred_ate_df, balancing_test=False, extra_title='(1st stage)'
        )
    ate_redf, ate_redf_se, ate_redf_effect_list = mcf_ate.ate_effects_print(
        mcf_redf, ate_redf_dic, y_pred_ate_df, balancing_test=False, extra_title='(reduced form)'
        )
    time_delta_late += time() - time_a_start

    # GATE
    time_g_start = time()
    # Initialise variables
    # lgate_global = lgate_se_global = lgate_diff_global = None
    # lgate_diff_se_global = lgate_est_global_dic = None
    lgate_local = lgate_se_local = lgate_diff_local = None
    lgate_diff_se_local = None

    if local_gate:
        # if global_effects:
        #     (lgate_global, lgate_se_global,
        #      lgate_diff_global, lgate_diff_se_global,
        #      report['fig_gate_global']
        #      ) = mcf_gateout.gate_effects_print(mcf_, lgate_global_dic,
        #                                         lgate_m_late_global_dic,
        #                                         lgate_est_global_dic,
        #                                         late_global, late_se_global,
        #                                         gate_type='GATE',
        #                                         iv=True
        #                                         )

        (lgate_local, lgate_se_local, lgate_diff_local, lgate_diff_se_local,
         report['fig_gate_local']) = mcf_gateout.gate_effects_print(mcf_,
                                                                    effect_dic=lgate_local_dic,
                                                                    effect_m_ate_dic=
                                                                    lgate_m_late_local_dic,
                                                                    gate_est_dic=
                                                                    lgate_est_local_dic,
                                                                    ate=late_local,
                                                                    ate_se=late_se_local,
                                                                    gate_type='GATE', iv=True,
                                                                    )
    time_delta_lgate += time() - time_g_start

    # BGATE
    time_lbgate_start = time()
    # Initialise variables
    lbgate_local = lbgate_se_local = lbgate_diff_local = None
    lbgate_diff_se_local = None

    if local_bgate:
        (lbgate_local, lbgate_se_local, lbgate_diff_local, lbgate_diff_se_local,
         report['fig_bgate_local']) = mcf_gateout.gate_effects_print(mcf_,
                                                                     effect_dic=lbgate_local_dic,
                                                                     effect_m_ate_dic=
                                                                         lbgate_m_late_local_dic,
                                                                     gate_est_dic=
                                                                         lbgate_est_local_dic,
                                                                     ate=late_local,
                                                                     ate_se=late_se_local,
                                                                     gate_type='BGATE', iv=True,
                                                                     special_txt=txt_lbg
                                                                     )
    time_delta_lbgate += time() - time_lbgate_start

    # CBGATE
    time_cbg_start = time()
    # Initialise variables
    lcbgate_local = lcbgate_se_local = lcbgate_diff_local = lcbgate_diff_se_local = None

    if local_cbgate:
        (lcbgate_local, lcbgate_se_local, lcbgate_diff_local, lcbgate_diff_se_local,
         report['fig_cbgate_local']) = mcf_gateout.gate_effects_print(mcf_,
                                                                      effect_dic=lcbgate_local_dic,
                                                                      effect_m_ate_dic=
                                                                          lcbgate_m_late_local_dic,
                                                                      gate_est_dic=
                                                                          lcbgate_est_local_dic,
                                                                      ate=late_local,
                                                                      ate_se=late_se_local,
                                                                      gate_type='CBGATE', iv=True,
                                                                      special_txt=txt_lcbg,
                                                                      )
    time_delta_lcbgate += time() - time_cbg_start
    # Collect some information for results_dic
    if local_gate or local_bgate or local_cbgate:
        gate_names_values = mcf_gateout.get_names_values(mcf_, lgate_est_local_dic,
                                                         lbgate_est_local_dic, lcbgate_est_local_dic
                                                         )
    else:
        gate_names_values = None

    time_q_start = time()

    qliate = qliate_se = qliate_diff = qliate_diff_se = None
    # qliate_est_dic = None
    qliate_mopp = qliate_mopp_se = None
    time_delta_lqiate += time() - time_q_start  # QIATE

    # IATE
    time_i_start = time()
    if mcf_.p_cfg.iate:
        (liate, liate_se, liate_names_dic, liate_df, report['iate_text']
         ) = mcf_iate.iate_effects_print(mcf_, liate_dic, liate_m_late_dic,  # liate_eff_dic,
                                         y_pred_iate_df,
                                         extra_title='(LIATE)', iv=True, report=report,
                                         )
        if liate_df is not None:
            data_df.reset_index(drop=True, inplace=True)
            liate_df.reset_index(drop=True, inplace=True)
            liate_pred_df = pd.concat([data_df, liate_df], axis=1)
        else:
            liate_pred_df = None
    else:
        #  liate_eff = None
        liate = liate_se = liate_df = liate_pred_df = None
        liate_names_dic = None

    # IATE (1st stage)
    if mcf_.p_cfg.iate:
        (iate_1st, iate_1st_se,  # iate_1st_eff,
         iate_1st_names_dic, iate_1st_df,
         report['iate_1st_text']) = mcf_iate.iate_effects_print(mcf_1st, iate_1st_dic,
                                                                iate_m_ate_1st_dic,
                                                                d_pred_iate_df,
                                                                extra_title='(1st stage)', iv=False
                                                                )
        if iate_1st_df is not None:
            data_df.reset_index(drop=True, inplace=True)
            iate_1st_df.reset_index(drop=True, inplace=True)
            iate_1st_pred_df = pd.concat([data_df, iate_1st_df], axis=1)
        else:
            iate_1st_pred_df = None
    else:
        # iate_1st_eff = None
        iate_1st = iate_1st_se = iate_1st_df = None
        iate_1st_pred_df = iate_1st_names_dic = None

    # IATE (reduced form)
    if mcf_.p_cfg.iate:
        (iate_redf, iate_redf_se,  # iate_redf_eff,
         iate_redf_names_dic,
         iate_redf_df, report['iate_redf_text']) = mcf_iate.iate_effects_print(
             mcf_redf, iate_redf_dic, iate_m_ate_redf_dic,  # iate_eff_redf_dic,
             y_pred_iate_df, extra_title='(reduced form)', iv=False
             )
        if iate_redf_df is not None:
            data_df.reset_index(drop=True, inplace=True)
            iate_redf_df.reset_index(drop=True, inplace=True)
            iate_redf_pred_df = pd.concat([data_df, iate_redf_df], axis=1)
        else:
            iate_redf_pred_df = None
    else:
        #  iate_redf_eff = None
        iate_redf = iate_redf_se = iate_redf_df = None
        iate_redf_pred_df = iate_redf_names_dic = None

    time_delta_liate += time() - time_i_start

    # Balancing test
    time_b_start = time()
    if mcf_.p_cfg.bt_yes:
        bala_1st, bala_1st_se, bala_1st_effect_list = mcf_ate.ate_effects_print(mcf_, bala_1st_dic,
                                                                                None,
                                                                                balancing_test=True
                                                                                )
        bala_redf, bala_redf_se, bala_redf_effect_list = mcf_ate.ate_effects_print(
            mcf_, bala_redf_dic, None, balancing_test=True
            )
    else:
        bala_1st = bala_1st_se = bala_1st_effect_list = None
        bala_redf = bala_redf_se = bala_redf_effect_list = None
    time_delta_lbala += time() - time_b_start

    results_both = {'ate_1st': ate_1st, 'ate_1st_se': ate_1st_se,
                    'ate 1st_effect_list': ate_1st_effect_list,
                    'ate_redf': ate_redf, 'ate_redf_se': ate_redf_se,
                    'ate redf_effect_list': ate_redf_effect_list,
                    'qiate': qliate, 'qiate_se': qliate_se,
                    'qiate_diff': qliate_diff, 'qiate_diff_se': qliate_diff_se,
                    'qiate_mopp': qliate_mopp, 'qiate_mopp_se': qliate_mopp_se,
                    'iate': liate, 'iate_se': liate_se,  # 'iate_eff': liate_eff,
                    'iate_1st': iate_1st, 'iate_1st_se': iate_1st_se,
                    'iate_redf': iate_redf, 'iate_redf_se': iate_redf_se,
                    'iate_data_df': liate_pred_df, 'iate_1st_pred_df': iate_1st_pred_df,
                    'iate_redf_pred_df': iate_redf_pred_df, 'iate_names_dic': liate_names_dic,
                    'iate_1st_names_dic': iate_1st_names_dic,
                    'iate_redf_names_dic': iate_redf_names_dic,
                    'bala_1st': bala_1st, 'bala_1st_se': bala_1st_se,
                    'bala_1st_effect_list': bala_1st_effect_list,
                    'bala_redf': bala_redf, 'bala_redf_se': bala_redf_se,
                    'bala_redf_effect_list': bala_redf_effect_list,
                    'ate_effect_list': late_effect_list,
                    'gate_names_values': gate_names_values,
                    'common_support_probabilities': cs_pred_prob,
                    'path_output': mcf_.gen_cfg.outpath,
                    }

    if global_effects:
        results_global = {'ate': late_global, 'ate_se': late_se_global,
                          'gate': None,  # lgate_global,
                          'gate_se': None,  # lgate_se_global,
                          'gate_diff': None,  # lgate_diff_global,
                          'gate_diff_se': None,  # lgate_diff_se_global,
                          'cbgate': None,  # lcbgate_global, 'cbgate_se': lcbgate_se_global,
                          'cbgate_diff': None,  # lcbgate_diff_global,
                          'cbgate_diff_se': None,  # lcbgate_diff_se_global,
                          'bgate': None,   # lbgate_global,
                          'bgate_se': None,  # lbgate_se_global,
                          'bgate_diff': None,  # lbgate_diff_global,
                          'bgate_diff_se': None,  # lbgate_diff_se_global,
                          }
        results_global.update(deepcopy(results_both))

    if local_effects:
        results_local = {'ate': late_local, 'ate_se': late_se_local,
                         'gate': lgate_local, 'gate_se': lgate_se_local,
                         'gate_diff': lgate_diff_local, 'gate_diff_se': lgate_diff_se_local,
                         'cbgate': lcbgate_local, 'cbgate_se': lcbgate_se_local,
                         'cbgate_diff': lcbgate_diff_local,
                         'cbgate_diff_se': lcbgate_diff_se_local,
                         'bgate': lbgate_local, 'bgate_se': lbgate_se_local,
                         'bgate_diff': lbgate_diff_local,
                         'bgate_diff_se': lbgate_diff_se_local,
                         }
        results_local.update(deepcopy(results_both))

    if mcf_.gen_cfg.with_output:
        if global_effects:
            results_global_dic = deepcopy(results_global)
            del results_global_dic['iate_data_df']
            report['mcf_pred_results_global'] = results_global_dic

        if local_effects:
            results_local_dic = deepcopy(results_local)
            del results_local_dic['iate_data_df']
            report['mcf_pred_results_local'] = results_local_dic  # in report
        mcf_.report['predict_list'].append(report.copy())

    time_end = time()

    if mcf_.gen_cfg.with_output:
        time_string = ['Data preparation and stats II:                  ',
                       'Common support:                                 ',
                       'Local centering (recoding of Y):                ',
                       'First stage scaling :                           ',
                       'Weights (for IATE and LIATE):                   ',
                       'LATEs:                                          ',
                       'LGATEs:                                         ',
                       'LBGATEs:                                        ',
                       'LCBGATEs:                                       ',
                       'LQIATEs:                                        ',
                       'LIATEs:                                         ',
                       'Balancing test:                                 ',
                       '\nTotal time prediction:                          ',
                       ]
        time_difference = [time_1 - time_start, time_2 - time_1, time_3 - time_2,
                           time_1stscale - time_3,
                           time_delta_weight, time_delta_late, time_delta_lgate,
                           time_delta_lbgate, time_delta_lcbgate, time_delta_lqiate,
                           time_delta_liate, time_delta_lbala, time_end - time_start
                           ]
        mcf_ps.print_mcf(mcf_.gen_cfg, mcf_.time_strings['time_train'])
        time_pred = mcf_ps.print_timing(mcf_.gen_cfg, 'Prediction', time_string, time_difference,
                                        summary=True
                                        )
        mcf_.time_strings['time_pred'] = time_pred

    return results_global, results_local


def ensure_binary_binary(mcf_: 'ModifiedCausalForest', data_df: pd.DataFrame) -> pd.DataFrame:
    """Validate binary treatment and instrument values before integer conversion."""
    iv_names, d_names = mcf_.var_cfg.iv_name, mcf_.var_cfg.d_name
    if len(iv_names) != 1 or len(d_names) != 1:
        raise ValueError('IV estimation requires one instrument column and one treatment column.')

    instrument = pd.to_numeric(data_df[iv_names[0]], errors='raise')
    if not instrument.isin((0, 1)).all():
        raise ValueError('Instrument must contain only 0 and 1.')
    if not data_df[d_names[0]].isin((0, 1)).all():
        raise ValueError('Treatment must be binary.')

    data_df[iv_names[0]] = instrument.astype(int)

    return data_df


def print_dics(mcf_: 'ModifiedCausalForest',
               mcf_1st: 'ModifiedCausalForest',
               mcf_redf: 'ModifiedCausalForest'
               ) -> None:
    """Print values of dictionaries."""
    mcf_ps.print_dic_values_all(mcf_, summary_top=True, summary_dic=False, train=False, title='IV')
    mcf_ps.print_dic_values_all(mcf_1st, summary_top=False, summary_dic=False, train=False,
                                title='IV (1st stage)'
                                )
    mcf_ps.print_dic_values_all(mcf_redf, summary_top=True, summary_dic=False, train=False,
                                title='IV (reduced form)'
                                )


def update_mcf_(mcf_: 'ModifiedCausalForest', mcf_1st: 'ModifiedCausalForest') -> None:
    """Update mcf_ instance."""
    # Copy some attributes of mcf_1st to mcf_
    mcf_.cf_cfg.folds = mcf_1st.cf_cfg.folds
    mcf_.cf_cfg.est_rounds = mcf_1st.cf_cfg.est_rounds
    mcf_.cf_cfg.x_name_mcf = mcf_1st.cf_cfg.x_name_mcf.copy()


def update_inst_data(mcf_: 'ModifiedCausalForest',
                     mcf_1st: 'ModifiedCausalForest',
                     mcf_redf: 'ModifiedCausalForest',
                     data_df: pd.DataFrame
                     ) -> pd.DataFrame:
    """Apply current prediction settings while retaining each stage's fitted state."""
    data_df, _ = mcf_data.data_frame_vars_lower(data_df)
    data_df = mcf_init_update.p_update_pred(mcf_, data_df)

    if mcf_.p_cfg.d_in_pred:
        data_df = mcf_data.check_recode_treat_variable(mcf_, data_df, train=False)

    for stage in (mcf_1st, mcf_redf):
        for cfg_name in ('p_cfg', 'post_cfg'):
            source_cfg = getattr(mcf_, cfg_name)
            target_cfg = getattr(stage, cfg_name)
            for item in fields(source_cfg):
                if item.init:
                    setattr(target_cfg, item.name, deepcopy(getattr(source_cfg, item.name)))
        stage.p_cfg.gate = mcf_.p_cfg.gate

        for name in ('yes', 'adj_method', 'pos_weights_only', 'use_x', 'use_prop_score',
                     'use_prog_score', 'ridge'):
            setattr(stage.p_ba_cfg, name, deepcopy(getattr(mcf_.p_ba_cfg, name)))

        for name in ('x_name_balance_test_ord', 'x_name_balance_test_unord',
                     'x_name_balance_test', 'x_name_balance_bgate', 'z_name_ord',
                     'z_name_unord', 'z_name_cont', 'z_name'):
            setattr(stage.var_cfg, name, deepcopy(getattr(mcf_.var_cfg, name)))

        for name in ('output_type', 'print_to_file', 'print_to_terminal', 'outfiletext',
                     'outfilesummary', 'outpath', 'agg_yes'):
            setattr(stage.gen_cfg, name, deepcopy(getattr(mcf_.gen_cfg, name)))

        mcf_init_update.p_update_pred(stage, data_df)

    for instance in (mcf_, mcf_1st, mcf_redf):
        mcf_init_update.int_update_pred(instance, len(data_df))
        mcf_init_update.post_update_pred(instance, data_df)

    return data_df


def local_center(mcf_1st: 'ModifiedCausalForest',
                 mcf_redf: 'ModifiedCausalForest',
                 data_df: pd.DataFrame, *,
                 prediction_round: str = 'regular',
                 ) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compute the centering predictions for the requested IV estimation round."""
    _, _, d_pred_x_df, _ = mcf_lc.local_centering(
        mcf_1st, data_df, fill_y_df=None, train=False, title='(1st stage)',
        prediction_round=prediction_round,
        )
    _, _, y_pred_x_df, _ = mcf_lc.local_centering(
        mcf_redf, data_df, fill_y_df=None, train=False, title='(reduced form)',
        prediction_round=prediction_round,
        )
    return y_pred_x_df, d_pred_x_df


def get_forests(mcf_: 'ModifiedCausalForest', *,
                mcf_1st: 'ModifiedCausalForest',
                mcf_redf: 'ModifiedCausalForest',
                only_one_fold_one_round: bool,
                fold: int, round_: bool
                ) -> tuple[dict, dict]:
    """Extract forsts."""
    if only_one_fold_one_round:
        forest_1st_dic = mcf_1st.forest[fold][0]
        forest_redf_dic = mcf_redf.forest[fold][0]
    else:
        forest_1st_dic = deepcopy(mcf_1st.forest[fold][0 if round_ == 'regular' else 1])
        forest_redf_dic = deepcopy(mcf_redf.forest[fold][0 if round_ == 'regular' else 1])
    if mcf_.gen_cfg.with_output and mcf_.gen_cfg.verbose:
        print(f'\n\nWeight maxtrix (all effects) {fold+1} /',
              f'{mcf_.cf_cfg.folds} forests, {round_}')

    return forest_1st_dic, forest_redf_dic


def new_instances_iv_train(mcf_: 'ModifiedCausalForest'
                           ) -> tuple['ModifiedCausalForest', 'ModifiedCausalForest']:
    """Create instances for 1st stage and reduced form."""
    mcf_1st = deepcopy(mcf_)
    mcf_1st.var_cfg.y_name = mcf_.var_cfg.d_name.copy()
    mcf_1st.var_cfg.y_tree_name = mcf_1st.var_cfg.y_name
    mcf_1st.var_cfg.d_name = mcf_.var_cfg.iv_name.copy()
    mcf_1st.gen_cfg.verbose = False

    mcf_redf = deepcopy(mcf_)
    mcf_redf.var_cfg.d_name = mcf_.var_cfg.iv_name.copy()
    mcf_redf.gen_cfg.verbose = False

    return mcf_1st, mcf_redf


def prepare_data_pred(mcf_: 'ModifiedCausalForest',
                      data_df: pd.DataFrame,
                      report: dict
                      ) -> tuple[pd.DataFrame, dict]:
    """Prepare data and print some descriptive statistics."""
    # Prepare data: Add and recode variables for GATES (Z)
    #             Recode categorical variables to prime numbers, cont. vars
    data_df = mcf_data.create_xz_variables(mcf_, data_df, train=False)
    if mcf_.gen_cfg.with_output and mcf_.gen_cfg.verbose:
        mcf_data.print_prime_value_corr(mcf_.data_train_dict, mcf_.gen_cfg, summary=False)

    # Clean data and remove missings and unncessary variables
    if mcf_.dc_cfg.clean_data:
        data_df, report['prediction_obs'] = mcf_data.clean_data(mcf_, data_df, train=False)

    # Descriptives by treatment
    if mcf_.p_cfg.d_in_pred and mcf_.int_cfg.descriptive_stats and mcf_.gen_cfg.with_output:
        mcf_ps.desc_by_treatment(mcf_, data_df, summary=False, stage=3)

    return data_df, report


def common_support_pred(mcf_: 'ModifiedCausalForest',
                        data_df: pd.DataFrame,
                        report: dict
                        ) -> tuple[pd.DataFrame, dict, pd.DataFrame | None]:
    """Adjust common support based on training information."""
    if mcf_.cs_cfg.type_:
        (data_df, _, report['cs_p_share_deleted'], report['cs_p_obs_remain'], _, _, _, cs_pred_prob
         ) = mcf_cs.common_support_p_score(mcf_, data_df, None, train=False, p_score_only=False)
    else:
        cs_pred_prob = None

    data_df = data_df.copy().reset_index(drop=True)
    if mcf_.p_cfg.d_in_pred and mcf_.int_cfg.descriptive_stats and mcf_.gen_cfg.with_output:
        mcf_ps.desc_by_treatment(mcf_, data_df, summary=True, stage=3)

    return data_df, report, cs_pred_prob
