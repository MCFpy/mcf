# Project Description 

mcf is a Python package that provides a fast and easy implementation of the Modified Causal Forest (MCF). The scope of the MCF is to estimate heterogeneous treatment effects for multiple treatment models in a selection-on-observables setting.
