"""Created on Fri Dec  8 13:42:19 2023.

Contains classes and methods needed for mcf and optimal policy reporting.

# -*- coding: utf-8 -*-

@author: MLechner
"""
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from mcf.optpolicy_main import OptimalPolicy, OptimalPolicyVersions


def opt_fairness(opt_o: 'OptimalPolicy', empty_lines_end: int) -> str:
    """Text content for the fairness (protected variables) adjustment."""
    prot_vars = [*opt_o.var_cfg.protected_ord_name, *opt_o.var_cfg.protected_unord_name]
    mat_vars = [*opt_o.var_cfg.material_ord_name,*opt_o.var_cfg.material_unord_name]
    txt = ('\nBACKGROUND'
           '\nThis fairness module is experimental. It is a preview of what '
           'will be analysed in the paper by Bearth, Lechner, Mareckova, and '
           'Muny (2024): Explainable Optimal Policy with Protected Variables. '
           'The adjustments aim to reduce dependence of policy scores and/or decision '
           'variables on protected features, while allowing for materially relevant features. '
           'Mean and MeanVar target conditional moments and do not guarantee that resulting '
           'allocations are independent of protected features. '
           '\nCurrently the following methods are available for the adjustments: '
           '\n(1) Mean: Residualisation using estimated conditional means aims to remove '
           'mean dependence on protected features, while retaining the component associated '
           'with materially relevant features.'
           '\n(2) MeanVar: In addition to the mean adjustment, rescaling using estimated '
           'conditional standard deviations aims to remove heteroscedasticity associated '
           'with protected features, while retaining variation associated with materially '
           'relevant features.'
           '\n(3) Quantiled: insprired by the quantile based an approach suggested by '
           'Strack & Yang (2024), but extended to address multiple treatments and possibly '
           'continuous protected and / or materially important features. If there are many values '
           'of the materially relevant features, features may be either discretized or treated as '
           'continuous. If treated as continuous, the respective densities needed to obtain the '
           'quantile positions are estimated by kernel density estimation (scikit-learn) '
           'within cells defined by the values of the protected features, if protected features '
           'are discrete or discretized. If the protected features are treated '
           'as continuous, respective conditional densities are estimated. Since the quality of '
           'the nonparametric estimators of these multivariate densities is rapidly declining '
           'with the dimension of the materially relevant variables, their dimension should be '
           'kept as small as possible (or they should be discretized).'
           '\n\nReference'
           '\n-Strack, Philipp, and Kai Hao Yang (2024): Privacy Preserving Signals, arXiv.'
           )

    txt += ('\n\nIMPLEMENTATION '
            f'\nProtected features: {", ".join(prot_vars)}. ')
    if mat_vars:
        txt += (f'\nMaterially relevant features: {", ".join(mat_vars)}. '
                '\nMaterially relevant features may be correlated with the protected features. '
                'Therefore, adjusted scores may still be correlated with protected features '
                'through their relationship with materially relevant features. '
                )
    txt += ('\n\nDiscretization settings for quantile adjustments, when needed:'
            '\nFeatures with sufficiently few values use exact cells without coarsening.'
            )
    for label, names, method, max_groups in (
            ('Protected', prot_vars, opt_o.fair_cfg.protected_disc_method,
             opt_o.fair_cfg.protected_max_groups),
            ('Materially relevant', mat_vars, opt_o.fair_cfg.material_disc_method,
             opt_o.fair_cfg.material_max_groups)):
        if not names:
            continue
        txt += f'\n{label} features: '
        match method:
            case 'EqualCell':
                txt += (f'up to {max_groups} groups per feature, '
                        'aiming for approximately equal group sizes.'
                        )
            case 'Kmeans':
                txt += f'k-means++ clustering with {max_groups} requested clusters.'
            case 'ExactCell':
                txt += 'exact cells without coarsening.'
            case 'NoDiscretization':
                txt += 'no discretization.'
    fair_txt = opt_o.report.get('fairscores_delete_x_vars_txt')
    if isinstance(fair_txt, str):
        txt += '\n' + fair_txt
    if 'fairscores_build_stats' in opt_o.report:
        txt += '\n' + opt_o.report['fairscores_build_stats']
    if 'fair_decision_vars_build_stats' in opt_o.report:
        txt += '\n' + opt_o.report['fair_decision_vars_build_stats']
    txt += ('\n\nTo see whether the resulting decision rules are still '
            'dependent on the protected variable, check the variable '
            'importance statistics in the output files as well.'
            )
    return txt + '\n' * empty_lines_end


def opt_estimationrisk(opt_o: 'OptimalPolicy', empty_lines_end: int) -> str:
    """Text content for the estimation risk adjustment."""
    txt = ('\nBACKGROUND'
           '\nThis module adjusting the policy score is experimental. Generally, the idea '
           'implemented follows the paper by Chernozhukov, Lee, Rosen, and Sun (2025). However, '
           'since several approximations are used in the algorithm, the methods will not have '
           'the direct confidence-level-related interpretations suggested by these authors. '
           '\nThe scores are adjusted by substracting a multiple of their standard errors. '
           '\n\nReference'
           '\n-Chernozhukov, Lee, Rosen, and Sun (2025), Policy Learning With Confidence, arXiv.'
           )

    txt += ('\n\nIMPLEMENTATION '
            f'\nStandard errors of policy scores: {", ".join(opt_o.var_cfg.polscore_se_name)}. '
            f'\nMultiplier used for adjustment: {opt_o.estriskcfg.value}. '
            )
    return txt + '\n' * empty_lines_end


def opt_allocation(opt_o: dict, empty_lines_end: int) -> str:
    """Text allocation part of description."""
    txt = ''
    for idx, alloc in enumerate(opt_o.report['alloc_list']):
        txt += alloc
        if idx < len(opt_o.report['alloc_list'])-1:
            txt += '\n' * 3 + 'NEXT ALLOCATION\n'

    return txt + '\n' * empty_lines_end


def opt_evaluation(opt_o: 'OptimalPolicy') -> tuple[str, list[tuple[str, pd.DataFrame]]]:
    """Text evaluation part of description."""
    def results_dic_to_df(results_dic):
        treat_values = ['Share of ' + str(s) + ' in %' for s in opt_o.gen_cfg.d_values]
        columns = ['Gross value', 'Net value', *treat_values]
        for idx, key in enumerate(results_dic):
            index = next(iter(results_dic[key]))   # first key
            if isinstance(results_dic[key][index], (list, tuple)) and (
                    len(results_dic[key][index]) == 1):
                data = [round(results_dic[key][index][0], 4),
                        round(results_dic[key].get('welfare net of costs', np.nan), 4),
                        *list(np.round(results_dic[key]['treatment share'] * 100, 2))
                        ]
                tmp_df = pd.DataFrame([data], index=(index,), columns=columns, copy=True)

            elif isinstance(results_dic[key][index], float) and key == index:
                data = [round(results_dic[key][index], 4),
                        round(results_dic[key].get('welfare net of costs', np.nan), 4),
                        *list(np.round(results_dic[key]['treatment share'] * 100, 2))
                        ]
                tmp_df = pd.DataFrame([data], index=(index,), columns=columns, copy=True)

            else:
                data = [*list(np.round(results_dic[key]['treatment share']*100, 2))]
                tmp_df = pd.DataFrame([data], index=(key,), columns=columns[2:], copy=True)
            if idx == 0:
                table_df = tmp_df
            else:
                table_df = pd.concat((table_df.copy(), tmp_df), axis=0)
        return table_df

    txt_table_list = []
    general_txt = ('\nMain evaluation results.'
                   '\n\nNote: The output files contain relevant additional information, like a '
                   'descriptive analysis of the treatment groups'
                   )
    if (opt_o.gen_cfg.variable_importance
            and (opt_o.var_cfg.vi_x_name or opt_o.var_cfg.vi_to_dummy_name)):
        general_txt += ' and variable importance statistics'
    general_txt += '.'
    if opt_o.gen_cfg.with_output and opt_o.gen_cfg.method in ('policy_tree', 'bps_classifier'):
        general_txt += ('\nQini-like plots, when generated, are saved alongside the text output. '
                        'They require usable policy scores and suitable policy and reference '
                        'allocations. Reference rules include the observed allocation, a random '
                        'allocation, and the uniform allocation with the highest mean score '
                        'net of treatment costs, where available. '
                        'The plots show mean welfare net of treatment costs as an increasing '
                        'share of observations receives the learned allocation and the remainder '
                        'receives the reference allocation. Observations are switched in '
                        'descending order of their net welfare gain.'
                        )
    for evalu in opt_o.report['evalu_list']:
        txt = evalu[0] + (
            '\nGross and net values show mean policy scores before and after subtracting '
            'treatment costs, respectively.'
            )
        table_df = results_dic_to_df(evalu[1])
        txt_table_list.append((txt, table_df))

    return general_txt, txt_table_list


def opt_training(opt_o: 'OptimalPolicy', empty_lines_end: int = 2) -> str:
    """Text training part of description."""
    txt = '\nCOMPUTATION'
    txt += f'\n{opt_o.gen_cfg.mp_parallel} logical cores are used for processing.'
    if (opt_o.int_cfg.xtr_parallel and
            opt_o.gen_cfg.method in ('policy_tree', 'policy tree old',)):
        txt += '\nContinuous variables are internally split for best use of cpu ressources.'

    screen = 'removed_vars' in opt_o.report
    percorr = screen and opt_o.dc_cfg.check_perfectcorr
    dummy = opt_o.dc_cfg.min_dummy_obs if screen else 0
    txt += '\n' * 2 + 'DATA PREPARATION'
    if screen:
        txt += '\nVariables without variation are removed.'
    if percorr:
        txt += '\nVariables that are perfectly correlated with other variables are removed.'
    if dummy:
        txt += ('\nDummy variables with less than '
                f'{opt_o.dc_cfg.min_dummy_obs} observations in the smaller group are removed.'
                )
    txt += '\nRows with any missing values for variables needed for training are removed.'
    if opt_o.gen_cfg.method in ('best_policy_score', 'bps_classifier'):
        if opt_o.other_cfg.restricted:
            txt += '\n' * 2 + 'RESTRICTIONS on treatment shares'
            txt += ('\nThe unrestricted allocation is retained as a benchmark. Additional '
                    'allocations use integer treatment capacities derived from the specified '
                    'maximum shares:'
                    '\n1) Randomly assign units to treatments with remaining capacity.'
                    '\n2) Process units in descending order of their best net-score gain '
                    'relative to treatment 0. Assign each unit to the treatment with the '
                    'highest net policy score among those with remaining capacity.'
                    '\n3) Process units in random order. Assign each unit to the treatment '
                    'with the highest net policy score among those with remaining capacity.'
                    )
            if opt_o.var_cfg.bb_restrict_name:
                priority_var = opt_o.var_cfg.bb_restrict_name[0]
                txt += (f'\n4) When the priority variable {priority_var} is available, '
                        'process units in descending order of that variable. Assign each '
                        'unit to the treatment with the highest net policy score among '
                        'those with remaining capacity.'
                        )
    elif opt_o.gen_cfg.method in ('policy_tree', 'policy tree old',):
        if opt_o.other_cfg.restricted:
            txt += '\n' * 2 + 'RESTRICTIONS on treatment shares'
            txt += ('\nRestrictions are taken into account by modifying the policy scores with '
                    'artificial costs. These artificial costs are computed such that a Black-Box '
                    'allocation will respect the constraints automatically.'
                    )
            cm_1 = [cm == 1 for cm in opt_o.other_cfg.costs_of_treat_mult]
            if not all(cm_1):
                mult = [str(mul) for mul in opt_o.other_cfg.costs_of_treat_mult]
                txt += ('These automatic costs are adjusted by the user '
                        f'using the following multipliers: {", ".join(mult)}.'
                        )
            txt += ('\nIf the allocated treatment shares are not close enough to the desired '
                    'shares, then these artificial costs can be adjusted by specifying/changing '
                    'the cost multiplier (keyword "other_costs_of_treat_mult"). '
                    )
            if opt_o.pt_cfg.enforce_restriction:
                txt += ('\nTrees that violate restrictions are not considered. Note that this '
                        'option increases computation substantially and may not work well for '
                        'two sequential optimal trees. Use only if you know what you do.'
                        )
        txt += '\n' * 2 + 'COMPUTATIONAL EFFICIENCY'
        txt += ('\nOptimal policy trees are computationally very demanding. '
                'Therefore, several approximation parameters are used.'
                '\nFor continuous variables, the baseline number of candidate split points is '
                f'{opt_o.pt_cfg.no_of_evalupoints}. '
                'Candidates occupy roughly equally spaced positions in the sorted data. '
                'This setting is used at each splitting decision, so '
                'the approximation improves the smaller the data in the leaf becomes. Reducing '
                'this value can shorten computation time, at the cost of a coarser search for '
                'the best split.'
                )
        txt += ('\nThe depth of the tree is also a key parameter. Usually, it is very hard to '
                'estimate trees beyond the depth of 4 (16 leaves) with reasonably sized training '
                'data. There are two options to improve the computational performance. The '
                'first one is to reduce the depth (leading to loss of efficiency but a gain in '
                'interpretability). The second option is to split the tree building into several '
                'steps. '
                )
        if opt_o.pt_cfg.depth_tree_2 > 1:
            txt += ('\nTwo-stage tree construction is requested. '
                    f'The requested depth of the first tree is {opt_o.pt_cfg.depth_tree_1-1}; '
                    'the requested depth of each second-stage tree is '
                    f'{opt_o.pt_cfg.depth_tree_2-1}. '
                    f'The requested total depth is {opt_o.pt_cfg.depth-1}. '
                    'If no feasible tree is found at a requested depth, the depth is reduced. '
                    'Some first-stage leaves may receive no second-stage tree. '
                    'Building trees sequentially adds an approximation relative to optimising '
                    'the entire tree jointly.'
                    )
        else:
            txt += 'However, the second option is not used here.'
        txt += ('\nAnother parameter crucial for performance is the minimum leaf size. Too small '
                'leaves may be undesirable for practical purposes (and they increase computation '
                'times). The minimum leaf size in this application is set to '
                f' {round(opt_o.pt_cfg.min_leaf_size)}.'
                )
        txt += ('\nIn addition, the user may reduce the size of the training '
                'data to increase speed, but this will increase sampling noise.'
                )
        txt += '\n' * 2 + 'CATEGORICAL VARIABLES'
        efficient_tree = opt_o.gen_cfg.method == 'policy_tree'
        cat_limit = opt_o.pt_cfg.no_of_evalupoints
        if efficient_tree:
            cat_limit = max(1, int(cat_limit * opt_o.pt_cfg.eva_cat_mult))

        txt += ('\nCategorical splits partition categories into two groups. '
                f'The search considers up to {cat_limit} candidate partitions per variable '
                'and node. When there are sufficiently few possible partitions, exhaustive '
                'search is used. Otherwise, an approximation is used.'
                )
        if efficient_tree and opt_o.pt_cfg.select_values_cat:
            txt += ('\nFor the approximation, a random subset of categories is selected. '
                    'Candidate groups are formed from these categories, with all remaining '
                    'categories assigned to the complementary group.'
                    )
        else:
            txt += ('\nFor the approximation, categories are ordered by policy-score '
                    'differences. Candidate partitions are formed from these orderings '
                    'and randomly sampled if their number exceeds the limit.'
                    )
            if efficient_tree:
                txt += (' If fewer candidates are obtained, additional random partitions '
                        'are generated up to the limit.'
                        )
        if opt_o.report['training_leaf_information'] is not None:
            txt += '\n' * 3 + 'STRUCTURE OF FINAL TREE'
            txt += opt_o.report['training_leaf_information']

    return txt + '\n' * empty_lines_end


def opt_general(opt_o: 'OptimalPolicy', empty_lines_end: int) -> str:
    """Collect general optimal policy information."""
    txt = '\nMETHOD'
    txt += '\nThe assignment rule is based on allocating units '
    method = opt_o.gen_cfg.method
    match method:
        case 'best_policy_score':
            txt += ('initially to the treatment with the highest policy score net of '
                    'treatment costs.'
                    )
            if opt_o.other_cfg.restricted:
                txt += (' Additional allocations account for the specified treatment-share '
                        'constraints.'
                        )

        case 'policy_tree' | 'policy tree old':
            txt += f'using a shallow decision tree with requested depth {opt_o.pt_cfg.depth-1} '
            if opt_o.pt_cfg.depth_tree_2 > 1:
                txt += ('(based on 2 optimal trees, '
                        f'requested depth of 1st tree: {opt_o.pt_cfg.depth_tree_1-1},'
                        f' requested depth of 2nd tree: {opt_o.pt_cfg.depth_tree_2-1})'
                        )
            txt += '.'
            if opt_o.gen_cfg.method == 'policy tree old':
                txt += '\n   Older, less efficient method used for tree building.'

        case 'bps_classifier':
            txt += ('using a classifier (for all allocations considered by the '
                    'best_policy_score algorithm).'
                    )
    txt += '\n\nVARIABLES provided'
    var_cfg = opt_o.var_cfg
    txt += f'\nPolicy scores: {", ".join(var_cfg.polscore_name)}'

    if var_cfg.polscore_desc_name:
        txt += ('\nTreatment dependent variables for descriptive analysis: '
                f'{", ".join(var_cfg.polscore_desc_name)}'
                )
    if (opt_o.gen_cfg.method in ('best_policy_score', 'bps_classifier')
            and var_cfg.bb_restrict_name and opt_o.other_cfg.restricted):
        txt += ('\nVariables determining prioritisation of units in case of '
                'binding constraints for the best_policy_score method: '
                f'{", ".join(var_cfg.bb_restrict_name)}'
                )
    if var_cfg.d_name:
        txt += f'\nTreatment: {var_cfg.d_name[0]}'
    if var_cfg.id_name:
        txt += f'\nIdentifier: {var_cfg.id_name[0]}'
    if var_cfg.x_ord_name:
        txt += f'\nOderered features: {", ".join(var_cfg.x_ord_name)}'
    if var_cfg.x_unord_name:
        txt += f'\nCategorical / unorderered features: {", ".join(var_cfg.x_unord_name)}'
    if var_cfg.vi_x_name and opt_o.gen_cfg.variable_importance:
        txt += ('\nFeatures used for variable importance statistics without '
                f'transformations: {", ".join(var_cfg.vi_x_name)}'
                )
    if var_cfg.vi_to_dummy_name and opt_o.gen_cfg.variable_importance:
        txt += ('\nFeatures that are '
                'transformed to indicator/dummy variables for variable '
                'importance computations (only): '
                f'{", ".join(var_cfg.vi_to_dummy_name)}'
                )
    txt += '\n' * 2 + 'COSTS'
    if (opt_o.other_cfg.costs_of_treat is not None
            and any(cost != 0 for cost in opt_o.other_cfg.costs_of_treat)
            ):
        cost = [str(cos) for cos in opt_o.other_cfg.costs_of_treat]
        txt += '\n' * 2 + f'Used provided treatment specific costs: {", ".join(cost)}'
    else:
        txt += '\nNo user provided costs of specific treatments.'
    txt += '\n' * 2 + 'RESTRICTIONS of treatment shares'
    if opt_o.other_cfg.restricted:
        share = [f'\nTreatment: {treat:4d}     maximum share: {shr:>7.1%}'
                 for treat, shr in enumerate(opt_o.other_cfg.max_shares)
                 ]
        txt += ('\nThe following restrictions on the treatment shares are '
                f'specified: {" ".join(share)}.'
                )
    else:
        txt += '\nTreatment shares are unrestricted.'

    txt += '\n' * 2 + 'FAIRNESS'
    if opt_o.fair_cfg.solvefair_used:
        txt += '\nFairness adjustments prior to policy learning.'
        protected_var = var_cfg.protected_ord_name.copy()
        protected_var.extend(var_cfg.protected_unord_name)
        txt += f'\nProtected variables: {", ".join(protected_var)}'
        material_var = var_cfg.material_ord_name.copy()
        material_var.extend(var_cfg.material_unord_name)
        if material_var:
            txt += f'\nMaterially relevant variables: {", ".join(material_var)}'

        adjust_target = getattr(opt_o.fair_cfg, 'adjust_target')
        match adjust_target:
            case 'xvariables':
                adjust_objects = 'Decision variables'
            case 'scores':
                adjust_objects = 'Policy scores'
            case _:
                adjust_objects = 'Policy scores and decision variables'

        txt += f'\nAdjusted objects: {adjust_objects}'
        txt += (f'\nFinal adjustment method setting: {opt_o.fair_cfg.adj_type}. '
                'Earlier adjustment steps may have used a different method. '
                'When enabled, the fairness adjustment output records '
                'the methods used at each step.'
                )
        txt += ('\nConfigured discretization method for protected variables: '
                f'{opt_o.fair_cfg.protected_disc_method}'
                )
        if material_var:
            txt += ('\nConfigured discretization method for materially relevant variables: '
                    f'{opt_o.fair_cfg.material_disc_method}'
                    )
        txt += ('\nEach quantile adjustment uses exact cells when the conditioning features have '
                'sufficiently few values in that sample. This does not change these settings.'
                )

        txt += '\nFor more detail information on methods used see output files.'
    else:
        txt += '\nNo fairness adjustments performed.'

    txt += '\n' * 2 + 'ESTIMATION RISK'
    if opt_o.estriskcfg.estrisk_used:
        txt += ('\nScores are adjusted for estimation error of the policy '
                'scores prior to policy learning.'
                )
    else:
        txt += '\nNo adjustments for estimation error performed.'

    return txt + '\n' * empty_lines_end


def opt_versions(opt_o: 'OptimalPolicyVersions', empty_lines_end: int) -> str:
    """General introduction into optimal policy estimation with treatment versions."""
    optp = opt_o.optp[0] if isinstance(opt_o.optp, list) else opt_o.optp
    method = optp.gen_cfg.method

    txt = 'Accounting for treatment versions in finding optimal assignment rules is implemented by '
    match method:
        case 'policy_tree':
            txt += ('a two-step procedure. '
                    '\nIn a first step a policy tree is build for the main treatments using a '
                    f'shallow decision tree with requested depth {optp.pt_cfg.depth-1} '
                    )
            if optp.pt_cfg.depth_tree_2 > 1:
                txt += (' (based on 2 sequentially optimal trees, '
                        f'requested depth of 1st tree: {optp.pt_cfg.depth_tree_1-1}, '
                        f'requested depth of 2nd tree: {optp.pt_cfg.depth_tree_2-1}) '
                        )
            dvt = [str(d) for d in opt_o.version_cfg.depth_version_tree]
            txt += ('.'
                    '\nIn the second step, for each main treatment that has treatment versions '
                    'an additional policy tree is build allocating its versions. The depths of '
                    'these trees for the treatment versions may differ among the main treatments. '
                    f'The following depths are requested: {", ".join(dvt)}. '
                    # '\n\nThe tree shown below is the tree for the main treatment only. The trees '
                    # 'for the treatment versions are contained in the output files. '
                    )
            txt += '\nNote: Below, the respective trees are shown. '
        case _:
            txt += 'by treating each version as a seperate treatment and use standard methods. '
    txt += '\n\nThe following policy scores are used: '
    for key, item in opt_o.version_cfg.policyscores_dict.items():
        print_str = " ".join(item) if isinstance(item, (list, tuple)) else item
        txt += f'\nMain treatment: {key}, versions: {print_str} '

    txt += ('\n\nThe results of any evaluations of the obtained allocations is contained in the '
            'respective output files. '
            )

    return txt + '\n' * empty_lines_end
